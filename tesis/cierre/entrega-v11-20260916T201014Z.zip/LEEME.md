# Insumos para escribir la V11 del informe

| Archivo | Qué es | Cómo usarlo |
|---|---|---|
| `Tesis_v10_cierre_tecnico.docx` | Documento base (V10). No modificarlo | Entrada del proceso de edición |
| `CAMBIOS_PARA_TESIS_V11.md` | Las ediciones a aplicar: texto actual de V10 con su página y texto propuesto para V11 | Fuente única de los cambios |
| `CIERRE_CONSOLIDADO.pdf` | Informe consolidado de cierre (24 páginas), con el corte vigente 25/6/0 en §6.5 | Referencia para verificar afirmaciones. No se copia dentro de la tesis |

## Reglas de edición

- La V11 se produce con el pipeline de scripts que generó la V10, no editando el DOCX a mano:
  `docs/cierre/evidencia/v10-closure-20260912T190052Z/build/` (lxml sobre OOXML, render con
  LibreOffice, `validate_v10.py`, índices con paginación iterativa).
- No modificar la V10 ni los paquetes de evidencia.
- No incorporar la declaración de uso de herramientas de IA: retirada por decisión del autor.
- N-3 y N-4 no se cierran en esta versión; sólo se refuerza la advertencia de procedencia (§7.3).
- Declarar el ajuste de criterios del 2026-09-15 (§7.4) y aplicar el recuento 25 completas /
  6 parciales / 0 sin cobertura, sobre `devel` commit `2475de8` (§7.5).

## Antes de publicar

`CAMBIOS_PARA_TESIS_V11.md` contiene marcadores `[CONFIRMAR POR EL AUTOR]`: hay que resolverlos o
retirar la afirmación correspondiente antes de dar la versión por cerrada.
