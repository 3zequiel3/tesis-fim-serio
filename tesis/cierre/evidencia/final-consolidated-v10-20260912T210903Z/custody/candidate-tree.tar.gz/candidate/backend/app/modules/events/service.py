"""
Lógica de negocio del dominio de eventos (Change 11).

Expone: validate_transition, ingest_event, compact_chain, retention_task.
Reutilizable por el consumer Valkey y el HTTP handler de approve/reject (C13).
"""

from __future__ import annotations

import asyncio
import re
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from enum import Enum
from typing import Any, Callable

import structlog
from sqlalchemy import update as sa_update
from sqlmodel import Session, select

from app.core.database import engine
from app.modules.audit.models import AuditLog
from app.modules.events.models import Event, EventStatus
from app.modules.rules.models import RuleSeverity
from app.modules.rules.service import determine_severity_for_path

log = structlog.get_logger()

_MAX_DIFF_TEXT_BYTES = 1024 * 1024
_DIFF_TRUNCATION_MARKER = "\n... [diff truncated by backend]\n"
_UNIFIED_HUNK = re.compile(r"^@@ -\d+(?:,\d+)? \+\d+(?:,\d+)? @@(?: .*)?$", re.MULTILINE)

# US-09: hex dump parcial acotado (modo binario del DiffViewer). El agente ya
# limita cada lado a _HEX_DUMP_BYTES=256 bytes (agent/detector.py); a 3 chars
# por byte más el offset por fila, 4096 deja margen holgado sin abrir la
# puerta a un payload arbitrariamente grande de un agente comprometido.
_MAX_HEX_DUMP_CHARS = 4096
_HEX_DUMP_LINE = re.compile(r"^[0-9a-f]{8}  [0-9a-f]{2}(?: [0-9a-f]{2}){0,15}$")


def _is_safe_text(value: str) -> bool:
    if "\x00" in value or "\ufffd" in value:
        return False
    return all(
        char in "\t\n\r\f" or not (ord(char) < 32 or 127 <= ord(char) < 160)
        for char in value
    )


def _is_unified_diff(value: str) -> bool:
    lines = value.splitlines()
    if len(lines) < 4 or not lines[0].startswith("--- ") or not lines[1].startswith("+++ "):
        return False

    in_hunk = False
    has_change = False
    for line in lines[2:]:
        if _UNIFIED_HUNK.fullmatch(line):
            in_hunk = True
            continue
        if not in_hunk or not line.startswith((" ", "+", "-", "\\ No newline at end of file")):
            return False
        has_change = has_change or line.startswith(("+", "-"))
    return in_hunk and has_change


def _bounded_diff_text(value: Any) -> str | None:
    """Return a UTF-8-safe, bounded textual diff without logging its content."""
    if (
        not isinstance(value, str)
        or not value
        or not _is_safe_text(value)
        or not _is_unified_diff(value)
    ):
        return None

    encoded = value.encode("utf-8")
    if len(encoded) <= _MAX_DIFF_TEXT_BYTES:
        return value

    marker = _DIFF_TRUNCATION_MARKER.encode("utf-8")
    prefix = encoded[: _MAX_DIFF_TEXT_BYTES - len(marker)].decode("utf-8", errors="ignore")
    return prefix + _DIFF_TRUNCATION_MARKER


def _bounded_hex_dump(value: Any) -> str | None:
    """Return a validated, bounded partial hex dump or None (US-09).

    Same defensive posture as _bounded_diff_text: a malformed, oversized, or
    wrong-typed value (from an untrusted or older agent) is dropped rather
    than persisted or guessed at — never truncated/repaired, just rejected.
    """
    if not isinstance(value, str) or not value:
        return None
    if len(value) > _MAX_HEX_DUMP_CHARS:
        return None
    if not all(_HEX_DUMP_LINE.fullmatch(line) for line in value.split("\n")):
        return None
    return value

TERMINAL_STATUSES: frozenset[EventStatus] = frozenset(
    {
        EventStatus.approved,
        EventStatus.rejected,
        EventStatus.auto_restored,
        EventStatus.quarantined,
        EventStatus.alert_only,
        EventStatus.superseded,
    }
)

# RN-72: solo pending tiene out-edges; todos los demás son terminales.
VALID_TRANSITIONS: dict[EventStatus, set[EventStatus]] = {
    EventStatus.pending: {EventStatus.approved, EventStatus.rejected, EventStatus.superseded},
    EventStatus.approved: set(),
    EventStatus.rejected: set(),
    EventStatus.auto_restored: set(),
    EventStatus.quarantined: set(),
    EventStatus.alert_only: set(),
    EventStatus.superseded: set(),
}

_MAX_CHAIN = 10
_RETENTION_DAYS = 30


class InvalidTransitionError(Exception):
    def __init__(self, from_status: EventStatus, to_status: EventStatus) -> None:
        self.from_status = from_status
        self.to_status = to_status
        super().__init__(f"Invalid transition: {from_status} → {to_status}")


class IngestDisposition(str, Enum):
    """Resultado materializado de un intento transaccional de ingesta."""

    persisted = "persisted"
    duplicate = "duplicate"
    supersede_race = "supersede_race"
    rate_limited = "rate_limited"


@dataclass(frozen=True)
class IngestOutcome:
    disposition: IngestDisposition
    event: Event | None = None


def validate_transition(from_status: EventStatus, to_status: EventStatus) -> None:
    """Lanza InvalidTransitionError si la transición no está en VALID_TRANSITIONS."""
    if to_status not in VALID_TRANSITIONS.get(from_status, set()):
        raise InvalidTransitionError(from_status, to_status)


# D35/RN-129 (C40): tabla de derivación del status terminal a partir de lo que
# el agente ya publica. El backend es la única autoridad sobre EventStatus —
# no se acepta un `status` de escritura libre del payload (ver ingest_event).
def derive_event_status(action: str | None, action_failed: bool) -> EventStatus:
    """
    Deriva el EventStatus de un evento entrante desde `action` + `action_failed`.

    - auto_restore sin fallo → auto_restored
    - quarantine sin fallo → quarantined
    - alert_only → alert_only (siempre; no ejecuta acción física, nada que fallar)
    - manual_review → pending
    - auto_restore/quarantine con fallo → pending (el archivo sigue adulterado,
      el incidente vuelve a la cola del operador con approve/reject disponibles)
    - action ausente o desconocida → pending (tolerancia hacia adelante, D33)
    """
    if action == "alert_only":
        return EventStatus.alert_only
    if action == "auto_restore":
        return EventStatus.pending if action_failed else EventStatus.auto_restored
    if action == "quarantine":
        return EventStatus.pending if action_failed else EventStatus.quarantined
    return EventStatus.pending


# US-08 criterio 2: "tipo de acción" siempre visible en el detalle. `action`
# (RuleAction) no sobrevive al ingest más allá de derivar EventStatus (ver
# derive_event_status arriba) — no hay columna nueva ni migración. RN-72 dice
# que `pending` es el único estado con out-edges (VALID_TRANSITIONS), así que
# approved/rejected/superseded solo pueden haberse originado en un ingest con
# action=manual_review; auto_restored/quarantined/alert_only son terminales
# sin out-edges y mapean 1:1 a la acción que los produjo.
def derive_action_type(event_status: EventStatus) -> str:
    """Deriva el tipo de acción a mostrar en el detalle desde el status."""
    if event_status == EventStatus.auto_restored:
        return "auto_restore"
    if event_status == EventStatus.quarantined:
        return "quarantine"
    if event_status == EventStatus.alert_only:
        return "alert_only"
    return "manual_review"


# US-10: la cadena se indexa por path (RN-21/RN-23). Un evento sin path
# (D51/RN-145, ej. detection_gap) no participa del mecanismo — su "cadena" es
# únicamente él mismo, nunca se agrupa con otros eventos sin ruta (un filtro
# `Event.path == None` traducido a `IS NULL` agruparía a todos los pathless
# entre sí, que es exactamente lo que D51/RN-145 dice que no debe pasar).
def get_event_chain(session: Session, event: Event) -> list[Event]:
    """Retorna todos los eventos del mismo path que `event`, orden cronológico ascendente."""
    if event.path is None:
        return [event]
    return list(
        session.exec(
            select(Event)
            .where(Event.path == event.path)
            .order_by(Event.created_at.asc(), Event.id.asc())
        ).all()
    )


def get_pending_event_for_path(session: Session, path: str) -> Event | None:
    """Retorna el evento pending más reciente para un path, o None."""
    return session.exec(
        select(Event)
        .where(Event.path == path, Event.status == EventStatus.pending)
        .order_by(Event.created_at.desc())
    ).first()


def mark_superseded(session: Session, event_id: int, version: int) -> bool:
    """
    UPDATE optimista: marca el evento como superseded solo si version coincide y status=pending.
    Retorna True si afectó 1 fila, False si hubo carrera (0 filas).
    """
    stmt = (
        sa_update(Event)
        .where(
            Event.id == event_id,
            Event.version == version,
            Event.status == EventStatus.pending,
        )
        .values(status=EventStatus.superseded, version=version + 1)
        .execution_options(synchronize_session=False)
    )
    result = session.execute(stmt)
    return result.rowcount == 1


def compact_chain(session: Session, path: str) -> None:
    """
    Si hay >_MAX_CHAIN eventos superseded para el path, elimina los más antiguos
    excluyendo los referenciados en audit_log. Se llama en la misma transacción
    que ingest_event (RN-98).
    """
    superseded = session.exec(
        select(Event)
        .where(Event.path == path, Event.status == EventStatus.superseded)
        .order_by(Event.created_at.asc())
    ).all()

    if len(superseded) <= _MAX_CHAIN:
        return

    protected_ids: set[int] = {
        r
        for r in session.exec(
            select(AuditLog.target_id).where(
                AuditLog.target_type == "event",
                AuditLog.target_id.isnot(None),
            )
        ).all()
        if r is not None
    }

    excess = len(superseded) - _MAX_CHAIN
    deleted = 0
    for evt in superseded:
        if deleted >= excess:
            break
        if evt.id not in protected_ids:
            session.delete(evt)
            deleted += 1


def _ingest_event_outcome(
    event_data: dict[str, Any],
    received_at: datetime,
    detected_at: datetime,
    *,
    accept_new: Callable[[], bool] | None = None,
) -> IngestOutcome:
    """
    Ingesta un evento válido:
    1. Busca pending para el mismo path.
    2. Si existe → mark_superseded (optimistic); si carrera → retorna None.
    3. Crea el nuevo evento con parent_event_id si hubo superseded.
    4. Llama compact_chain en la misma transacción.
    """
    # D51/RN-145: sin default. El "" que había acá era la clave con la que
    # get_pending_event_for_path buscaba el pending anterior para supersedirlo
    # — con ella, TODOS los eventos sin ruta (p. ej. detection_gap) se
    # supersederían entre sí bajo la misma clave, y cada brecha nueva
    # borraría la anterior de la vista del operador. El nulo debe llegar
    # nulo hasta la columna.
    path = event_data.get("path")
    # D51/RN-145: vocabulario que el agente ya emite, persistido sin
    # validación contra enum (mismo criterio de tolerancia hacia adelante que
    # action/action_error, D33/D36/RN-130). Ausente (clave faltante, agente
    # anterior a esta change) -> default del modelo, 'file_modified'.
    event_type = event_data.get("event_type", "file_modified")
    # D35/RN-129 (C40): el status NO se lee del payload — el backend es la
    # única autoridad sobre EventStatus. Se deriva de action/action_failed,
    # que son un vocabulario cerrado producido por el motor de reglas del
    # agente; aceptar un `status` de escritura libre permitiría a un agente
    # comprometido inyectar eventos ya `approved`/`rejected`.
    action = event_data.get("action")
    action_failed = bool(event_data.get("action_failed", False))
    status = derive_event_status(action, action_failed)
    # D36/RN-130 (C41): causa del fallo, puramente explicativa — no influye en
    # la derivación de status ni en la supersesión. Sin validación contra
    # enum (tolerancia hacia adelante, D-8 del design): un valor desconocido
    # se persiste tal cual, truncado a la longitud de la columna; ausente ->
    # None. En la ruta de éxito el agente no escribe la clave.
    action_error = event_data.get("action_error")
    if isinstance(action_error, str):
        action_error = action_error[:64]
    else:
        action_error = None

    hash_expected = event_data.get("hash_expected")
    if isinstance(hash_expected, str):
        hash_expected = hash_expected[:64]
    else:
        hash_expected = None
    diff_text = _bounded_diff_text(event_data.get("diff_text"))
    # US-09: is_binary tolerante hacia adelante (mismo criterio que
    # is_symlink/action_failed) — ausente en un agente anterior a esta
    # change -> False. hex_dump_before/hex_dump_after pasan por la misma
    # validación defensiva bounded que diff_text.
    is_binary = bool(event_data.get("is_binary", False))
    hex_dump_before = _bounded_hex_dump(event_data.get("hex_dump_before"))
    hex_dump_after = _bounded_hex_dump(event_data.get("hex_dump_after"))

    with Session(engine) as session:
        duplicate = session.exec(
            select(Event).where(Event.event_id == event_data.get("event_id", ""))
        ).first()
        if duplicate is not None:
            session.expunge(duplicate)
            return IngestOutcome(IngestDisposition.duplicate, duplicate)

        # Reservar capacidad solo después de deduplicar en la transacción.
        if accept_new is not None and not accept_new():
            return IngestOutcome(IngestDisposition.rate_limited)

        # D51/RN-145 (D-6 del design): un evento sin ruta no participa de la
        # supersesión por path — get_pending_event_for_path NUNCA se invoca
        # con path=None, mantiene su firma `path: str`.
        pending = get_pending_event_for_path(session, path) if path is not None else None
        parent_event_id: int | None = None

        if pending is not None and pending.id is not None:
            validate_transition(pending.status, EventStatus.superseded)
            success = mark_superseded(session, pending.id, pending.version)
            if not success:
                log.warning("service.superseded_race", path=path, pending_id=pending.id)
                # FIX-03 (D25, RN-121): re-consultar si el pending fue aprobado/rechazado
                # concurrentemente (en ese caso no hay pending activo → insertar independiente)
                still_pending = get_pending_event_for_path(session, path)
                if still_pending is not None:
                    # Todavía hay un pending activo → skip legítimo
                    log.warning("service.superseded_race.still_pending", path=path)
                    return IngestOutcome(IngestDisposition.supersede_race)
                # No hay pending → continuar inserción como evento independiente
                log.info("service.superseded_race.insert_independent", path=path)
                # parent_event_id ya es None; el flujo continúa normalmente
            else:
                parent_event_id = pending.id

        # D35/RN-129 (C40): terminales de origen agente se persisten con
        # resolved_at = received_at y resolved_by = NULL — identifica una
        # resolución automática sin operador humano. pending (incluido el
        # pending por acción fallida) queda abierto: ambos campos en None.
        is_terminal = status in (
            EventStatus.auto_restored,
            EventStatus.quarantined,
            EventStatus.alert_only,
        )

        # D51/RN-145 (D-7 del design): un evento sin ruta recibe severidad
        # `high` fija, SIN consultar el ruleset — determine_severity_for_path
        # no matchea ninguna regla sin path y caería en `low` (D-C15-01), que
        # es lo contrario de lo que significa una pérdida de cobertura. La
        # excepción se dispara por AUSENCIA DE RUTA, no por
        # event_type == "detection_gap": un tipo de evento futuro sin ruta
        # hereda el tratamiento correcto sin tocar este código. `high` y no
        # `critical`: una brecha de detección es una pérdida de garantía, no
        # una violación de integridad confirmada (D34/RN-128 sigue siendo la
        # única autoridad — el valor que el agente proponga se ignora igual).
        severity = (
            RuleSeverity.high
            if path is None
            else determine_severity_for_path(path, session)
        )

        event = Event(
            event_id=event_data.get("event_id", ""),
            agent_id=event_data.get("agent_id", ""),
            event_type=event_type,
            path=path,
            hash_detected=event_data.get("hash_detected") or "",
            hash_expected=hash_expected,
            diff_text=diff_text,
            is_binary=is_binary,
            hex_dump_before=hex_dump_before,
            hex_dump_after=hex_dump_after,
            status=status,
            severity=severity,
            action_failed=action_failed,
            action_error=action_error,
            parent_event_id=parent_event_id,
            process_pid=event_data.get("process_pid"),
            process_uid=event_data.get("process_uid"),
            process_exe=event_data.get("process_exe"),
            detected_at=detected_at,
            received_at=received_at,
            resolved_at=received_at if is_terminal else None,
            resolved_by=None,
            # D33/RN-127 (C39): .get() tolerante — un agente viejo sin estas keys
            # ingiere igual, con defaults false/None.
            is_symlink=event_data.get("is_symlink", False),
            symlink_target=event_data.get("symlink_target"),
        )
        session.add(event)
        session.flush()

        # D51/RN-145 (D-6 del design): la condición `parent_event_id is not
        # None` ya implica `path is not None` por construcción — sólo hay
        # parent_event_id cuando hubo supersesión, y un evento sin ruta nunca
        # supersede (ver la guarda de arriba). Se declara la guarda explícita
        # igual, para que un refactor futuro no la pierda: un compact_chain
        # sobre ruta nula borraría eventos de brecha de detección al llegar
        # al umbral de 10.
        if parent_event_id is not None and path is not None:
            compact_chain(session, path)

        # Separar la fila ya materializada antes del commit evita que el
        # despacho dispare un SELECT por expiración del objeto.
        session.expunge(event)
        session.commit()
        return IngestOutcome(IngestDisposition.persisted, event)


def ingest_event(
    event_data: dict[str, Any],
    received_at: datetime,
    detected_at: datetime,
) -> Event | None:
    """API de dominio compatible; el consumer usa el resultado tipado interno."""
    return _ingest_event_outcome(event_data, received_at, detected_at).event


async def retention_task() -> None:
    """
    Tarea asyncio periódica: elimina eventos terminales con más de 30 días
    que no están referenciados en audit_log (RN-98).
    """
    while True:
        await asyncio.sleep(3600)
        cutoff = datetime.now(timezone.utc) - timedelta(days=_RETENTION_DAYS)
        with Session(engine) as session:
            protected_ids: set[int] = {
                r
                for r in session.exec(
                    select(AuditLog.target_id).where(
                        AuditLog.target_type == "event",
                        AuditLog.target_id.isnot(None),
                    )
                ).all()
                if r is not None
            }

            q = select(Event).where(
                Event.status.in_(list(TERMINAL_STATUSES)),
                Event.created_at < cutoff,
            )
            if protected_ids:
                q = q.where(Event.id.notin_(protected_ids))

            to_delete = session.exec(q).all()
            for evt in to_delete:
                session.delete(evt)
            if to_delete:
                session.commit()
                log.info("service.retention_run", deleted=len(to_delete))
