"""
Tests D-A3 (LANE L9, ensayo multianfitrión) — SANs adicionales y EKU
completo en el certificado de servidor del backend.

Cubre:
- parse_extra_sans: formato "IP:"/"DNS:", errores de formato.
- ensure_ca(..., extra_sans=...): el cert de backend generado lleva los SANs
  fijos (backend, fim-backend, localhost) MÁS los de extra_sans, y EKU
  SERVER_AUTH + CLIENT_AUTH (antes sólo SERVER_AUTH — D-A3 lo agrega porque
  este mismo cert se reutiliza como identidad de cliente TLS hacia Valkey,
  L8/app.core.valkey._tls_kwargs).
- Idempotencia: una segunda llamada con los mismos extra_sans no regenera;
  con SANs nuevos, si regenera.
"""

from __future__ import annotations

import ipaddress
import os

import pytest
from cryptography import x509
from cryptography.x509.oid import ExtendedKeyUsageOID

os.environ.setdefault("DATABASE_URL", "postgresql+psycopg://fim:test@localhost:5432/fim_test")
os.environ.setdefault("VALKEY_URL", "valkey://localhost:6379")
os.environ.setdefault("JWT_SECRET_CURRENT", "test-secret-current-32-chars-xxxxx")
os.environ.setdefault("JWT_SECRET_PREVIOUS", "")
os.environ.setdefault("ADMIN_USERNAME", "admin")
os.environ.setdefault("ADMIN_PASSWORD", "AdminPassword123!")
os.environ.setdefault("CORS_ALLOWED_ORIGINS", "http://localhost:5173")


# ── parse_extra_sans ───────────────────────────────────────────────────────


def test_parse_extra_sans_vacio() -> None:
    from app.core.pki import parse_extra_sans

    assert parse_extra_sans("") == []
    assert parse_extra_sans("   ") == []


def test_parse_extra_sans_ip_y_dns() -> None:
    from app.core.pki import parse_extra_sans

    result = parse_extra_sans("IP:192.168.1.43,DNS:fim-server.lan")
    assert result == [
        x509.IPAddress(ipaddress.ip_address("192.168.1.43")),
        x509.DNSName("fim-server.lan"),
    ]


def test_parse_extra_sans_prefijo_invalido() -> None:
    from app.core.pki import parse_extra_sans

    with pytest.raises(ValueError, match="prefix must be 'DNS' or 'IP'"):
        parse_extra_sans("FOO:bar")


def test_parse_extra_sans_ip_malformada() -> None:
    from app.core.pki import parse_extra_sans

    with pytest.raises(ValueError, match="invalid FIM_EXTRA_SANS entry"):
        parse_extra_sans("IP:999.999.999.999")


def test_parse_extra_sans_sin_valor() -> None:
    from app.core.pki import parse_extra_sans

    with pytest.raises(ValueError, match="invalid FIM_EXTRA_SANS entry"):
        parse_extra_sans("DNS:")


# ── ensure_ca(..., extra_sans=...) ─────────────────────────────────────────


def test_backend_cert_incluye_sans_fijos_mas_extra_sans(tmp_path) -> None:
    from app.core.pki import ensure_ca

    ca_file = tmp_path / "ca.pem"
    ca_key = tmp_path / "ca-key.pem"
    cert_file = tmp_path / "backend.pem"
    key_file = tmp_path / "backend-key.pem"

    ensure_ca(
        str(ca_file), str(ca_key), str(cert_file), str(key_file),
        extra_sans="IP:192.168.1.43,DNS:fim-server.lan",
    )

    cert = x509.load_pem_x509_certificate(cert_file.read_bytes())
    san = cert.extensions.get_extension_for_class(x509.SubjectAlternativeName).value
    general_names = list(san)

    for expected in (
        x509.DNSName("backend"),
        x509.DNSName("fim-backend"),
        x509.DNSName("localhost"),
        x509.DNSName("fim-server.lan"),
        x509.IPAddress(ipaddress.ip_address("192.168.1.43")),
    ):
        assert expected in general_names, f"falta {expected} en el SAN del cert de backend"


def test_backend_cert_sin_extra_sans_mantiene_solo_los_fijos(tmp_path) -> None:
    from app.core.pki import ensure_ca

    ca_file = tmp_path / "ca.pem"
    ca_key = tmp_path / "ca-key.pem"
    cert_file = tmp_path / "backend.pem"
    key_file = tmp_path / "backend-key.pem"

    ensure_ca(str(ca_file), str(ca_key), str(cert_file), str(key_file))

    cert = x509.load_pem_x509_certificate(cert_file.read_bytes())
    san = cert.extensions.get_extension_for_class(x509.SubjectAlternativeName).value
    assert list(san) == [
        x509.DNSName("backend"),
        x509.DNSName("fim-backend"),
        x509.DNSName("localhost"),
    ]


def test_backend_cert_eku_incluye_server_auth_y_client_auth(tmp_path) -> None:
    """D-A3: este cert se reutiliza como identidad de cliente TLS hacia
    Valkey (L8) — necesita CLIENT_AUTH además de SERVER_AUTH."""
    from app.core.pki import ensure_ca

    ca_file = tmp_path / "ca.pem"
    ca_key = tmp_path / "ca-key.pem"
    cert_file = tmp_path / "backend.pem"
    key_file = tmp_path / "backend-key.pem"

    ensure_ca(str(ca_file), str(ca_key), str(cert_file), str(key_file))

    cert = x509.load_pem_x509_certificate(cert_file.read_bytes())
    eku = set(cert.extensions.get_extension_for_class(x509.ExtendedKeyUsage).value)
    assert eku == {ExtendedKeyUsageOID.SERVER_AUTH, ExtendedKeyUsageOID.CLIENT_AUTH}


def test_backend_cert_no_se_regenera_si_ya_tiene_los_mismos_extra_sans(tmp_path) -> None:
    from app.core.pki import ensure_ca

    ca_file = tmp_path / "ca.pem"
    ca_key = tmp_path / "ca-key.pem"
    cert_file = tmp_path / "backend.pem"
    key_file = tmp_path / "backend-key.pem"

    ensure_ca(
        str(ca_file), str(ca_key), str(cert_file), str(key_file),
        extra_sans="IP:192.168.1.43",
    )
    first_bytes = cert_file.read_bytes()

    ensure_ca(
        str(ca_file), str(ca_key), str(cert_file), str(key_file),
        extra_sans="IP:192.168.1.43",
    )
    assert cert_file.read_bytes() == first_bytes


def test_backend_cert_se_regenera_si_extra_sans_cambia(tmp_path) -> None:
    from app.core.pki import ensure_ca

    ca_file = tmp_path / "ca.pem"
    ca_key = tmp_path / "ca-key.pem"
    cert_file = tmp_path / "backend.pem"
    key_file = tmp_path / "backend-key.pem"

    ensure_ca(str(ca_file), str(ca_key), str(cert_file), str(key_file))
    first_bytes = cert_file.read_bytes()

    ensure_ca(
        str(ca_file), str(ca_key), str(cert_file), str(key_file),
        extra_sans="IP:192.168.1.43",
    )
    second_bytes = cert_file.read_bytes()
    assert second_bytes != first_bytes

    cert = x509.load_pem_x509_certificate(second_bytes)
    san = cert.extensions.get_extension_for_class(x509.SubjectAlternativeName).value
    assert x509.IPAddress(ipaddress.ip_address("192.168.1.43")) in list(san)
