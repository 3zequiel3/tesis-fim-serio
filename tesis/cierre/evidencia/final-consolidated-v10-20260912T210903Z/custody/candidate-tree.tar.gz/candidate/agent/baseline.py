"""
Motor de baseline cifrado AES-256-GCM para el agente FIM (Change 07, RN-15/19/47-50/66/82).

API in-process — sin servidor HTTP (D8/RN-108).
Flujo típico de cambio detectado:
    engine.add_snapshot(path)   # archiva versión actual en snapshots
    engine.write_entry(path)    # actualiza entry con nuevo contenido
"""

from __future__ import annotations

import base64
import dataclasses
import gzip
import hashlib
import json
import os
import platform
import stat
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import TYPE_CHECKING

_LINUX = platform.system() == "Linux"

import structlog
from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.hashes import SHA256
from cryptography.hazmat.primitives.kdf.hkdf import HKDF

from agent.detector import _target_in_scope

if TYPE_CHECKING:
    from agent.config import AgentConfig

log = structlog.get_logger()

_VERSION = b"\x01"
_NONCE_LEN = 12
_MAX_FILE_BYTES = 10 * 1024 * 1024  # 10 MiB — archivos más grandes: solo hash+metadata
_MAX_SNAPSHOTS = 3


class BaselineIntegrityError(Exception):
    def __init__(self, path: str) -> None:
        self.path = path
        super().__init__(f"baseline integrity failure: {path}")


class BaselineApprovalError(Exception):
    """A baseline approval cannot be bound to an exact local detection."""


@dataclass
class Snapshot:
    hash: str
    captured_at: str
    gzip: bool
    content_b64: str | None


@dataclass
class BaselineEntry:
    path: str
    status: str  # "present" | "absent"
    hash: str | None
    size: int | None
    mode: str | None
    uid: int | None
    gid: int | None
    mtime: str | None
    captured_at: str
    snapshots: list[Snapshot]
    content_b64: str | None
    oversize: bool = False
    # D33/RN-127: string crudo de os.readlink si el path es un symlink; None para
    # archivos regulares. Default retrocompatible — entries viejas sin esta key
    # parsean igual vía from_dict.
    symlink_target: str | None = None
    # UUID emitted by the agent for the event that last established this active
    # baseline. It makes command redelivery idempotent without reusing stale bytes.
    approved_event_id: str | None = None

    def to_json_bytes(self) -> bytes:
        return json.dumps(dataclasses.asdict(self), ensure_ascii=False).encode()

    @classmethod
    def from_dict(cls, d: dict) -> "BaselineEntry":
        snaps = [Snapshot(**s) for s in d.get("snapshots", [])]
        fields = {k: v for k, v in d.items() if k != "snapshots"}
        return cls(**fields, snapshots=snaps)


@dataclass
class ApprovalCandidate:
    """Encrypted, one-per-path local content awaiting explicit approval."""

    event_id: str
    path: str
    status: str
    hash: str | None
    size: int | None
    mode: str | None
    uid: int | None
    gid: int | None
    mtime: str | None
    captured_at: str
    content_b64: str | None
    symlink_target: str | None = None


@dataclass
class ScanReport:
    scanned: int
    skipped: int
    oversize: int
    errors: int


# ── 1. Cripto ────────────────────────────────────────────────────────────────

def load_master_secret(secrets_dir: str | Path) -> bytes:
    p = Path(secrets_dir) / "master_secret"
    if not p.exists():
        raise FileNotFoundError(f"master_secret not found: {p}")
    data = p.read_bytes()
    if len(data) != 32:
        raise ValueError(f"master_secret must be exactly 32 bytes, got {len(data)}")
    return data


def derive_baseline_key(master_secret: bytes, agent_id: str) -> bytes:
    hkdf = HKDF(
        algorithm=SHA256(),
        length=32,
        salt=agent_id.encode(),
        info=b"baseline-v1",
    )
    return hkdf.derive(master_secret)


def _encrypt(key: bytes, plaintext_json: bytes) -> bytes:
    nonce = os.urandom(_NONCE_LEN)
    ciphertext = AESGCM(key).encrypt(nonce, plaintext_json, None)
    return _VERSION + nonce + ciphertext


def _decrypt(key: bytes, blob: bytes) -> bytes:
    if len(blob) < 1 + _NONCE_LEN + 16:
        raise ValueError("blob too short")
    if blob[0:1] != _VERSION:
        raise ValueError(f"unknown baseline version: {blob[0]:#04x}")
    nonce = blob[1:1 + _NONCE_LEN]
    ciphertext = blob[1 + _NONCE_LEN:]
    return AESGCM(key).decrypt(nonce, ciphertext, None)  # raises InvalidTag on tamper


# ── 2. Persistencia atómica ───────────────────────────────────────────────────

def _entry_path(baseline_dir: Path, path: str) -> Path:
    name = hashlib.sha256(path.encode()).hexdigest() + ".bin"
    return baseline_dir / name


def _candidate_path(candidate_dir: Path, path: str) -> Path:
    name = hashlib.sha256(path.encode()).hexdigest() + ".bin"
    return candidate_dir / name


def _atomic_write(final_path: Path, data: bytes) -> None:
    tmp = Path(str(final_path) + ".tmp")
    fd = os.open(str(tmp), os.O_CREAT | os.O_WRONLY | os.O_TRUNC, 0o600)
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(data)
            f.flush()
            os.fsync(f.fileno())
    except Exception:
        try:
            os.unlink(str(tmp))
        except OSError:
            pass
        raise
    os.replace(str(tmp), str(final_path))


# ── helpers ───────────────────────────────────────────────────────────────────

def _sha256_file(path: str) -> tuple[str, bytes]:
    h = hashlib.sha256()
    chunks: list[bytes] = []
    with open(path, "rb") as f:
        while chunk := f.read(65536):
            h.update(chunk)
            chunks.append(chunk)
    return h.hexdigest(), b"".join(chunks)


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


# ── Helper de selección de contenido restaurable ─────────────────────────────

def select_restorable_content(entry: "BaselineEntry") -> tuple[bytes, str] | None:
    """
    Retorna (content_bytes, expected_hash) del mejor origen restaurable.

    Primero intenta el contenido activo (entry.content_b64). Si es None,
    itera entry.snapshots en orden inverso (más reciente primero) buscando
    el primero con content_b64 no nulo — descomprimiendo si gzip=True.

    Retorna None si no hay ningún origen restaurable.
    """
    if entry.content_b64 is not None:
        return base64.b64decode(entry.content_b64), entry.hash or ""

    for snap in reversed(entry.snapshots):
        if snap.content_b64 is None:
            continue
        raw = base64.b64decode(snap.content_b64)
        if snap.gzip:
            raw = gzip.decompress(raw)
        return raw, snap.hash

    return None


# ── Motor ─────────────────────────────────────────────────────────────────────

class BaselineEngine:
    """
    Motor de baseline AES-256-GCM.  Sin servidor HTTP (D8).

    Uso típico:
        engine = BaselineEngine(config, master_secret_bytes)
        report = engine.init_scan(config.watch_paths)
    """

    def __init__(self, config: "AgentConfig", master_secret_bytes: bytes) -> None:
        self._config = config
        self._baseline_dir = Path(config.storage.baseline_dir)
        self._candidate_dir = self._baseline_dir / ".approval-candidates"
        self._key = derive_baseline_key(master_secret_bytes, config.agent_id)
        self._ensure_dir()
        self._candidate_dir.mkdir(mode=0o700, parents=True, exist_ok=True)
        if _LINUX:
            os.chmod(self._candidate_dir, 0o700)

    # ── 2.3 permisos del directorio ────────────────────────────────────────

    def _ensure_dir(self) -> None:
        self._baseline_dir.mkdir(parents=True, exist_ok=True)
        if not _LINUX:
            return  # permisos Unix solo se verifican en producción (Linux)
        try:
            os.chmod(self._baseline_dir, 0o700)
        except OSError as exc:
            raise RuntimeError(
                f"Cannot set 0700 on baseline dir {self._baseline_dir}: {exc}"
            ) from exc
        actual = stat.S_IMODE(self._baseline_dir.stat().st_mode)
        if actual != 0o700:
            raise RuntimeError(
                f"baseline dir {self._baseline_dir} has wrong permissions: {oct(actual)}"
            )

    # ── cifrado/descifrado internos ───────────────────────────────────────

    def _encrypt_entry(self, entry: BaselineEntry) -> bytes:
        return _encrypt(self._key, entry.to_json_bytes())

    def _decrypt_entry(self, blob: bytes, expected_path: str) -> BaselineEntry:
        try:
            plaintext = _decrypt(self._key, blob)
        except InvalidTag:
            log.error("baseline.integrity_failure", path=expected_path, reason="gcm_tag_invalid")
            raise BaselineIntegrityError(expected_path)
        try:
            d = json.loads(plaintext)
            entry = BaselineEntry.from_dict(d)
        except Exception as exc:
            log.error("baseline.parse_failure", path=expected_path, error=str(exc))
            raise BaselineIntegrityError(expected_path) from exc
        # Detecta swapping: el path dentro del plaintext debe coincidir
        if entry.path != expected_path:
            log.error(
                "baseline.path_mismatch",
                expected=expected_path,
                found=entry.path,
            )
            raise BaselineIntegrityError(expected_path)
        return entry

    # ── 3. CRUD de entradas ────────────────────────────────────────────────

    def write_entry(self, path: str) -> BaselineEntry:
        """Escribe/actualiza la entry del path con el contenido actual del archivo.
        Preserva snapshots existentes."""
        file_size = os.path.getsize(path)
        oversize = file_size > _MAX_FILE_BYTES

        existing = self.read_entry(path)
        existing_snapshots = existing.snapshots if existing else []

        hash_hex: str | None = None
        content_b64: str | None = None

        if not oversize:
            hash_hex, content = _sha256_file(path)
            content_b64 = base64.b64encode(content).decode()
        else:
            h = hashlib.sha256()
            with open(path, "rb") as f:
                while chunk := f.read(65536):
                    h.update(chunk)
            hash_hex = h.hexdigest()

        st = os.stat(path)
        entry = BaselineEntry(
            path=path,
            status="present",
            hash=hash_hex,
            size=file_size,
            mode=oct(stat.S_IMODE(st.st_mode)),
            uid=st.st_uid,
            gid=st.st_gid,
            mtime=datetime.fromtimestamp(st.st_mtime, tz=timezone.utc).isoformat(),
            captured_at=_now_iso(),
            snapshots=existing_snapshots,
            content_b64=content_b64,
            oversize=oversize,
        )
        blob = self._encrypt_entry(entry)
        _atomic_write(_entry_path(self._baseline_dir, path), blob)
        return entry

    def write_symlink_entry(self, path: str) -> BaselineEntry:
        """
        Escribe/actualiza la entry de un symlink usando SOLO `os.lstat`/`os.readlink`
        (D33/RN-127) — NUNCA sigue el link ni lee/hashea/cifra el contenido del
        destino, esté este dentro o fuera de scope (Philosophy B, symlink-as-object).

        `content_b64` queda SIEMPRE en `None`; `hash` es `sha256(target)` (el string
        de `readlink`, no el contenido apuntado); `symlink_target` guarda ese mismo
        string. Preserva snapshots existentes, igual que `write_entry`.
        """
        target = os.readlink(path)
        hash_hex = hashlib.sha256(target.encode()).hexdigest()

        existing = self.read_entry(path)
        existing_snapshots = existing.snapshots if existing else []

        st = os.lstat(path)
        entry = BaselineEntry(
            path=path,
            status="present",
            hash=hash_hex,
            size=st.st_size,
            mode=oct(stat.S_IMODE(st.st_mode)),
            uid=st.st_uid,
            gid=st.st_gid,
            mtime=datetime.fromtimestamp(st.st_mtime, tz=timezone.utc).isoformat(),
            captured_at=_now_iso(),
            snapshots=existing_snapshots,
            content_b64=None,
            oversize=False,
            symlink_target=target,
        )
        blob = self._encrypt_entry(entry)
        _atomic_write(_entry_path(self._baseline_dir, path), blob)
        return entry

    def read_entry(self, path: str) -> BaselineEntry | None:
        ep = _entry_path(self._baseline_dir, path)
        if not ep.exists():
            return None
        try:
            return self._decrypt_entry(ep.read_bytes(), path)
        except BaselineIntegrityError:
            raise

    def mark_absent(self, path: str) -> BaselineEntry:
        entry = BaselineEntry(
            path=path,
            status="absent",
            hash=None,
            size=None,
            mode=None,
            uid=None,
            gid=None,
            mtime=None,
            captured_at=_now_iso(),
            snapshots=[],
            content_b64=None,
        )
        blob = self._encrypt_entry(entry)
        _atomic_write(_entry_path(self._baseline_dir, path), blob)
        return entry

    def list_entries(self) -> list[str]:
        paths: list[str] = []
        for f in self._baseline_dir.glob("*.bin"):
            try:
                blob = f.read_bytes()
                plaintext = _decrypt(self._key, blob)
                d = json.loads(plaintext)
                paths.append(d["path"])
            except (InvalidTag, KeyError, json.JSONDecodeError, ValueError, OSError) as exc:
                log.warning("baseline.list_entry_unreadable", file=str(f), error=str(exc))
        return paths

    # ── 4. Snapshots ──────────────────────────────────────────────────────

    def add_snapshot(self, path: str) -> bool:
        """Archiva el contenido activo actual como snapshot (llamar ANTES de write_entry).
        Retorna True si se agregó, False si se omitió por dedup o entry ausente."""
        entry = self.read_entry(path)
        if entry is None or entry.status == "absent" or entry.hash is None:
            return False

        # Dedup: si el último snapshot ya tiene el mismo hash, no agregar
        if entry.snapshots and entry.snapshots[-1].hash == entry.hash:
            return False

        # Nuevo snapshot del contenido activo actual (sin comprimir)
        new_snap = Snapshot(
            hash=entry.hash,
            captured_at=entry.captured_at,
            gzip=False,
            content_b64=entry.content_b64,
        )

        # Comprimir todos los snapshots existentes (pasan a no-activos)
        compressed: list[Snapshot] = []
        for snap in entry.snapshots:
            if not snap.gzip and snap.content_b64 is not None:
                raw = base64.b64decode(snap.content_b64)
                c = gzip.compress(raw, compresslevel=6)
                compressed.append(Snapshot(
                    hash=snap.hash,
                    captured_at=snap.captured_at,
                    gzip=True,
                    content_b64=base64.b64encode(c).decode(),
                ))
            else:
                compressed.append(snap)

        all_snaps = compressed + [new_snap]

        # FIFO: máx 3
        if len(all_snaps) > _MAX_SNAPSHOTS:
            all_snaps = all_snaps[-_MAX_SNAPSHOTS:]

        entry.snapshots = all_snaps
        _atomic_write(_entry_path(self._baseline_dir, path), self._encrypt_entry(entry))
        return True

    # ── 5. Scan y verificación ────────────────────────────────────────────

    def init_scan(self, watch_paths: list[str]) -> ScanReport:
        """Escaneo inicial idempotente: solo procesa archivos sin entry existente."""
        scanned = skipped = oversize_count = errors = 0
        for watch_path in watch_paths:
            p = Path(watch_path)
            if not p.exists():
                log.warning("baseline.watch_path_missing", path=watch_path)
                continue
            watch_path_real = os.path.realpath(watch_path)
            candidates = [p] if p.is_file() else list(p.rglob("*"))
            for file_path in candidates:
                path_str = str(file_path)
                # D33/RN-127: is_symlink() ANTES de is_file() — Path.is_file() sigue
                # symlinks y clasificaría mal un symlink como archivo regular.
                # Todo candidato de rglob ya vive dentro de watch_path (rglob no
                # recursa dentro de dirs simbólicos), así que el symlink está en
                # scope por ubicación sin chequeo adicional (Philosophy B).
                if file_path.is_symlink():
                    if _entry_path(self._baseline_dir, path_str).exists():
                        skipped += 1
                        continue
                    try:
                        self.write_symlink_entry(path_str)
                        scanned += 1
                    except OSError as exc:
                        log.error("baseline.scan_error", path=path_str, error=str(exc))
                        errors += 1
                    continue
                if not file_path.is_file():
                    continue
                if not _target_in_scope(path_str, [watch_path_real]):
                    log.warning("baseline.out_of_scope_skip", path=path_str)
                    skipped += 1
                    continue
                if _entry_path(self._baseline_dir, path_str).exists():
                    skipped += 1
                    continue
                try:
                    entry = self.write_entry(path_str)
                    scanned += 1
                    if entry.oversize:
                        oversize_count += 1
                except OSError as exc:
                    log.error("baseline.scan_error", path=path_str, error=str(exc))
                    errors += 1
        return ScanReport(
            scanned=scanned,
            skipped=skipped,
            oversize=oversize_count,
            errors=errors,
        )

    def run_scan(self, paths: list[str]) -> ScanReport:
        """
        Escaneo bajo demanda para una lista de paths dada (C14, D-C14-07).

        Idéntico al scan inicial pero sin skip de entries existentes:
        sobreescribe (upsert) cualquier entry ya presente — útil para
        rescan_baseline y para paths recién añadidos en update_config.

        Si un path no existe → log warning y continua (no lanza excepción).
        """
        scanned = skipped = oversize_count = errors = 0
        for watch_path in paths:
            p = Path(watch_path)
            if not p.exists():
                log.warning("baseline.run_scan.path_missing", path=watch_path)
                continue
            watch_path_real = os.path.realpath(watch_path)
            candidates = [p] if p.is_file() else list(p.rglob("*"))
            for file_path in candidates:
                path_str = str(file_path)
                # D33/RN-127: is_symlink() ANTES de is_file() (ver init_scan).
                if file_path.is_symlink():
                    try:
                        self.write_symlink_entry(path_str)
                        scanned += 1
                    except OSError as exc:
                        log.error("baseline.run_scan.error", path=path_str, error=str(exc))
                        errors += 1
                    continue
                if not file_path.is_file():
                    continue
                if not _target_in_scope(path_str, [watch_path_real]):
                    log.warning("baseline.out_of_scope_skip", path=path_str)
                    skipped += 1
                    continue
                try:
                    entry = self.write_entry(path_str)
                    scanned += 1
                    if entry.oversize:
                        oversize_count += 1
                except OSError as exc:
                    log.error("baseline.run_scan.error", path=path_str, error=str(exc))
                    errors += 1
        return ScanReport(
            scanned=scanned,
            skipped=skipped,
            oversize=oversize_count,
            errors=errors,
        )

    def verify_entry(self, path: str) -> bool:
        """Verifica integridad GCM. True = íntegra. Raise BaselineIntegrityError si falló el tag."""
        ep = _entry_path(self._baseline_dir, path)
        if not ep.exists():
            return False
        try:
            self._decrypt_entry(ep.read_bytes(), path)
            return True
        except BaselineIntegrityError:
            raise

    def update_from_command(
        self,
        path: str,
        hash_value: str | None,
        baseline_status: str,
        source_event_id: str | None = None,
    ) -> BaselineEntry:
        """
        Actualiza (o crea) la entrada de baseline a partir de un comando baseline_update
        recibido desde el backend (C13, RN handler 8.3).

        La aprobación consume únicamente el candidato local cifrado que fue
        capturado para el UUID de evento original. Nunca combina un hash nuevo
        con content_b64 anterior y nunca recibe contenido desde el backend.

        Misma clave HKDF que el resto del motor. Nuevo nonce AES-GCM por escritura.

        Args:
            path: ruta del archivo monitorizado.
            hash_value: SHA-256 hexadecimal del archivo, o None si status=absent.
            baseline_status: "present" | "absent".
        """
        if not source_event_id:
            raise BaselineApprovalError("approval_event_identity_missing")

        existing = self.read_entry(path)
        if (
            existing is not None
            and existing.approved_event_id == source_event_id
            and existing.status == baseline_status
            and existing.hash == hash_value
        ):
            return existing

        candidate_path = _candidate_path(self._candidate_dir, path)
        if not candidate_path.exists():
            raise BaselineApprovalError("approval_candidate_unavailable")
        try:
            plaintext = _decrypt(self._key, candidate_path.read_bytes())
            candidate = ApprovalCandidate(**json.loads(plaintext))
        except (InvalidTag, OSError, ValueError, TypeError, json.JSONDecodeError) as exc:
            raise BaselineApprovalError("approval_candidate_unavailable") from exc

        if candidate.event_id != source_event_id:
            raise BaselineApprovalError("approval_candidate_stale")
        if (
            candidate.path != path
            or candidate.status != baseline_status
            or candidate.hash != hash_value
        ):
            raise BaselineApprovalError("approval_candidate_mismatch")
        if baseline_status == "present" and candidate.symlink_target is None:
            if candidate.content_b64 is None:
                raise BaselineApprovalError("approval_content_unavailable")
            content = base64.b64decode(candidate.content_b64)
            if hashlib.sha256(content).hexdigest() != hash_value:
                raise BaselineApprovalError("approval_candidate_mismatch")

        entry = BaselineEntry(
            path=path,
            status=baseline_status,
            hash=hash_value,
            size=candidate.size,
            mode=candidate.mode,
            uid=candidate.uid,
            gid=candidate.gid,
            mtime=candidate.mtime,
            captured_at=candidate.captured_at,
            snapshots=existing.snapshots if existing else [],
            content_b64=candidate.content_b64,
            oversize=False,
            symlink_target=candidate.symlink_target,
            approved_event_id=source_event_id,
        )

        blob = self._encrypt_entry(entry)
        _atomic_write(_entry_path(self._baseline_dir, path), blob)
        candidate_path.unlink(missing_ok=True)
        log.info(
            "baseline.update_from_command",
            path=path,
            status=baseline_status,
            hash=hash_value,
        )
        return entry

    def stage_approval_candidate(
        self,
        event_id: str,
        path: str,
        hash_value: str | None,
        baseline_status: str,
        *,
        is_symlink: bool = False,
    ) -> bool:
        """Persist the exact bounded local bytes associated with a detection.

        Only the newest event for a path is retained. The encrypted candidate
        is capped at the same 10 MiB limit as active baseline content.
        """
        candidate_path = _candidate_path(self._candidate_dir, path)
        candidate_path.unlink(missing_ok=True)
        if not event_id or baseline_status not in ("present", "absent"):
            return False

        if baseline_status == "absent":
            if os.path.lexists(path):
                return False
            candidate = ApprovalCandidate(
                event_id=event_id,
                path=path,
                status="absent",
                hash=None,
                size=None,
                mode=None,
                uid=None,
                gid=None,
                mtime=None,
                captured_at=_now_iso(),
                content_b64=None,
            )
        elif is_symlink:
            try:
                target = os.readlink(path)
                st = os.lstat(path)
            except OSError:
                return False
            actual_hash = hashlib.sha256(target.encode()).hexdigest()
            if actual_hash != hash_value:
                return False
            candidate = ApprovalCandidate(
                event_id=event_id,
                path=path,
                status="present",
                hash=actual_hash,
                size=st.st_size,
                mode=oct(stat.S_IMODE(st.st_mode)),
                uid=st.st_uid,
                gid=st.st_gid,
                mtime=datetime.fromtimestamp(st.st_mtime, tz=timezone.utc).isoformat(),
                captured_at=_now_iso(),
                content_b64=None,
                symlink_target=target,
            )
        else:
            try:
                flags = os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0)
                fd = os.open(path, flags)
                with os.fdopen(fd, "rb") as source:
                    content = source.read(_MAX_FILE_BYTES + 1)
                    st = os.fstat(source.fileno())
            except OSError:
                return False
            if not stat.S_ISREG(st.st_mode):
                return False
            if len(content) > _MAX_FILE_BYTES:
                return False
            actual_hash = hashlib.sha256(content).hexdigest()
            if actual_hash != hash_value:
                return False
            candidate = ApprovalCandidate(
                event_id=event_id,
                path=path,
                status="present",
                hash=actual_hash,
                size=len(content),
                mode=oct(stat.S_IMODE(st.st_mode)),
                uid=st.st_uid,
                gid=st.st_gid,
                mtime=datetime.fromtimestamp(st.st_mtime, tz=timezone.utc).isoformat(),
                captured_at=_now_iso(),
                content_b64=base64.b64encode(content).decode(),
            )

        candidate_json = json.dumps(dataclasses.asdict(candidate)).encode()
        _atomic_write(candidate_path, _encrypt(self._key, candidate_json))
        return True
