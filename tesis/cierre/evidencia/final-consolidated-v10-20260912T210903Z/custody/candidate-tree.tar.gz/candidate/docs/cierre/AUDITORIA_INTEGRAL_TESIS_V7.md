# Auditoría integral de la tesis V7

**Objeto auditado:** `docs/cierre/Tesis_v7_cierre_tecnico.docx`  
**SHA-256:** `db6fff628bf6d17265c24c2c577673c02d41284a48248ec3ff31bd1178305d50`  
**Fecha de auditoría:** 11 de septiembre de 2026  
**Dictamen:** **Aprobada con observaciones**  
**Calificación global:** **7,5/10** (promedio bruto: **7,4612500000**; promedio de las medias capitulares expuestas: **7,4608333333**).

## Resumen ejecutivo

La V7 mejora de manera comprobable la coherencia académica y editorial de la V6 (7,2/10), sin modificar los resultados adversos. Las Figuras 1, 2 y 4 ya separan mTLS agente-backend de Valkey sin TLS verificado, retiran la atribución normativa falsa de retención ilimitada y delimitan el protocolo como entrega al menos una vez con persistencia deduplicada. La nota de Tabla 18 identifica los cortes heterogéneos; el índice separa Tabla 12 y Tabla 12a; y el Anexo G incorpora una matriz de 31 historias cuyo recuento es aritméticamente reproducible: 10 completas, 21 parciales y 0 sin cobertura. US-09 permanece parcial. La bibliografía tiene 47 entradas, está alfabetizada, incorpora localizadores y corrige la referencia de Newcombe para datos pareados.

La mejora no equivale a corroboración de la hipótesis. Continúan ausentes una ejecución consolidada sobre un commit final, una prueba de la concurrencia originalmente prevista, validación multianfitrión, TLS en Valkey, SMTP real y una distribución de repeticiones válida para el drenaje. La matriz permite recomputar estados, pero gran parte de su evidencia depende del repositorio externo y varias celdas duplican literalmente sus referencias. El objetivo específico 6 aún promete “garantía exactamente-una-vez”, aunque el desarrollo demuestra y declara una garantía más limitada.

No se identifican hallazgos críticos. Se registran **23 riesgos: 6 altos, 11 medios y 6 bajos**. Las limitaciones correctamente declaradas no se presentan como contradicciones, pero sí restringen el alcance defendible.

## Alcance, método y limitaciones de la auditoría

Se aplicó exactamente la metodología de V6: lectura completa de `document.xml`, inventario de párrafos y celdas, revisión capítulo por capítulo, evaluación metodológica transversal, contraste bibliográfico con fuentes primarias u oficiales, inspección individual de 23 tablas y 10 imágenes, análisis técnico, métricas heurísticas de escritura, registro de riesgos y puntuación por seis dimensiones.

- **Hecho verificado:** observable en el DOCX o fuente primaria.
- **Afirmación no verificable:** declarada, pero sin prueba suficiente dentro del objeto.
- **Error:** contradicción o defecto material demostrable.
- **Juicio evaluativo:** valoración académica fundada.

El ZIP del DOCX superó la prueba de integridad. LibreOffice headless falló con código 1 por no poder crear su configuración (`dconf` sobre sistema de archivos de solo lectura); por ello no se fija paginación ni se afirma ausencia de cortes visuales. Las tablas se inspeccionaron en OOXML: las 23 repiten encabezado y tienen `cantSplit` en todas sus filas. Las figuras se revisaron desde los PNG embebidos. La accesibilidad web se comprobó sólo con fuentes primarias; un DOI inaccesible o un bloqueo de red no se interpretó como inexistencia.

## Estructura, hipótesis y objetivos

La estructura de doce capítulos es lógica y completa. La hipótesis de §1.6 es explícita, falsable y conjunta; el texto correctamente concluye que no fue corroborada. Su formulación acumula funcionalidad, backlog y comparación experimental, lo que dificulta atribuir el rechazo a una dimensión concreta. Los once objetivos se trazan en Tabla 20. Persiste una contradicción terminológica en el objetivo 6: exige “garantía exactamente-una-vez”, mientras §§4.4 y 7.2 prueban sólo entrega al menos una vez y persistencia a lo sumo una vez. La aclaración posterior evita sobreafirmar resultados, pero no repara el objetivo original.

## Evaluación capítulo por capítulo

### Capítulo 1 — Introducción

**Cumple con observaciones.** Problema, alcance, criterios e hipótesis están delimitados. La baseline restaurable se ubica localmente en `/var/lib/fim-agent/baseline/` y se conserva la limitación de la clave co-residente. El objetivo 6 mantiene una garantía más fuerte que la acreditada.

### Capítulo 2 — Marco teórico y estado del arte

**Cumple.** Integra FIM, hashes, normativa, fanotify, mensajería, criptografía y amenazas con fuentes pertinentes. La comparación evita atribuir exclusividades inexistentes. No es revisión sistemática y carece de estrategia de búsqueda, limitación expresamente reconocida. La documentación oficial de [fanotify(7)](https://man7.org/linux/man-pages/man7/fanotify.7.html) confirma eventos desde Linux 5.1, capacidades adicionales y `FAN_Q_OVERFLOW`; no respalda tratar fanotify como sustituto universal de inotify.

### Capítulo 3 — Marco metodológico

**Cumple con observaciones.** Ciencia del diseño, unidad de análisis, variables, instrumentos, baterías y amenazas están explicitados. McNemar y Newcombe se aplican conceptualmente a datos pareados, pero no se ejecuta inferencia porque faltan pares y script. No hay justificación de tamaño muestral, confiabilidad interobservador ni reporte de la triangulación prevista con `tcpdump`/`strace`.

### Capítulo 4 — Desarrollo

**Cumple con observaciones.** Las Figuras 1, 2 y 4 ahora son coherentes con baseline, Valkey, retención y semántica de entrega. La arquitectura describe outbox, deduplicación, bloqueo optimista, anti-replay y autenticación sin afirmar inmunidad XSS/CSRF. El principal residuo es la denominación exactamente-una-vez en el objetivo y nombre histórico del protocolo; el cuerpo la limita correctamente.

### Capítulo 5 — Resultados

**Cumple con observaciones.** Conserva 17,274 ms y 17,745 ms como intervalos distintos, usa operaciones/s y no concurrencia, separa 153 s, 51,773 s y 29,146 s, y no suma suites. La nota de Tabla 18 identifica cada origen. Persisten evidencia fragmentada, una sola corrida válida de Run 4, 31 operaciones sin webhook en Tabla 13 y ausencia de suite final.

### Capítulo 6 — Discusión

**Cumple con observaciones.** Limita causalidad y generalización, reconoce co-residencia, Valkey sin TLS y costos no evaluados. La síntesis de licencia n8n evita un dictamen absoluto y se apoya en la Sustainable Use License oficial.

### Capítulo 7 — Conclusiones

**Cumple.** Responde a objetivos e hipótesis, declara no corroboración conjunta y no transforma pruebas dirigidas en validación integral. Mantiene indeterminadas las ausencias históricas y limita la aptitud productiva.

### Capítulo 8 — Recomendaciones y trabajo futuro

**Cumple.** Diferencia cierre de evidencia de extensiones futuras. Suite final, TLS Valkey y ensayo multianfitrión se formulan como ampliaciones de evidencia, no como reescritura retrospectiva del alcance.

### Capítulo 9 — Consideraciones éticas

**Cumple con observaciones.** Reconoce sensibilidad de diffs y cuarentena y evita inventar un código deontológico. Falta una matriz operacional de datos, finalidad, acceso, canal y retención.

### Capítulo 10 — Glosario

**Cumple con observaciones.** Es útil, pero “fanotify… sucesor técnico de inotify” e “inotify… sustituido funcionalmente por fanotify” son generalizaciones no sostenidas por la documentación oficial. Persisten anglicismos y definiciones con contenido argumentativo.

### Capítulo 11 — Referencias

**Cumple con observaciones menores.** Las 47 entradas están en una lista alfabética única; el rastreo heurístico no detectó referencias sin uso y Menezes fue retirada. Newcombe corresponde al artículo sobre proporciones pareadas. Valkey apunta a la [documentación oficial vigente](https://valkey.io/docs/) y la [Sustainable Use License de n8n](https://docs.n8n.io/n8n-community-license/sustainable-use-license.md) respondió HTTP 200 y contiene el título correspondiente. Subsisten pequeñas inconsistencias APA de tipo de documento, capitalización y fechas de recuperación de documentación versionada.

### Capítulo 12 — Anexos

**Cumple con observaciones.** La matriz tiene exactamente US-01 a US-31, sin duplicados ni faltantes, y produce 10/21/0. Las limitaciones por historia son informativas. La tabla carece de número, título y entrada en el índice; además, muchas evidencias están duplicadas dentro de la misma celda. El DOCX aislado no contiene los artefactos referidos.

## Revisión metodológica transversal

| Dimensión | Evaluación |
|---|---|
| Paradigma | Ciencia del diseño explícita y pertinente. |
| Enfoque | Cuantitativo para evaluación del artefacto, con discusión argumentativa. |
| Diseño | Comparativo sobre carga común; válido descriptivamente, insuficiente para causalidad o población. |
| Población y muestra | Operaciones generadas, no probabilísticas; sin justificación de precisión ni potencia. |
| Variables e indicadores | Operacionalizados; latencia histórica no coincide con el intervalo objetivo y se declara. |
| Instrumentos | Generador, logs, SQL, `tcpdump`, `strace`, checklist; validación principalmente autoral. |
| Estadística | Descriptiva coherente; McNemar/Newcombe identificados, no ejecutados sin pares. Sin IC de P99 ni variabilidad de Run 4. |
| Amenazas a validez | Bien explicitadas: topología local, evidencia multiversión, instrumentos internos y generalización limitada. |
| Reproducibilidad | Mejorada por matriz, rutas y commits; todavía depende del repositorio y carece de corrida final congelada. |

## Revisión individual de las 23 tablas

| Tabla | Evaluación |
|---|---|
| A | 39 siglas; encabezado repetible y contenido coherente. |
| 1 | Umbrales preestablecidos; conserva correctamente la concurrencia original. |
| 2 | Distingue norma, recomendación y documento programático. |
| 3 | STRIDE pertinente; mitigación descrita no equivale a prueba. |
| 4 | Variables trazables; cobertura del backlog sigue sin objetivo específico propio. |
| 5 | Stack detallado; versiones “verificadas” no son comprobables desde el DOCX. |
| 6 | Esquema coherente; `alerts` es persistencia de fallos, no tabla ficticia. |
| 7 | Baseline y secreto maestro correctamente reconstruidos. |
| 8 | Máquina de estados coherente. |
| 9 | Fallbacks claros; no acredita SMTP ni proveedores comerciales. |
| 10 | Separa mTLS agente-backend de Valkey sin TLS verificado. |
| 11 | Recuento 10/21/0 y límites de US-20/US-09 coherentes. |
| 12 | P99 histórico 17,274 ms; siete ausencias indeterminadas; dos `Si` sin tilde. |
| 12a | Reagregación n=493 y P99 17,745 ms, sin artefacto de cálculo dentro del DOCX. |
| 13 | Tasas 50/100 operaciones/s y estados parciales correctos; no prueba concurrencia ni explica 31 faltantes. |
| 14 | 9/11=81,8 % correcto; checklist autoral basada en NIST r2 retirado. |
| 15 | 912=418+494 y 911+1; corte histórico, no versión final. |
| 16 | 2.988/3.000 y 153 s preservados; un `Si` sin tilde. |
| 17 | 7/500 frente a 395/500 y factor “—”; comparación descriptiva. |
| 18 | Nota corregida: separa batería histórica, reagregación, matriz, causalidad y Runs 3/4. |
| 19 | mmap A/B/C n=10; no acredita inmunidad ni demora prolongada. |
| 20 | Objetivo-evidencia-limitación coherente; no declara cumplimiento integral. |
| Matriz de historias (objeto OOXML 23; sin número) | 31 filas, 10 completas/21 parciales/0 sin cobertura; evidencia repetida en numerosas celdas y falta epígrafe/indexación. |

El documento contiene 23 objetos OOXML: Tabla A, Tablas 1–20 incluyendo 12a, y la matriz no numerada de Anexo G. Todas las filas poseen `cantSplit` y todos los encabezados están configurados para repetirse.

## Revisión individual de las 10 figuras

| Figura | Evaluación |
|---|---|
| 1 | Corregida y legible: separa mTLS del transporte Valkey sin TLS y ubica baseline local. |
| 2 | Corregida: retira `version` duplicado y retención ilimitada; ER simplificado, no notación formal estricta. |
| 3 | Flujo completo pero denso; texto fino para proyección. |
| 4 | Corregida: `sent_at→received_at`, at-least-once y persistencia deduplicada; no promete efectos exactamente una vez. |
| 5 | Coherente con los siete estados, pero flechas y etiquetas oscuras sobre fondo negro tienen contraste insuficiente. |
| 6 | Captura legible; prueba presencia visual, no las condiciones del banner. |
| 7 | Toggle visible con lista vacía; no demuestra filtrado, cadena ni `parent_event_id`. |
| 8 | Termina en registros `alerts`; sin tabla `failed_notifications`. Texto interno pequeño. |
| 9 | Despliegue simplificado y legible; omite fronteras de confianza y estado TLS. |
| 10 | Componentes comprensibles; no es UML/C4 estricto y así se rotula. |

Los PNG tienen resolución suficiente en origen, pero resolución no equivale a legibilidad: Figuras 3, 5 y 8 concentran texto fino. No se evaluó su tamaño efectivo en página por el fallo de renderizado.

## Auditoría técnica independiente de la arquitectura

La separación entre agente, Valkey, backend, PostgreSQL, frontend y n8n es viable para un prototipo. Son fortalezas la deduplicación, outbox, bloqueo optimista, candidato cifrado ligado al evento y separación entre contenido restaurable local y metadatos centrales. [Valkey](https://valkey.io/docs/) confirma la existencia de documentación oficial del componente; el documento no convierte esto en verificación de TLS.

Los límites defendibles son: instancia única; dependencia de Valkey para autenticación; Valkey sin TLS en ensayos; clave maestra local; `CAP_SYS_ADMIN`; `audit_log` mutable; cola `drop-oldest`; ausencia multianfitrión y de evaluación de saturación real. La documentación de fanotify confirma que `FAN_Q_OVERFLOW` informa desborde, pero no recupera eventos perdidos.

## Resultados, discusión y conclusiones

La cadena metodológica es internamente consistente: hipótesis conjunta, criterios no redefinidos, resultados históricos adversos, verificaciones posteriores separadas, discusión limitada y conclusión no corroborativa. Es defendible afirmar latencias bajas en los intervalos documentados, entrega de los eventos efectivamente encolados y verificación dirigida de capacidades concretas. No es defendible afirmar validación integral final, concurrencia, TLS Valkey, SMTP real, alta disponibilidad, operación multianfitrión ni aptitud productiva.

## Auditoría cuantitativa de escritura científica

Método idéntico a V6: tokenización Unicode sobre texto materializado; segmentación heurística por puntuación; expresiones regulares para `se`, pasivas, `-mente` y sufijos nominales. Las métricas incluyen celdas, por lo que la nueva matriz incrementa longitud y densidad.

| Métrica | V7 | V6 | Cambio |
|---|---:|---:|---:|
| Palabras | 48.507 | 46.342 | +2.165 |
| Oraciones heurísticas | 1.660 | 1.618 | +42 |
| Media palabras/oración | 29,21 | 28,63 | +0,58 |
| Mediana | 23 | 22 | +1 |
| Oraciones >40 | 362 | 339 | +23 |
| Oraciones >50 | 219 | 199 | +20 |
| Adverbios `-mente` | 283 | 284 | −1 |
| Impersonales con `se` | 67 | 65 | +2 |
| Pasivas perifrásticas | 33 | 33 | 0 |
| Nominalizaciones | 3.125 | 3.075 | +50 |

El incremento obedece en buena medida a la matriz, pero existe una regresión mensurable de concisión. Persisten oraciones extensas y reservas acumuladas.

| Dimensión de escritura | Nota |
|---|---:|
| Claridad | 7,5 |
| Concisión | 6,2 |
| Voz activa | 7,3 |
| Fluidez | 7,2 |
| Precisión terminológica | 7,7 |
| Coherencia discursiva | 8,0 |
| Estilo científico | 7,8 |
| **Media** | **7,39** |

## Tabla completa de riesgos y hallazgos

| ID | Severidad | Problema | Ubicación exacta buscable | Evidencia / clasificación | Consecuencia para defensa | Corrección mínima |
|---|---|---|---|---|---|---|
| A-1 | Alto | Falta ejecución integral final sobre un commit. | §4.9, “Permanece pendiente una ejecución consolidada”; §7.6. | **Hecho verificado; límite declarado.** | No permite atribuir cobertura y seguridad al estado final simultáneamente. | Mantener límite o adjuntar manifiesto, JUnit y cobertura de un único commit. |
| A-2 | Alto | La hipótesis conjunta no fue corroborada. | §1.6; Tabla 18; §7.6. | **Hecho verificado, no contradicción.** | Exige defender valor de ingeniería pese al resultado global. | Exponer criterios alcanzados sin reformular la hipótesis. |
| A-3 | Alto | Reproducibilidad depende del repositorio externo. | Anexo F y rutas `docs/cierre/evidencia/...`. | **Afirmación no verificable desde el DOCX.** | Una copia aislada no permite comprobar artefactos. | Depositar repositorio/paquete y checksums institucionalmente. |
| A-4 | Alto | Notificaciones no prueban concurrencia ni explican 31 faltantes. | §5.3; Tabla 13. | **Hecho verificado; límite declarado.** | No acredita 100 solicitudes concurrentes. | Mantener parcial o ejecutar criterio original con denominador completo. |
| A-5 | Alto | Validación local y sin TLS Valkey. | §§3.7, 5.6.1, 7.6; Figura 1; Tabla 20. | **Hecho verificado; límite declarado.** | No acredita seguridad distribuida extremo a extremo. | No extrapolar; aportar ensayo multianfitrión con TLS si se amplía evidencia. |
| A-6 | Alto | Backlog integral no alcanzado: 10/21/0. | Anexo G; Tabla 20. | **Hecho verificado y recomputable.** | 21 historias no satisfacen todos sus criterios. | Defender alcance parcial; no afirmar 31/31. |
| M-1 | Medio | Run 4 tiene una sola corrida válida y margen 0,854 s. | §5.6.1, “29,146 segundos”. | **Hecho verificado.** | Resultado sensible a variabilidad. | Repetir sin modificar configuración y reportar todas las corridas. |
| M-2 | Medio | Triangulación temporal prevista no reportada. | §3.5 (`tcpdump`, `strace`); §6.4. | **Afirmación no verificable.** | No hay reloj independiente para marcas internas. | Publicar contraste o declarar instrumentos no aplicados. |
| M-3 | Medio | Checklist autoral usa NIST r2 retirado. | §§3.6, 5.4; Tabla 14. | **Hecho verificado.** | 81,8 % depende del universo autoral. | Mantener descriptivo; mapear a r3 o usar segundo evaluador. |
| M-4 | Medio | Objetivo promete exactamente-una-vez. | §1.5, “garantía exactamente-una-vez”; §4.4. | **Error de coherencia terminológica.** | Un tribunal puede exigir una garantía que el sistema no ofrece. | Reformular el objetivo como entrega al menos una vez con persistencia deduplicada, sin alterar resultados. |
| M-5 | Medio | Matriz duplica evidencia en numerosas filas. | Anexo G, por ejemplo US-01, US-04, US-06. | **Error editorial.** El mismo bloque aparece dos veces en una celda. | Aumenta volumen y favorece errores de lectura. | Eliminar duplicados conservando una única referencia por evidencia. |
| M-6 | Medio | Matriz de historias carece de epígrafe e índice. | Anexo G, tras “La matriz siguiente…”. | **Error editorial.** Es el objeto OOXML 23 sin número. | Dificulta referencia cruzada y navegación. | Asignar número/título y actualizar índice. |
| M-7 | Medio | Figura 5 tiene bajo contraste interno. | Figura 5, flechas/etiquetas grises sobre fondo negro. | **Juicio visual.** | Parte de las transiciones resulta ilegible en impresión/proyección. | Regenerar con fondo claro o contraste accesible. |
| M-8 | Medio | Figura 7 no prueba el comportamiento citado. | Figura 7, lista vacía. | **Error probatorio.** | No evidencia efecto del toggle ni `parent_event_id`. | Presentar antes/después o apoyarse sólo en pruebas dirigidas. |
| M-9 | Medio | Privacidad de diffs no operacionalizada. | §§4.7, 8.1, 9.1; US-09. | **Pendiente declarado.** | Riesgo de secretos/datos en notificaciones. | Matriz de campos, accesos, retención y minimización por canal. |
| M-10 | Medio | Versiones del stack no son verificables en el DOCX. | Tabla 5 y su nota. | **Afirmación no verificable.** | No se comprueban lockfiles ni imágenes. | Adjuntar manifiesto del snapshot. |
| M-11 | Medio | Figuras 9/10 no son UML/C4 formal. | Anexos D/H. | **Juicio evaluativo; rotuladas como simplificadas.** | Menor precisión de fronteras y protocolos. | Mantener aclaración o adoptar notación formal con leyenda. |
| B-1 | Bajo | `Si` aparece sin tilde. | Tablas 12, 14 y 16. | **Error editorial.** | Terminación desigual. | Normalizar “Sí”. |
| B-2 | Bajo | Glosario presenta sustitución universal inotify→fanotify. | Cap. 10, entradas `fanotify` e `inotify`. | **Error técnico menor.** La fuente oficial describe capacidades adicionales, no reemplazo universal. | Pregunta técnica evitable. | Reemplazar por relación complementaria y diferencias de API. |
| B-3 | Bajo | Anglicismos abundantes. | Global: `baseline`, `fallback`, `snapshot`, `payload`. | **Juicio editorial.** | Reduce uniformidad. | Aplicar política terminológica. |
| B-4 | Bajo | Epígrafes agregan volumen sin función metodológica. | Inicio de capítulos. | **Juicio evaluativo.** | Pueden percibirse ornamentales. | Retirar los no funcionales. |
| B-5 | Bajo | No se pudo fijar paginación final. | Documento completo. | **Limitación de esta auditoría.** LibreOffice falló; OOXML sí fue inspeccionado. | Cortes/viudas podrían subsistir. | Exportar en el entorno final y revisar páginas. |
| B-6 | Bajo | Concisión regresó respecto de V6. | Global; métricas heurísticas. | **Hecho cuantitativo.** +2.165 palabras y +23 oraciones >40. | Mayor carga cognitiva. | Dividir oraciones y depurar redundancias, sobre todo en matriz. |

## Calificación por capítulo

Fórmula idéntica a V6: media aritmética de las seis dimensiones aplicables con igual peso; N/A se excluye. La global es la media de las doce medias. No hay bonificación ni penalización oculta; la severidad sólo informa el dictamen.

| Cap. | Rigor | Método | Redacción | Bibliografía | APA | Coherencia | Media |
|---|---:|---:|---:|---:|---:|---:|---:|
| 1 | 8,0 | 7,8 | 7,7 | 7,3 | 7,2 | 8,1 | 7,68 |
| 2 | 8,2 | 7,6 | 7,6 | 8,3 | 7,7 | 8,0 | 7,90 |
| 3 | 8,3 | 7,6 | 7,5 | 7,9 | 7,5 | 8,0 | 7,80 |
| 4 | 7,8 | 7,4 | 7,2 | 7,0 | 7,0 | 8,2 | 7,43 |
| 5 | 7,5 | 6,8 | 7,3 | 6,9 | 6,8 | 8,0 | 7,22 |
| 6 | 7,8 | 7,2 | 7,4 | 7,7 | 7,5 | 7,7 | 7,55 |
| 7 | 8,0 | 7,5 | 7,7 | 7,0 | 7,1 | 8,3 | 7,60 |
| 8 | 7,8 | 7,4 | 7,4 | 7,0 | 7,1 | 8,0 | 7,45 |
| 9 | 7,5 | 7,0 | 7,4 | 6,7 | 7,0 | 7,8 | 7,23 |
| 10 | 7,0 | N/A | 7,2 | 6,5 | 6,8 | 6,8 | 6,86 |
| 11 | N/A | N/A | 7,3 | 8,3 | 7,9 | 7,8 | 7,83 |
| 12 | 7,5 | 7,1 | 6,7 | 6,6 | 6,8 | 7,2 | 6,98 |

**Promedio bruto:** 7,4612500000.  
**Nota final:** **7,5/10**.

## Comparación metodológicamente válida V5→V6→V7

| Versión | Nota | Cambio | Interpretación |
|---|---:|---:|---|
| V5 | 6,7 | — | Contradicciones centrales y riesgos críticos. |
| V6 | 7,2 | +0,5 | Cierre epistemológico y técnico más coherente. |
| V7 | 7,5 | +0,3 | Figuras, Tabla 18, índice, matriz y bibliografía mejoradas. |

La mejora V6→V7 es real en coherencia visual, trazabilidad autocontenida y referencias. No proviene de nuevos resultados experimentales. La diferencia residual de medición deriva de que la matriz agrega texto a las métricas y de que no se fijó paginación; las páginas no forman parte de la fórmula.

## Fortalezas, debilidades y preguntas previsibles

**Fortalezas:** honestidad epistemológica; arquitectura madura para prototipo; matriz 31/31 recomputable; Figuras 1/2/4 corregidas; Tabla 20 sólida; bibliografía verificable y alfabetizada.

**Debilidades:** ausencia de suite final; 21 historias parciales; validación local sin TLS Valkey; concurrencia no ensayada; matriz redundante y sin epígrafe; Run 4 sin replicación.

**Preguntas previsibles:**

1. ¿Qué garantiza realmente el protocolo denominado exactamente-una-vez?
2. ¿Cómo se acredita que una historia es completa si la evidencia está fuera del DOCX?
3. ¿Por qué Run 4 se acepta con una sola corrida y 0,854 s de margen?
4. ¿Qué ocurre cuando Valkey falla o circula por una red no confiable?
5. ¿Qué valor conserva la tesis si la hipótesis conjunta no fue corroborada?
6. ¿Cómo se gobierna el contenido sensible del visor de diferencias?

## Condiciones mínimas y plan priorizado

| Prioridad | Acción | Impacto | Esfuerzo |
|---|---|---|---|
| 1 | Congelar commit y ejecutar suite integral, si se busca ampliar evidencia. | Muy alto | Alto |
| 2 | Numerar la matriz y eliminar evidencia duplicada. | Alto | Bajo |
| 3 | Alinear el objetivo 6 con la garantía realmente demostrada. | Alto | Bajo |
| 4 | Repetir Run 4 sin cambiar configuración y reportar variabilidad. | Alto | Medio |
| 5 | Corregir el glosario fanotify/inotify. | Medio | Bajo |
| 6 | Regenerar Figura 5 con contraste y revisar exportación final. | Medio | Bajo |
| 7 | Aportar ensayo multianfitrión/TLS Valkey sólo como evidencia nueva. | Muy alto | Alto |

## Dictamen final

**Aprobada con observaciones.** La V7 es internamente más coherente y defendible que V6, y las correcciones principales son verificables. No alcanza nivel sobresaliente porque la cadena empírica sigue fragmentada y la hipótesis conjunta no fue corroborada. Debe defenderse como un artefacto de ingeniería evaluado parcialmente, no como validación integral ni despliegue productivo.

## Key Learnings:

1. V7 corrige los defectos materiales de las Figuras 1, 2 y 4 y la nota de Tabla 18 sin cambiar resultados.
2. La matriz de Anexo G permite recomputar 10 completas y 21 parciales, pero depende de evidencia externa, duplica referencias y no tiene epígrafe.
3. La nota comparable asciende de 7,2 a 7,5; los límites dominantes siguen siendo suite final ausente, validación local y TLS Valkey no verificado.
