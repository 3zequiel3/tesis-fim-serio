# Auditoría integral de la tesis V8

**Objeto auditado:** `docs/cierre/Tesis_v8_cierre_tecnico.docx`  
**SHA-256:** `b53a0b72870350e1783b4b56b50551c22f2a926906491b563930dfff52d93910`  
**Fecha:** 11 de septiembre de 2026  
**Calificación:** **7,6/10** (promedio bruto **7,6101388889**; desde medias capitulares expuestas **7,6100000000**)  
**Dictamen:** **Aprobada con observaciones**

## Resumen ejecutivo

V8 mejora de forma verificable la V7 (7,5/10), principalmente en precisión, auditabilidad y diseño documental. El objetivo 6 ya no promete exactamente-una-vez: especifica entrega al menos una vez con persistencia deduplicada. La Figura 5 fue regenerada con contraste y notación de máquina de estados; las Figuras 9 y 10 explicitan topología, protocolos y límites; el glosario ya presenta fanotify e inotify como APIs coexistentes. Tabla 21 incorpora un inventario de tratamiento de datos y Tabla 22 numera e indexa la matriz completa de 31 historias. Se eliminaron duplicaciones de evidencia en esa matriz. El Anexo F agrega hashes y comandos de comprobación; todos los archivos y commits allí enumerados que están disponibles en el repositorio local coinciden con los valores declarados.

La reducción de párrafos extensos es mensurable: la media baja de 29,21 a 25,39 palabras y las oraciones de más de 50 palabras de 219 a 188. El total crece a 50.081 palabras porque se agregaron inventarios de privacidad y reproducibilidad, no por mera expansión narrativa.

Las mejoras son documentales y no cambian los resultados: no existe suite final consolidada, la hipótesis conjunta no fue corroborada, 21 historias siguen parciales, las pruebas son locales, no se acreditaron concurrencia original, TLS Valkey, SMTP real ni operación multianfitrión, y Run 4 conserva una sola repetición válida. V8 registra **18 riesgos: 5 altos, 8 medios y 5 bajos; ninguno crítico**.

## Método, alcance y límites

Se aplicó exactamente el método V5–V7: lectura completa de `document.xml`, inventario OOXML, revisión de doce capítulos, veinticuatro tablas y diez figuras, revisión metodológica transversal, fuentes oficiales/primarias, arquitectura, resultados, anexos, métricas heurísticas, riesgos y seis dimensiones de puntuación con igual peso.

- **Hecho verificado:** observable en DOCX, repositorio o fuente primaria.
- **Afirmación no verificable:** declarada sin evidencia suficiente.
- **Error:** contradicción o defecto material.
- **Juicio evaluativo:** valoración académica fundada.

El DOCX es un ZIP válido. LibreOffice headless volvió a fallar con código 1 por `dconf` no escribible; no se afirma que la paginación final carezca de desbordes, viudas o cortes. En OOXML, las 24 tablas repiten encabezados y todas sus filas usan `cantSplit`. Las figuras se inspeccionaron desde los PNG. La URL oficial [Sustainable Use License de n8n](https://docs.n8n.io/n8n-community-license/sustainable-use-license.md) se considera verificada: respondió HTTP 200 y contiene `# Sustainable Use License`; no constituye un hallazgo.

## Estructura, hipótesis y objetivos

La organización de doce capítulos es lógica. La hipótesis es explícita, falsable y conjunta, pero combina suficiencia funcional y comparación experimental en una proposición amplia. V8 conserva correctamente su no corroboración. Los once objetivos específicos son trazables y el objetivo 6 ahora coincide con la semántica efectivamente demostrada. El criterio 31/31 permanece separado del árbol de objetivos y correctamente incumplido.

## Evaluación capítulo por capítulo

### Capítulo 1 — Introducción

**Cumple.** La justificación fue segmentada sin perder reservas; baseline local, secreto co-residente, alcance de laboratorio e hipótesis quedan claros. El objetivo del protocolo fue corregido sin cambiar retrospectivamente un resultado.

### Capítulo 2 — Marco teórico

**Cumple.** Integra FIM, normativa, fanotify, SOAR, mensajería y criptografía con fuentes primarias. No reclama revisión sistemática ni exclusividad. La documentación oficial de [fanotify(7)](https://man7.org/linux/man-pages/man7/fanotify.7.html) respalda las capacidades y el riesgo de overflow; no acredita por sí sola el artefacto.

### Capítulo 3 — Metodología

**Cumple con observaciones.** Ciencia del diseño, variables, instrumentos, baterías y amenazas están definidos. McNemar/Newcombe son pertinentes para pares, pero no se ejecutan sin la tabla operación por operación. Persisten falta de justificación muestral, confiabilidad interobservador y triangulación temporal publicada.

### Capítulo 4 — Desarrollo

**Cumple con observaciones.** Arquitectura, deduplicación, outbox, bloqueo optimista, candidatos cifrados, cookies y anti-replay son coherentes. La Figura 5 ahora es legible. Implementación declarada no equivale a verificación integral.

### Capítulo 5 — Resultados

**Cumple con observaciones.** Mantiene separados 17,274/17,745 ms, tasas y concurrencia, drenaje histórico/Run 3/Run 4, y baterías históricas/posteriores. La nota de Tabla 18 sigue correctamente segmentada. Continúan una sola corrida válida de Run 4, 31 operaciones sin webhook y suite final ausente.

### Capítulo 6 — Discusión

**Cumple.** Limita causalidad, generalización y licencia n8n; reconoce Valkey sin TLS, co-residencia, dependencia de autenticación y costos no medidos.

### Capítulo 7 — Conclusiones

**Cumple.** Responde objetivos e hipótesis sin declarar cumplimiento integral. No atribuye causalidad retrospectiva a las ausencias ni aptitud productiva.

### Capítulo 8 — Trabajo futuro

**Cumple.** Separa correcciones de cierre de extensiones. Suite final, TLS Valkey y multianfitrión amplían evidencia; no reescriben el alcance original.

### Capítulo 9 — Ética

**Cumple con observaciones.** Tabla 21 convierte un pendiente genérico en inventario por canal y distingue controles implementados de pendientes. Expone riesgos reales: cola local sin cifrado, token SSE en query, acceso amplio al detalle y retención externa no definida.

### Capítulo 10 — Glosario

**Cumple.** Corrige fanotify/inotify como tecnologías complementarias. Persisten anglicismos, pero están definidos.

### Capítulo 11 — Referencias

**Cumple con observaciones menores.** Conserva 47 entradas alfabéticas, todas con localizador; no se detectaron huérfanas heurísticas. Newcombe corresponde a datos pareados, Valkey apunta a su [documentación oficial](https://valkey.io/docs/) y n8n a la SUL válida. Persisten detalles menores APA en capitalización y clasificación documental.

### Capítulo 12 — Anexos

**Cumple con observaciones.** Anexo F agrega un manifiesto útil y honesto; los hashes/commits declarados fueron comprobados en la copia local. Tabla 22 está numerada, indexada, sin IDs faltantes o duplicados y produce 10/21/0. Los hashes identifican bytes disponibles, pero no crean una suite final ni un depósito institucional inmutable. Las imágenes de contenedor permanecen fijadas por etiqueta, no digest.

## Revisión metodológica transversal

| Dimensión | Evaluación |
|---|---|
| Paradigma | Ciencia del diseño explícita y pertinente. |
| Enfoque | Cuantitativo de evaluación de artefacto más discusión argumentativa. |
| Diseño | Comparativo descriptivo; insuficiente para causalidad o inferencia poblacional. |
| Población y muestra | Operaciones generadas no probabilísticas; sin fundamento de tamaño/potencia. |
| Variables | Bien operacionalizadas; intervalos históricos diferentes se mantienen separados. |
| Instrumentos | Generador, logs, SQL y checklist; validación principalmente autoral. |
| Estadística | Descriptiva correcta; inferencia pareada pendiente por ausencia de datos originales. |
| Validez | Amenazas internas/externas declaradas con precisión. |
| Reproducibilidad | Mejorada con hashes y comandos; incompleta sin suite final, digests, SBOM y depósito estable. |

## Revisión individual de las 24 tablas

| Tabla | Evaluación |
|---|---|
| A | 39 siglas; correcta. |
| 1 | Umbrales preestablecidos; conserva concurrencia original. |
| 2 | Distingue obligaciones y recomendaciones. |
| 3 | STRIDE pertinente; mitigación no equivale a prueba. |
| 4 | Indicadores trazables; backlog sin objetivo propio. |
| 5 | Stack detallado; ahora complementado por manifiesto, sin digests de imágenes. |
| 6 | Esquema coherente y sin tabla ficticia. |
| 7 | Baseline/secreto correctamente delimitados. |
| 8 | Máquina de estados coherente. |
| 9 | Fallbacks claros; no acredita SMTP/proveedores. |
| 10 | Separa mTLS agente-backend y Valkey sin TLS. |
| 11 | Estado 10/21/0 coherente. |
| 12 | P99 histórico 17,274 ms; siete ausencias indeterminadas; `Si` sin tilde. |
| 12a | P99 posterior 17,745 ms, n=493; intervalo distinto. |
| 13 | 50/100 operaciones/s; no concurrencia; 31 faltantes sin causa. |
| 14 | 9/11=81,8 %; checklist autoral sobre NIST r2 retirado. |
| 15 | 912=418+494; corte histórico. |
| 16 | 2.988/3.000 y 153 s preservados; `Si` sin tilde. |
| 17 | 7/500 frente a 395/500; factores retirados. |
| 18 | Orígenes heterogéneos explícitos; no agrega suites. |
| 19 | mmap n=10 por caso; no prueba inmunidad ni demora adversarial. |
| 20 | Objetivo/evidencia/límite consistente. |
| 21 | Inventario de nueve canales/artefactos, con controles y pendientes separados. Es muy ancha y densa. |
| 22 | Matriz US-01..US-31: 10 completas/21 parciales; evidencia duplicada corregida. |

Inventario: Tabla A + Tablas 1–22 incluyendo 12a = 24 objetos OOXML. Tabla 21 tiene seis columnas y celdas extensas; sin render no se acredita legibilidad final, aunque encabezados repetidos y filas indivisibles reducen el riesgo de corte.

## Revisión individual de las 10 figuras

| Figura | Evaluación |
|---|---|
| 1 | Correcta: mTLS y Valkey separados; baseline local. |
| 2 | ER simplificado coherente; sin retención falsa ni `version` duplicado. |
| 3 | Flujo correcto, pero texto fino y denso. |
| 4 | `sent_at→received_at`; al menos una vez + persistencia deduplicada. |
| 5 | Regenerada con alto contraste, nodo inicial, estados y leyenda. Cumple como UML simplificado. |
| 6 | Captura legible; existencia visual, no prueba de condiciones. |
| 7 | Lista vacía: no demuestra efecto del toggle ni `parent_event_id`. |
| 8 | Finaliza en `alerts`; texto interno pequeño. |
| 9 | Topología y límites visibles. El título interno dice “diagrama UML”, mientras el epígrafe niega formalidad UML/C4. |
| 10 | Componentes y canales más claros. Presenta la misma tensión título interno “UML”/epígrafe informativo. |

## Auditoría técnica independiente

La arquitectura es viable para prototipo y presenta decisiones maduras: deduplicación, outbox, bloqueo optimista, baseline restaurable local cifrada y separación de evidencia. Figura 9 muestra correctamente que las corridas Valkey usaron TCP sin TLS y que mTLS corresponde al canal agente-backend.

Persisten: instancia única, Valkey como dependencia de autenticación, transporte Valkey no cifrado, clave local, `CAP_SYS_ADMIN`, `audit_log` sin depuración, cola `drop-oldest` y ausencia multianfitrión. Tabla 21 añade riesgos concretos que mejoran la honestidad: HMAC no cifra, la cola local contiene el payload completo, el token SSE viaja en query y los receptores externos carecen de política común acreditada.

## Resultados, discusión y conclusión

La cadena metodológica continúa coherente: criterios fijos, resultados adversos preservados, verificaciones posteriores separadas y conclusión no corroborativa. Es defendible afirmar comportamiento en los ensayos identificados. No lo es afirmar sistema final integral, concurrencia, TLS Valkey, SMTP comercial, alta disponibilidad, multianfitrión ni aptitud productiva.

## Auditoría cuantitativa de escritura

Mismo parser y heurísticas que V7; la nueva Tabla 21 y el manifiesto agregan contenido tabular.

| Métrica | V8 | V7 | Cambio |
|---|---:|---:|---:|
| Palabras | 50.081 | 48.507 | +1.574 |
| Oraciones | 1.971 | 1.660 | +311 |
| Media palabras/oración | 25,39 | 29,21 | −3,82 |
| Mediana | 20 | 23 | −3 |
| >40 palabras | 327 | 362 | −35 |
| >50 palabras | 188 | 219 | −31 |
| Adverbios `-mente` | 290 | 283 | +7 |
| Impersonales `se` | 68 | 67 | +1 |
| Pasivas perifrásticas | 40 | 33 | +7 |
| Nominalizaciones | 3.182 | 3.125 | +57 |

| Dimensión de escritura | Nota |
|---|---:|
| Claridad | 7,9 |
| Concisión | 7,3 |
| Voz activa | 7,4 |
| Fluidez | 7,7 |
| Precisión terminológica | 8,0 |
| Coherencia discursiva | 8,2 |
| Estilo científico | 8,0 |
| **Media** | **7,79** |

Las oraciones más cortas mejoran lectura. El aumento de pasivas y nominalizaciones impide considerar resuelto el estilo en términos absolutos.

## Tabla completa de riesgos

| ID | Severidad | Problema | Ubicación buscable | Evidencia / clasificación | Consecuencia | Corrección mínima |
|---|---|---|---|---|---|---|
| A-1 | Alto | No existe suite final sobre commit limpio. | §4.9; §7.6; Anexo F.3. | **Hecho verificado y declarado.** | No atribuye resultados simultáneos al estado final. | Mantener límite o ejecutar suite con JUnit, cobertura y manifiesto. |
| A-2 | Alto | Hipótesis conjunta no corroborada. | §1.6; Tabla 18; §7.6. | **Hecho, no contradicción.** | Defensa debe explicar valor pese al resultado. | Presentar criterios sin reformular hipótesis. |
| A-3 | Alto | Notificaciones no prueban concurrencia y omiten 31 casos. | §5.3; Tabla 13. | **Hecho y límite declarado.** | No acredita 100 concurrentes. | Mantener parcial o ejecutar criterio original. |
| A-4 | Alto | Evaluación local y sin TLS Valkey. | §§3.7, 5.6.1, 7.6; Figura 9. | **Hecho y límite declarado.** | No acredita seguridad distribuida extremo a extremo. | No extrapolar; ensayo nuevo multianfitrión/TLS. |
| A-5 | Alto | Backlog integral no alcanzado: 10/21/0. | Tabla 22; Tabla 20. | **Hecho recomputable.** | 21 historias incumplen criterios. | Defender cobertura parcial; no afirmar 31/31. |
| M-1 | Medio | Run 4: una corrida válida y margen 0,854 s. | §5.6.1, “29,146 segundos”. | **Hecho.** | Resultado frágil ante variabilidad. | Repetir sin cambiar configuración. |
| M-2 | Medio | Triangulación temporal no reportada. | §3.5 (`tcpdump`, `strace`). | **No verificable.** | Falta reloj independiente. | Publicar contraste o declarar no aplicación. |
| M-3 | Medio | Checklist autoral sobre NIST r2 retirado. | §§3.6, 5.4; Tabla 14. | **Hecho.** | 81,8 % depende del universo autoral. | Mantener descriptivo; mapear a r3/segundo evaluador. |
| M-4 | Medio | Tratamiento de diffs conserva controles pendientes. | Tabla 21, filas agente/Valkey/API/SSE. | **Hecho y pendiente declarado.** | Posible exposición de contenido y tokens. | Cifrar cola, restringir detalle, evitar query token y fijar retención. |
| M-5 | Medio | Manifiesto no equivale a snapshot final reproducible. | Anexo F.1–F.3. | **Hecho declarado.** Hashes verificados, pero cortes distintos y worktree modificado. | No reconstruye un sistema final único. | Depósito inmutable, digests, SBOM y commit limpio. |
| M-6 | Medio | Tabla 21 es extremadamente densa. | Tabla 21, seis columnas. | **Juicio editorial.** | Riesgo de ilegibilidad/paginación. | Usar orientación horizontal o dividir por canal. |
| M-7 | Medio | Figura 7 no prueba US-31. | Figura 7, lista vacía. | **Error probatorio.** | No muestra efecto del toggle. | Antes/después o sólo prueba automatizada. |
| M-8 | Medio | Figuras 9/10 mezclan rótulo UML e informal. | Títulos internos y epígrafes de Figuras 9/10. | **Error de coherencia gráfica.** | Ambigüedad sobre notación exigible. | Alinear título interno con “representación informativa” o formalizar UML. |
| B-1 | Bajo | `Si` sin tilde. | Tablas 12, 14 y 16. | **Error editorial.** | Terminación desigual. | Normalizar “Sí”. |
| B-2 | Bajo | Texto fino en Figuras 3 y 8. | Figuras 3 y 8. | **Juicio visual.** | Difícil proyección. | Simplificar/ampliar. |
| B-3 | Bajo | Anglicismos abundantes. | Global: `baseline`, `fallback`, `snapshot`. | **Juicio editorial.** | Registro menos uniforme. | Aplicar política terminológica. |
| B-4 | Bajo | Epígrafes ornamentales. | Inicios de capítulos. | **Juicio evaluativo.** | Agregan volumen no metodológico. | Retirar los no funcionales. |
| B-5 | Bajo | Paginación no verificada. | Documento completo. | **Límite de auditoría.** LibreOffice falló. | Pueden subsistir cortes visuales. | Exportar y revisar en entorno final. |

## Calificación por capítulo

Fórmula idéntica: media aritmética de seis dimensiones aplicables; N/A se excluye. Global = media de doce medias. Sin ajustes externos.

| Cap. | Rigor | Método | Redacción | Bibliografía | APA | Coherencia | Media |
|---|---:|---:|---:|---:|---:|---:|---:|
| 1 | 8,1 | 7,9 | 8,0 | 7,4 | 7,3 | 8,4 | 7,85 |
| 2 | 8,3 | 7,7 | 7,8 | 8,3 | 7,7 | 8,2 | 8,00 |
| 3 | 8,3 | 7,6 | 7,7 | 7,9 | 7,5 | 8,0 | 7,83 |
| 4 | 8,0 | 7,6 | 7,5 | 7,1 | 7,1 | 8,5 | 7,63 |
| 5 | 7,5 | 6,8 | 7,5 | 6,9 | 6,8 | 8,1 | 7,27 |
| 6 | 7,8 | 7,2 | 7,6 | 7,7 | 7,5 | 7,8 | 7,60 |
| 7 | 8,0 | 7,5 | 7,8 | 7,0 | 7,1 | 8,4 | 7,63 |
| 8 | 7,8 | 7,4 | 7,6 | 7,0 | 7,1 | 8,0 | 7,48 |
| 9 | 7,8 | 7,4 | 7,7 | 7,0 | 7,3 | 8,2 | 7,57 |
| 10 | 7,3 | N/A | 7,5 | 6,7 | 6,9 | 7,5 | 7,18 |
| 11 | N/A | N/A | 7,3 | 8,3 | 7,9 | 7,8 | 7,83 |
| 12 | 7,9 | 7,5 | 7,2 | 7,0 | 7,1 | 8,0 | 7,45 |

**Promedio bruto:** 7,6101388889.  
**Nota final:** **7,6/10**.

## Comparación V7→V8

| Aspecto | V7 | V8 | Interpretación |
|---|---:|---:|---|
| Nota | 7,5 | 7,6 | +0,1 por precisión, trazabilidad y legibilidad; no por resultados nuevos. |
| Riesgos | 23 | 18 | Objetivo 6, matriz, glosario, Figura 5 y manifiesto mejorados. |
| Historias | 10/21/0 | 10/21/0 | Sin cambio empírico. |
| Suite final | Ausente | Ausente | Límite dominante. |
| Hipótesis | No corroborada | No corroborada | Resultado preservado. |

La comparación es válida porque conserva parser, dimensiones y fórmula. El aumento de texto proviene de dos tablas/manifiesto; la caída de longitud oracional es mejora real. La paginación no puntúa.

## Fortalezas, debilidades y preguntas de defensa

**Fortalezas:** honestidad epistemológica; arquitectura madura; objetivos alineados; matrices 21/22 útiles; manifiesto verificable; figuras corregidas; escritura más segmentada.

**Debilidades:** evidencia multiversión, 21 historias parciales, entorno local, Valkey sin TLS, concurrencia ausente, Run 4 no replicado y controles de privacidad pendientes.

**Preguntas previsibles:**

1. ¿Qué impide afirmar que la versión final fue validada integralmente?
2. ¿Qué aporta el manifiesto si los ensayos pertenecen a snapshots diferentes?
3. ¿Cómo se protege `diff_text` en cola, Valkey, API y receptores?
4. ¿Por qué Run 4 cumple con una sola corrida y margen estrecho?
5. ¿Qué valor mantiene la tesis si la hipótesis conjunta no se corroboró?
6. ¿Son las Figuras 9/10 UML o representaciones informativas?

## Plan priorizado

| Prioridad | Acción | Impacto | Esfuerzo |
|---|---|---|---|
| 1 | Suite final sobre commit limpio con JUnit/cobertura/manifiesto. | Muy alto | Alto |
| 2 | Repetir Run 4 y ejecutar concurrencia original. | Alto | Medio/alto |
| 3 | Resolver controles pendientes de Tabla 21. | Alto | Medio |
| 4 | Alinear rótulos de Figuras 9/10 y verificar Tabla 21 renderizada. | Medio | Bajo |
| 5 | TLS Valkey y multianfitrión sólo como evidencia adicional. | Muy alto | Alto |
| 6 | Limpieza editorial final (`Sí`, texto fino, anglicismos). | Bajo | Bajo |

## Dictamen final

**Aprobada con observaciones.** V8 es más precisa, trazable y legible que V7. No alcanza un nivel sobresaliente porque el núcleo empírico no cambió: no hay suite final, la hipótesis no fue corroborada y quedan validaciones decisivas fuera del alcance observado. Debe defenderse como artefacto de ingeniería evaluado parcialmente, no como sistema productivo validado de extremo a extremo.

## Key Learnings:

1. V8 corrige objetivo 6, Figura 5, glosario, numeración de matriz y aporta un manifiesto cuyos hashes disponibles coinciden.
2. Tabla 21 mejora la ética aplicada al revelar riesgos concretos de `diff_text`, cola, Valkey, API y SSE, sin presentarlos como resueltos.
3. La nota comparable asciende a 7,6; suite final, hipótesis, backlog parcial y validación local siguen limitando el dictamen.
