# Auditoría integral de la tesis FIM — versión V5 de cierre técnico aplicado

## Veredicto y alcance

**Dictamen único: Aprobada con observaciones mayores.**  
**Calificación técnica-documental estimada: 6,7/10.**

La tesis presenta un artefacto técnicamente ambicioso, una arquitectura razonada y una conducta académica valiosa al conservar resultados adversos y distinguir varias verificaciones posteriores. Sin embargo, esta versión no está lista para una defensa sin correcciones: conserva contradicciones materiales sobre la baseline, autenticación y cobertura del backlog; mezcla estados históricos y posteriores en tablas de síntesis; contiene tablas severamente dañadas; mantiene una figura reconocidamente incorrecta; y no aporta dentro del documento los datos primarios suficientes para reproducir varias conclusiones cuantitativas. El principal riesgo no es que los resultados sean desfavorables, sino que el tribunal no pueda reconstruir de forma inequívoca qué versión, intervalo, protocolo y evidencia respaldan cada afirmación.

### Objeto exacto auditado

- Archivo: `/home/ezequiel/Facultad/tesis/devoluciones de la tesis/versiones/v3/Tesis_v5_cierre_tecnico_aplicado (1).docx`
- SHA-256: `65c8055038e5838144ee90503e8904005f02a401d9a3c1dfc7924836159fc971`
- Renderizado de control: 149 páginas A4.
- Inventario: 12 capítulos, 22 objetos de tabla —incluida la lista tabular de siglas—, 21 leyendas numeradas de tablas porque se añadió “Tabla 12a”, y 10 figuras.

Esta auditoría se limita al contenido del DOCX. Los commits, scripts, rutas de evidencias y matrices que el texto menciona no fueron tratados como prueba observada cuando el documento no incorporó su contenido verificable. Se distingue:

- **Hecho verificado:** observable en el DOCX, su XML o su renderizado.
- **Afirmación no verificable:** declarada por el documento, pero sin evidencia primaria suficiente dentro del objeto auditado.
- **Error:** contradicción, dato incorrecto, artefacto roto o inferencia que excede la evidencia.
- **Juicio evaluativo:** valoración académica razonada del tribunal simulado.

## Resumen ejecutivo

### Resultado central

La hipótesis conjunta no queda corroborada. El propio texto reconoce que el criterio de 31/31 historias no fue alcanzado, que la concurrencia prevista no fue ensayada, que el drenaje histórico incumplió y que las verificaciones posteriores corresponden a versiones diferenciadas. Esa honestidad es una fortaleza. No obstante, la Tabla 20 y el párrafo posterior vuelven a afirmar que los once objetivos fueron atendidos en diseño e implementación y que su dimensión de evaluación “se cumplió”, lo que contradice las limitaciones que el mismo capítulo enumera.

### Hallazgos determinantes

1. **La cadena de evidencia no está consolidada.** Hay batería histórica, Coverage Run 3, corrida causal, Run 3, Run 4 y verificaciones dirigidas en commits distintos; falta una ejecución final sobre un único estado del código.
2. **La Tabla 4 está estructuralmente rota.** Encabezados y primera fila se fusionaron; varias columnas quedaron desplazadas. Es la tabla central de operacionalización y, tal como se renderiza en las páginas 48–49, no es defendible.
3. **La baseline se describe de dos maneras incompatibles.** §1.3 afirma que se traslada fuera del anfitrión; §4.4 y §9.1 sostienen que el contenido restaurable permanece cifrado localmente. Además, la Tabla 10 conserva la ruta obsoleta `/opt/fim-agent/storage/baseline/`, frente a `/var/lib/fim-agent/baseline/`.
4. **El estado de US-09 y del backlog no está unificado.** §5.5.1 informa US-09 posterior y matriz 4/27, pero §4.6, Tabla 18, Tabla 20 y Anexo G conservan “no implementada”, “código no alcanzable” y 2/28/1 sin marcar siempre el carácter histórico.
5. **Resultados de carga y latencia exceden el alcance de los ensayos.** Tabla 13 llama “concurrentes” a tasas secuenciales de emisión; el P99 histórico de 17,274 ms y la reagregación de 17,745 ms miden intervalos diferentes; Tabla 17 conserva factores de mejora como si fueran intervalos homogéneos.
6. **La bibliografía estadística no respalda el método que el texto dice necesitar.** La referencia de Newcombe incluida trata una proporción individual; no es el artículo de diferencias pareadas que §3.6 y §5.7 invocan.
7. **La calidad visual es desigual.** Las imágenes tienen resolución efectiva suficiente (315–351 ppp), pero varias contienen texto demasiado pequeño; la Figura 7 muestra un listado vacío y no demuestra la cadena `parent_event_id`; la Figura 8 conserva un modelo de datos incorrecto y una instrucción editorial interna.

## Evaluación capítulo por capítulo

### Capítulo 1 — Introducción (p. 15–24)

**Valoración: 6,92/10.** El problema está bien contextualizado y los criterios fueron formulados antes de la medición, una decisión metodológicamente sana. La hipótesis es falsable y conjunta. El defecto grave aparece en §1.3: la frase “la baseline se traslada fuera del anfitrión monitoreado” contradice el diseño descripto después, donde el contenido restaurable queda cifrado localmente y el servidor centraliza metadatos, hashes y resoluciones. También se formula como objetivo una garantía “exactamente-una-vez” que §4.4 reduce correctamente a entrega al menos una vez con persistencia deduplicada. El objetivo debe usar desde el inicio esa semántica acotada.

El criterio de “100 solicitudes concurrentes” es válido como criterio previsto, pero no fue ejecutado; esta distinción debe preservarse en todas las síntesis. Los fundamentos de algunos umbrales son operativos y plausibles, pero no aparecen derivados de bibliografía o de necesidades de un contexto de uso concreto. En especial, 30 segundos de drenaje carece de volumen asociado, defecto que el propio §5.6.1 reconoce.

### Capítulo 2 — Marco teórico (p. 25–44)

**Valoración: 7,55/10.** Es el capítulo más sólido: diferencia hashing, cifrado y autenticación; presenta límites de fanotify; delimita normativas obligatorias de referencias orientativas; y evita atribuir originalidad científica a componentes conocidos. La página de manual oficial confirma que fanotify no reporta modificaciones originadas por `mmap(2)`, `msync(2)` y `munmap(2)` y advierte pérdida de eventos por overflow ([Linux man-pages, `fanotify(7)`](https://man7.org/linux/man-pages/man7/fanotify.7.html)).

Persisten tres problemas. Primero, §2.5 y §6.7 hacen afirmaciones negativas amplias sobre capacidades ausentes en Falco y Tetragon basadas en documentación consultada, no en revisión sistemática ni ensayo funcional; la reserva existe, pero debe mantenerse cerca de cada afirmación. Segundo, el texto califica n8n y otros componentes dentro de un ecosistema “de código abierto”, aunque n8n utiliza una licencia de uso sostenible con restricciones comerciales: corresponde hablar de código disponible o *fair-code* en ese caso. Tercero, §2.6 describe correctamente una evasión determinística para un orden preciso de operaciones, mientras §1.7 y §6.5 la vuelven una “ventana temporal” o condición de carrera. El fenómeno debe explicarse con una sola causalidad: ausencia de eventos por escrituras mapeadas y detección indirecta eventual a partir de otro evento de cierre.

### Capítulo 3 — Marco metodológico (p. 45–56)

**Valoración: 6,72/10.** El encuadre en ciencia del diseño es pertinente y el texto distingue evaluación del artefacto de inferencia poblacional. Sin embargo, llamar al esquema “diseño experimental con grupo de control” resulta más fuerte que la práctica documentada: no hay asignación aleatoria, unidades independientes ni replicación entre anfitriones. La denominación más precisa es evaluación comparativa controlada o *benchmark* pareado bajo laboratorio.

La unidad de análisis se define como operación de archivo, pero las operaciones comparten rutas, ventanas y estado; por ello no son observaciones estadísticamente independientes. El documento reconoce la estructura pareada para detección, pero no discute dependencia temporal y agrupamiento por ruta para latencias. Los tamaños de 500, 3.000 y 1.000 planificados no tienen análisis de potencia, precisión esperada ni justificación basada en estabilidad de percentiles. La corrida real de notificaciones se apartó de la planificación y produjo 360 operaciones/329 muestras.

La operacionalización falla editorialmente: la Tabla 4 es ilegible y sus definiciones quedan desplazadas. Además, §3.6 define la latencia objetivo como (a) fin de modificación → (c) recepción backend, pero el P99 histórico mide (b) recepción por el agente → (c), mientras la reagregación posterior parte de una marca posterior a la operación. No son el mismo estimando. La tabla de pares necesaria para McNemar no está incluida. El instrumento de triage fue construido y evaluado por los autores, sin segundo evaluador, y se apoya en SP 800-61r2, retirada por NIST el 3 de abril de 2025 y sustituida por r3 ([NIST SP 800-61 Rev. 2](https://csrc.nist.gov/pubs/sp/800/61/r2/final)).

### Capítulo 4 — Desarrollo (p. 57–86)

**Valoración: 6,45/10.** El capítulo explica con buen nivel de detalle la arquitectura, las transacciones, la bandeja de salida, la máquina de estados, la cola offline y el alcance real de “exactamente-una-vez”. La distinción entre monolito modular backend y componentes desplegables es defendible, aunque la etiqueta global “microservicios” debería justificarse por independencia de despliegue y propiedad de datos, no sólo por separación en contenedores.

Las contradicciones editoriales son numerosas. §4.6 afirma `SameSite=Strict` y, en el párrafo siguiente, que la matriz registra `SameSite=Lax; Path=/`. La misma frase contiene “con atributos Secure, atributos de cookie…”, un error de edición, y llama al código del visor “no alcanzable” aunque §5.5.1 afirma que US-09 se incorporó después. La redacción general “mitiga conjuntamente XSS, clickjacking y CSRF” debe acotarse: CSP, `httpOnly`, `SameSite` y validación de origen reducen vectores específicos, no producen inmunidad.

La Figura 7 no muestra eventos, por lo cual no evidencia US-31 ni la exposición de la cadena `superseded`. La Figura 8 admite en su propia nota que rotula una tabla `failed_notifications` inexistente y todavía incluye la instrucción “La figura debe regenerarse”. Las Tablas 7, 10 y 11 contienen texto partido entre celdas. La Tabla 10 usa una ruta de baseline diferente de §4.4. La nota de la Figura 1 dice que la comunicación agente-servidor se realiza sobre mTLS, aunque el texto distingue un canal mTLS agente-backend y transporte Valkey sin TLS en las corridas.

Todas las cantidades de líneas, módulos, pruebas, commits y rutas de evidencia son **afirmaciones no verificables desde este DOCX**. El propio documento debe enlazar un manifiesto inmutable o incorporar un anexo mínimo de procedencia.

### Capítulo 5 — Resultados (p. 87–103)

**Valoración: 6,18/10.** La mayor fortaleza es conservar fallos e incertidumbres: 7 operaciones históricas sin evento, 12 diferencias en resiliencia, drenaje histórico de 153 s y Run 3 de 51,773 s. También se evita reclasificar retrospectivamente las 19 ausencias con la corrida causal posterior.

La validez está limitada por la fragmentación de versiones. El 89,35 % corresponde a Coverage Run 3, con 2.484/2.780 sentencias, sin ramas y sobre un snapshot anterior a cambios posteriores; no puede extrapolarse al estado final. Los 912 casos históricos no incluyen una validación frontend integral ni prueban 31 historias. La matriz de cierre documentada en esta versión —4 completas, 27 parciales y 0 sin cobertura funcional— es más informativa que el recuento histórico de 2 completas, 28 parciales y 1 sin cobertura, pero tampoco equivale a calidad funcional global.

La Tabla 13 presenta “50 concurrentes” y “100 concurrentes”, mientras el texto aclara que fueron 50 y 100 operaciones/s mediante bucle secuencial; ambos “Cumple” sólo se refieren al umbral temporal del receptor local, no al criterio de concurrencia ni a la recepción externa. Tabla 17 tiene la fila de operaciones sin evento desplazada entre columnas y factores de mejora basados en intervalos que no son plenamente equivalentes. El control cron mide tiempo hasta el siguiente sondeo; FIM usa un tramo interno o una marca posterior al generador. El cociente es descriptivo, no una mejora extremo a extremo validada.

Run 4 cumple 29,146 s por un margen de 0,854 s en una única corrida válida, con eventos preencolados, rutas únicas, límite 100.000/min, transporte local sin TLS y sin repetir la desconexión de cinco minutos. Es evidencia útil del trayecto de drenaje, no de resiliencia integral ni de estabilidad bajo repetición.

### Capítulo 6 — Discusión (p. 104–112)

**Valoración: 7,00/10.** La discusión es cauta, reconoce validez interna/externa limitada y evita presentar aptitud productiva. Separa resultados históricos y posteriores mejor que las tablas. El mayor problema de coherencia es que §6.2 vuelve a hablar de “copia central de la baseline”, reactivando la contradicción de §1.3. Debe decir centralización de metadatos, hashes y resoluciones, mientras la baseline restaurable permanece local.

La discusión sobre `mmap` mezcla “no observó evasión” con una evasión determinística descripta en §2.6. Las diez repeticiones de A sólo demuestran que, en ese entorno, el hash diferido se ejecutó después de la escritura; no invalidan la vía de evasión ni permiten modelar su probabilidad. También se afirma que una revisión de seguridad interna encontró 27 hallazgos, pero el documento no reproduce el registro; por eso es procedencia declarada, no evidencia inspeccionable.

### Capítulo 7 — Conclusiones (p. 113–118)

**Valoración: 6,55/10.** La conclusión contiene reservas maduras: no presenta la hipótesis conjunta como corroborada, no suma baterías heterogéneas y delimita ausencia de validación multianfitrión. Sin embargo, la Tabla 20 conserva pendientes obsoletos y estados históricos, y el párrafo siguiente declara que los once objetivos “se atendieron” en diseño e implementación y que su evaluación “se cumplió”. Esa oración no es compatible con objetivos parciales, pruebas dirigidas, criterios incumplidos y componentes sólo especificados/exportables.

La conclusión correcta debería discriminar por objetivo: alcanzado documentalmente, implementado según el informe, verificado en snapshot, evaluado bajo laboratorio, parcial o no acreditado. No debe usar una oración agregada de cumplimiento. La propia frase “el registro acredita que fueron detectados… no que su totalidad permanezca corregida” es un buen modelo epistemológico para todo el capítulo.

### Capítulo 8 — Recomendaciones y trabajo futuro (p. 119–123)

**Valoración: 7,10/10.** La distinción entre correcciones de cierre y extensiones futuras es clara. Son pertinentes la consolidación de suites, la revisión de concurrencia, la separación TLS agente-backend/Valkey, la repetición del drenaje y el despliegue multianfitrión.

No obstante, §8.1 aún contiene tareas editoriales internas (“regenerar las figuras afectadas”) y evidencia faltante que debería resolverse antes de presentar la versión como cerrada. La mención a “identificación del código deontológico” no aparece resuelta. Debe evitarse convertir extensiones —alta disponibilidad, TPM, Tetragon, SIEM— en defectos del alcance original.

### Capítulo 9 — Consideraciones éticas (p. 124–126)

**Valoración: 6,58/10.** El capítulo trata minimización, divulgación responsable y uso declarado de IA. La incorporación del diff textual como dato potencialmente sensible es correcta. Sin embargo, faltan una matriz concreta de datos, finalidad, retención, acceso y supresión; y una discusión específica de cómo los fallbacks de notificación podrían transmitir rutas, fragmentos o contenido a terceros. La ley exige medidas técnicas y organizativas, pero el documento no debe convertir la plataforma en acreditación de cumplimiento jurídico.

### Capítulo 10 — Glosario (p. 127–134)

**Valoración: 6,68/10.** Es amplio y útil, aunque extenso para términos ya definidos en el cuerpo. Algunas entradas son promocionales o absolutas: “Docker es la plataforma de contenedores más difundida” no tiene fuente; “TLS 1.3… reemplaza a TLS 1.2” necesita mayor precisión operacional; y “microservicio” debería alinearse con la arquitectura realmente desplegada. La entrada fanotify denomina al subsistema “sucesor técnico de inotify”, simplificación discutible porque son interfaces coexistentes con alcances diferentes.

### Capítulo 11 — Referencias (p. 135–140)

**Valoración: 6,50/10.** Se identificaron 48 entradas; 40 incluyen URL o DOI. La mayoría de los estándares, normas y artículos clave existen y las citas principales tienen correspondencia. La organización por seis categorías, aunque legible, no es la lista alfabética única habitual de APA 7. Varias entradas institucionales carecen de URL aun cuando son recursos web (IBM, Mandiant, Verizon), y la documentación dinámica se fecha sin versión archivada ni fecha de recuperación.

El error sustantivo es Newcombe: la referencia incluida es *Two-sided confidence intervals for the single proportion* (17(8), 857–872), pero el cuerpo necesita *Improved confidence intervals for the difference between binomial proportions based on paired data* (17(22), 2635–2650, DOI `10.1002/(SICI)1097-0258(19981130)17:22<2635::AID-SIM954>3.0.CO;2-C`) ([artículo correcto en Wiley](https://onlinelibrary.wiley.com/doi/10.1002/%28SICI%291097-0258%2819981130%2917%3A22%3C2635%3A%3AAID-SIM954%3E3.0.CO%3B2-C)). Menezes et al. (1996) aparece sin cita detectada en el cuerpo. Las referencias de software deben precisar versión cuando sostienen conducta específica.

### Capítulo 12 — Anexos (p. 141–149)

**Valoración: 6,03/10.** Los anexos explican flujos y configuración, pero no hacen reproducible el experimento. Anexo F remite a repositorio, commits y evidencias sin incorporar manifiesto, comandos, hashes de archivos ni datos primarios suficientes. Anexo G conserva “US-09 no implementada” y 2 completas/28 parciales/1 sin cobertura, mientras el cuerpo registra 4/27 posteriores. Figura 9 y Figura 10 son claras como diagramas simplificados, pero no usan una notación UML/C4 formal completa; eso es aceptable si se las denomina vistas informales y se agrega una leyenda rigurosa.

No se identifica reparto verificable de responsabilidades entre los dos autores ni cronograma ejecutado. No es posible exigirlos sin reglamento institucional, pero un tribunal puede preguntar por autoría individual y gestión del proyecto.

## Revisión metodológica transversal

| Dimensión | Evaluación | Riesgo |
|---|---|---|
| Paradigma | Ciencia del diseño es adecuada para construir y evaluar el artefacto. | Bajo. |
| Enfoque | Cuantitativo para criterios; argumentativo para diseño. No es mixto formal. | Bajo. |
| Diseño | Comparación controlada pareada en un único anfitrión; no sostiene causalidad ni generalización. | Alto si se lo llama “experimental” sin matiz. |
| Población | No hay población probabilística definida; la carga es sintética y diseñada. | Alto para cualquier extrapolación. |
| Unidad de análisis | Operación de archivo, con dependencia por ruta, ventana y estado. | Alto para inferencia que asuma independencia. |
| Muestra | Tamaños seleccionados sin potencia ni precisión objetivo; desviación entre plan y ejecución. | Alto. |
| Variables | Definiciones conceptuales razonables, pero Tabla 4 rota e intervalos temporales inconsistentes. | Crítico. |
| Instrumentos | Generador y checklist propios; piloto declarado, sin datos del piloto ni evaluación externa. | Alto. |
| Estadística | Descriptivos suficientes para laboratorio; inferencia pareada no ejecutable sin pares. | Alto. |
| Validez interna | Amenazas reconocidas; relojes, topología y estados entre corridas no totalmente controlados. | Alto. |
| Validez externa | Delimitación explícita a anfitrión único, sin TLS Valkey ni canales comerciales. | Alto pero honestamente reconocido. |
| Reproducibilidad | Rutas y commits declarados; faltan artefactos incorporados, manifiesto final y corrida consolidada. | Crítico. |

## Auditoría individual de tablas

| Objeto | Página(s) | Estado y observación |
|---|---:|---|
| Lista de abreviaturas | 13–14 | Legible. “CNC” y algunos nombres institucionales deben verificarse contra la denominación normativa vigente. |
| Tabla 1 | 22 | Legible. El criterio “100 solicitudes concurrentes” debe conservarse como previsto e incumplido, no confundirse con tasa. El umbral de drenaje carece de volumen asociado. |
| Tabla 2 | 30–31 | Legible, con buen cuidado sobre alcance normativo. “Obligación legal” debe atribuirse a sujetos alcanzados, no al producto. |
| Tabla 3 | 41–42 | Visualmente apretada. Varias “mitigaciones” son diseño declarado, no eficacia verificada; cambiar la columna o agregar estado de prueba. |
| Tabla 4 | 48–49 | **Rota.** Encabezados y primera fila fusionados, palabras partidas y desplazamiento de columnas. Debe reconstruirse, no sólo ensancharse. |
| Tabla 5 | 59–60 | Legible. Versiones requieren manifiesto de fecha/snapshot. El guion de Docker/Compose no es versión. |
| Tabla 6 | 62–63 | Legible. Consistente al indicar que fallos se materializan en `alerts`. |
| Tabla 7 | 65–66 | **Rota:** “secreto ma” / “estro Baseline ilegible”. Corregir el contenido de celdas. |
| Tabla 8 | 71 | Legible y coherente con la máquina de estados. |
| Tabla 9 | 78 | Legible. “Persistencia final” no prueba entrega; especificar que es registro de fallo. |
| Tabla 10 | 80 | **Rota:** “no integri” / “dad) Streams Valkey”. Ruta obsoleta `/opt/...`; además mezcla mTLS agente-backend con integridad de eventos transportados por Valkey. |
| Tabla 11 | 86 | **Rota:** “inacti” / “vo”. Mezcla implementación declarada, pruebas y evaluaciones posteriores; necesita columna de corte/commit. |
| Tabla 12 | 88–89 | Legible. El “Cumple” de P99 sólo aplica al tramo histórico (b)→(c), no a la latencia objetivo (a)→(c). |
| Tabla 12a | 89 | Legible. No está en el índice de tablas. La marca post-operación y los datos originales deben enlazarse. |
| Tabla 13 | 90 | **Semánticamente incorrecta:** 50/100 “concurrentes” fueron 50/100 operaciones/s secuenciales. Los “Cumple” no acreditan concurrencia ni entrega externa. |
| Tabla 14 | 91–92 | Muy densa, texto excesivamente estrecho. El 81,8 % depende de una checklist propia sobre una norma retirada; requiere reserva metodológica visible en la tabla. |
| Tabla 15 | 93 | Legible. Cuenta casos de prueba, no historias ni cobertura final. |
| Tabla 16 | 94–95 | **Rota:** fila de precedencia comandos/eventos desplazada; “Si-” y “Si” sin tilde. El 100 % es 2.988/2.988 encolados, no 3.000/3.000 operaciones. |
| Tabla 17 | 97–98 | **Rota:** tercera fila desplazada. Debe quedar FIM `7 de 500 (1,4 %; causa indeterminada)`, control `395 de 500 (79,0 %)`, factor `—`. Retirar o acotar cocientes de latencia. |
| Tabla 18 | 99–101 | Legible pero contradictoria: conserva US-09 no implementada y 2/28/1 junto a estado posterior 4/27; “intervalo pendiente de precisar” contradice §3.6, que ya diferencia intervalos. |
| Tabla 19 | 102 | Legible. Diez repeticiones por caso son caracterización limitada, no estimación robusta de probabilidad de evasión. |
| Tabla 20 | 113–116 | Visualmente densa y semánticamente desactualizada: conserva copia de restauración no especificada, 90,3 %/discrepancia, intervalo impreciso y US-09 no implementada. Mezcla cortes de evidencia. |

**Conclusión tabular:** se cubrieron los 22 objetos XML. El índice enumera 20 tablas, pero el cuerpo tiene 21 leyendas numeradas porque se añadió Tabla 12a; debe actualizarse el índice. Las tablas 4, 7, 10, 11, 16 y 17 requieren reparación de celdas; 13, 18 y 20 requieren corrección semántica.

## Auditoría individual de figuras

| Figura | Página | Resolución efectiva | Evaluación |
|---|---:|---:|---|
| 1. Arquitectura | 58 | 336 ppp | Buena resolución. Rótulos pequeños. La nota sobre mTLS sobre-generaliza: debe separar API mTLS de Valkey sin TLS en las corridas. |
| 2. Entidad-relación | 62 | 351 ppp | Legible a zoom; cardinalidades y atributos pequeños en impresión. Es un extracto, no esquema completo. |
| 3. Flujo del agente | 64 | 322 ppp | Coherente; texto interno pequeño. La concurrencia entre fases debe leerse como diseño declarado. |
| 4. Secuencia ACK | 68 | 329 ppp | Coherente con persistencia deduplicada. El nombre “exactamente-una-vez” sigue siendo riesgoso aun con nota aclaratoria. |
| 5. Estados | 70 | 315 ppp | Coherente con Tabla 8; etiquetas pequeñas pero recuperables. |
| 6. Dashboard | 74 | 328 ppp | Resolución suficiente; texto UI muy pequeño. Sólo evidencia manual de esa pantalla/snapshot. |
| 7. Eventos | 75 | 328 ppp | **No prueba lo que afirma la nota:** el listado aparece vacío; no se ve cadena `superseded` ni `parent_event_id`. |
| 8. Fallbacks | 76 | 315 ppp | **Incorrecta:** representa `failed_notifications` como tabla/entidad independiente. Mantiene una nota de trabajo editorial. Debe rehacerse. |
| 9. Despliegue | 145 | 351 ppp | Clara como vista simplificada. Debe diferenciar topología recomendada de topología experimental real. |
| 10. Componentes | 149 | 351 ppp | Clara como vista simplificada; no es UML/C4 formal. Faltan responsabilidades/interfaz más precisas. |

La inspección visual alcanzó todas las páginas que contienen tablas o figuras y sus continuaciones. La resolución raster no es el problema principal: lo son el tamaño tipográfico interno, la falta de evidencia visual en Figura 7 y el contenido incorrecto de Figura 8.

## Revisión técnica independiente de arquitectura

### Fortalezas verificables como diseño documentado

- Separación explícita entre agente, backend, PostgreSQL, Valkey, n8n y frontend.
- Persistencia deduplicada por UUID sobre transporte al menos una vez.
- Bandeja de salida transaccional para evitar divergencia DB/mensajería.
- Máquina de estados y bloqueo optimista para resolución humana.
- Baseline local cifrada con limitación explícita ante compromiso privilegiado.
- Separación conceptual entre mTLS de canal y HMAC de mensaje.
- Reconocimiento de dependencia dura de Valkey en autenticación.

### Reservas técnicas

- “Microservicios ligeramente acoplados” no queda demostrado por contenedores; el backend es monolito modular y comparte dependencias centrales.
- El agente accede a Valkey además del backend; la frontera de confianza y autenticación de esa conexión no está representada de modo consistente.
- La cola `drop-oldest` de 100 MB contradice cualquier garantía absoluta de preservación bajo presión; la propiedad sólo vale mientras no se alcance el límite.
- El XACK seguido por `event_ack` conserva ventanas de reentrega; la deduplicación protege el registro, no todos los efectos laterales.
- `parent_event_id` y candidato local reducen carreras, pero no forman una transacción distribuida con el sistema de archivos.
- La PKI propia no acredita validación de revocación en cada handshake; el texto lo reconoce.
- El secreto de baseline co-residente limita el beneficio del cifrado ante root; protege principalmente soportes o copias parciales.
- Los fallbacks pueden aumentar superficie de fuga: payload, ruta y diff requieren minimización por canal.
- La topología de laboratorio no valida latencia, disponibilidad ni seguridad del despliegue distribuido propuesto.

## Resultados, discusión y conclusiones

### Qué puede sostenerse

- **Hecho verificado en el documento:** se reportan 912 casos históricos, 911 aprobados y uno omitido; 493 eventos correlacionados sobre 500 operaciones; 2.988 eventos entregados de 2.988 encolados; drenajes de 153 s, 51,773 s y 29,146 s bajo condiciones distintas; y una matriz posterior 4/27.
- **Juicio evaluativo:** esos datos son coherentes como relato de resultados parciales y preservan fallos, pero no son auditables integralmente sin archivos primarios.
- **Afirmación no verificable:** que todos los commits, manifiestos, JUnit, trazas y scripts mencionados contienen exactamente la evidencia declarada.
- **Error:** presentar tasas como concurrencia, usar factores entre intervalos distintos, mantener US-09 como no implementada en síntesis vigentes y declarar cumplida la evaluación de todos los objetivos.

### Hipótesis

La hipótesis es conjuntiva; basta un criterio no alcanzado para no corroborarla. El documento finalmente reconoce esto, y esa conclusión debe dominar todas las tablas y resúmenes. No corresponde promediar criterios ni usar avances posteriores heterogéneos para transformar el veredicto.

## Bibliografía y verificación externa

### Existencia y correspondencia

Las fuentes centrales verificadas existen: [RFC 8446](https://www.rfc-editor.org/rfc/rfc8446) para TLS 1.3; [RFC 5869](https://www.rfc-editor.org/rfc/rfc5869) para HKDF; [RFC 9106](https://www.rfc-editor.org/rfc/rfc9106) para Argon2; [FIPS 180-4](https://csrc.nist.gov/pubs/fips/180-4/upd1/final) para SHA-256; [NIST SP 800-207](https://csrc.nist.gov/pubs/sp/800/207/final) para Zero Trust; [NIST SP 800-61r2/r3](https://csrc.nist.gov/pubs/sp/800/61/r2/final); la documentación oficial de [fanotify](https://man7.org/linux/man-pages/man7/fanotify.7.html); [Valkey Streams](https://valkey.io/topics/streams-intro/); y la [Ley argentina 25.326](https://www.argentina.gob.ar/normativa/nacional/ley-25326-64790/texto).

Las referencias de IBM, Mandiant y Verizon carecen de enlace en la bibliografía; no se cuestiona su existencia, pero debe agregarse el URL editorial verificable. ISO/IEC 27002 y PCI DSS pueden carecer de URL en APA, pero deben conservar edición exacta. Para documentación viva, conviene consignar versión y fecha de recuperación o enlazar una versión archivada.

### APA 7

- Reordenar en una única lista alfabética si el reglamento institucional no exige agrupación temática.
- Aplicar sangría francesa uniforme.
- Corregir Newcombe al artículo pareado efectivamente invocado.
- Agregar DOI como URL `https://doi.org/...` y evitar caracteres sin codificar que rompan hipervínculos.
- Revisar el uso de siglas como autor (`AAIP`, `CNCF`, `NIST`) frente al nombre corporativo de la referencia.
- Eliminar Menezes et al. si no se cita, o incorporar una cita sustantiva donde realmente respalde una afirmación.
- Completar URLs de reportes institucionales sin inventar metadatos.

## Auditoría cuantitativa de escritura

| Métrica | Resultado | Interpretación |
|---|---:|---|
| Palabras | 46.744 | Extensión alta pero compatible con una tesis técnica con anexos. |
| Oraciones (heurística) | 1.585 | Segmentación aproximada. |
| Longitud media | 29,48 palabras | Elevada; aumenta carga cognitiva. |
| Mediana | 23 palabras | Más razonable que la media; hay cola larga. |
| Oraciones >40 palabras | 356 | 22,5 % aproximado; requiere edición. |
| Oraciones >50 palabras | 209 | 13,2 % aproximado; riesgo claro de densidad. |
| Adverbios en `-mente` | 291 | No es defecto por sí mismo; revisar acumulaciones. |
| Construcciones impersonales con `se` | 66 | Heurística conservadora. |
| Pasivas perifrásticas | 31 | Uso moderado; no domina el texto. |
| Nominalizaciones por sufijo | 3.100 | Heurística muy amplia; señala densidad nominal, no 3.100 defectos. |

### Calidad de escritura

| Dimensión | Nota |
|---|---:|
| Claridad | 6,6 |
| Concisión | 5,8 |
| Voz activa | 7,1 |
| Fluidez | 6,7 |
| Precisión terminológica | 6,5 |
| Coherencia discursiva | 6,2 |
| Estilo científico | 7,0 |
| Media | 6,56 |

La prosa es formal y generalmente precisa, pero muchas oraciones integran tesis, reserva, excepción y consecuencia en un solo período. El problema no es el vocabulario técnico, sino la densidad sintáctica. Deben priorizarse §1.3, §3.4–3.7, §4.4–4.8, §5.6–5.9 y §7.1. También persisten anglicismos no normalizados (`baseline`, `graceful`, `crash`, `fallback`, `payload`, `snapshot`) y un error sin espacio en §1.3: “inexistencia.El”.

## Tabla completa de riesgos y hallazgos

| ID | Severidad | Problema | Ubicación | Evidencia / clasificación | Consecuencia para defensa | Corrección mínima |
|---|---|---|---|---|---|---|
| C-1 | Crítico | Evidencia fragmentada por versiones y sin corrida final consolidada. | §3.7, §4.9, §5, §7.6, Anexo F. | **Hecho verificado:** el texto distingue batería histórica, Coverage Run 3 y verificaciones posteriores. | No se puede afirmar estado final del sistema ni reproducir un resultado global. | Congelar commit y ejecutar suites/coverage/manifiesto final; si no se hace, limitar toda conclusión al snapshot correspondiente. |
| C-2 | Crítico | Tabla de operacionalización destruida. | Tabla 4, pp. 48–49. | **Error visual/XML:** encabezados y celdas fusionados/desplazados. | El tribunal no puede reconstruir variables, unidades, umbrales y baterías. | Reconstruir tabla desde cero y verificarla en PDF. |
| C-3 | Crítico | Baseline central/local contradictoria y rutas incompatibles. | §1.3, §4.4, §6.2, §9.1, Tabla 10. | **Error:** “se traslada fuera” frente a contenido restaurable local; `/opt/...` frente a `/var/lib/...`. | Debilita la arquitectura de confianza y la restauración. | Establecer una sola verdad: contenido restaurable cifrado local; servidor con metadatos/hashes/resoluciones; ruta `/var/lib/fim-agent/baseline/`. |
| C-4 | Crítico | US-09/backlog con estados incompatibles. | §4.6, §5.5.1, Tabla 18, Tabla 20, Anexo G. | **Error:** no implementada/código no alcanzable/2-28-1 frente a implementación posterior/4-27. | Impide saber el alcance real y parece manipulación de resultados aunque sea arrastre editorial. | Marcar explícitamente corte histórico o actualizar todas las síntesis a 4/27 con evidencia y sin afirmar 31/31. |
| C-5 | Crítico | Conclusión agregada excede la matriz. | §7.1, párrafo posterior a Tabla 20. | **Error:** dice que evaluación de once objetivos se cumplió pese a parciales/no acreditados. | Riesgo directo de objeción por sobreafirmación. | Reescribir objetivo por objetivo con categorías de evidencia y retirar el cumplimiento integral. |
| A-1 | Alto | Contradicción `SameSite=Strict`/`Lax; Path=/` y frase dañada. | §4.6, pp. 73–74. | **Error.** El alcance y la eliminación coherente mediante `Path` están definidos en [RFC 6265](https://www.rfc-editor.org/rfc/rfc6265). | Debilita afirmaciones de hardening y trazabilidad requisito-implementación. | Registrar `Lax; Path=/` como evidencia actual y `Strict`/ruta restringida como criterio previsto, o incorporar prueba posterior. |
| A-2 | Alto | Tasas etiquetadas como concurrencia. | Tabla 13 y §5.3, p. 90. | **Error:** el texto admite bucle secuencial a 50/100 ops/s. | Un tribunal puede invalidar el criterio de carga. | Cambiar a operaciones/s y declarar concurrencia no evaluada. |
| A-3 | Alto | Latencia objetivo e histórica miden intervalos distintos. | §3.6, Tabla 12, Tabla 12a, Tabla 18. | **Error de coherencia:** 17,274 ms (b→c) vs. 17,745 ms (marca post-operación→c). | Los “Cumple” y comparaciones no responden al mismo estimando. | Definir inicio/fin por tabla y reservar cumplimiento del criterio (a→c) hasta datos reproducibles. |
| A-4 | Alto | Factores de mejora entre intervalos no equivalentes. | Tabla 17 y §5.7. | **Juicio evaluativo respaldado:** control hasta sondeo vs. FIM tramo interno/post-operación. | Cocientes parecen mejora extremo a extremo validada. | Retirar factores o marcarlos descriptivos con diferencia de alcance. |
| A-5 | Alto | Tabla 20 conserva pendientes obsoletos. | Tabla 20, pp. 113–116. | **Error:** copia no especificada, 90,3 %, intervalo impreciso, US-09 no implementada. | La matriz de cierre contradice el desarrollo. | Sustituir por limitaciones vigentes y separar cortes históricos/posteriores. |
| A-6 | Alto | Tablas con celdas desplazadas. | Tablas 7, 10, 11, 16 y 17. | **Error visual/XML.** | Presentación no profesional y riesgo de interpretación errónea. | Corregir contenido de celdas y rerenderizar. |
| A-7 | Alto | Figura 8 usa entidad inexistente y contiene instrucción editorial. | Figura 8, p. 76. | **Error reconocido por el propio texto.** | Contradice el esquema de persistencia. | Regenerar con registros `alerts`; eliminar la nota de trabajo. |
| A-8 | Alto | Pruebas dirigidas tratables como evidencia demasiado amplia. | Resumen, §4.12, §5.5, §7. | **Afirmación no verificable:** commits y artefactos no están incorporados. | Confusión entre implementado, probado puntualmente y validado integralmente. | Añadir tabla de evidencia por commit, alcance y resultado; prohibir agregación entre suites. |
| A-9 | Alto | Referencia estadística equivocada. | §3.6, §5.7, Ref. Newcombe (1998). | **Error bibliográfico:** artículo de proporción individual, no diferencia pareada ([Newcombe, 1998, artículo pareado](https://onlinelibrary.wiley.com/doi/10.1002/%28SICI%291097-0258%2819981130%2917%3A22%3C2635%3A%3AAID-SIM954%3E3.0.CO%3B2-C)). | El método inferencial queda sin fuente correcta. | Reemplazar por Newcombe 1998, 17(22), 2635–2650; no calcular sin pares originales. |
| A-10 | Alto | Drenaje final sin repetición y margen mínimo. | §5.6.1. | **Hecho verificado:** Run 4 único, 29,146 s, configuración modificada. | No hay variabilidad ni robustez del cumplimiento. | Repetir sin cambiar configuración; informar distribución y todos los intentos válidos. |
| A-11 | Alto | Ausencias históricas sin causalidad contemporánea. | §5.2, §5.6, §7.6. | **Afirmación no verificable:** retornos a baseline compatibles, no demostrados. | Riesgo de reclasificar falsos negativos. | Mantener causa indeterminada; no usar corrida causal posterior retrospectivamente. |
| A-12 | Alto | mTLS agente-backend confundible con TLS Valkey. | Figura 1, Tabla 10, §4.8, §7.6. | **Error de representación:** corridas Valkey sin TLS. | Sobreafirmación de seguridad de transporte. | Dibujar dos canales y estados de verificación separados. |
| A-13 | Alto | Evaluación n8n no equivale a SMTP/proveedores reales. | §4.7, Tabla 9, Tabla 20. | **Hecho verificado:** receptor controlado y retardos nulos. | No acredita canal externo ni política temporal nominal. | Rotular como integración controlada; dejar SMTP/comerciales no acreditados. |
| A-14 | Alto | Figura 7 no evidencia US-31. | Figura 7, p. 75. | **Error probatorio:** lista vacía. | La “comprobación manual” no demuestra cadena/parent. | Reemplazar por captura con cadena visible o retirar la afirmación probatoria. |
| A-15 | Alto | Uso persistente de “exactamente-una-vez”. | Objetivo 6, Figura 4, §4.4. | **Error terminológico acotado por el propio texto.** | Puede interpretarse como garantía de efectos laterales. | Renombrar “entrega al menos una vez con persistencia deduplicada”. |
| A-16 | Alto | Checklist de triage autocreada y basada en revisión retirada. | §3.6, Tabla 14. | **Hecho verificado:** sin evaluador independiente; SP 800-61r2 retirada ([NIST](https://csrc.nist.gov/pubs/sp/800/61/r2/final)). | 81,8 % depende del denominador autoral. | Conservar como caracterización; migrar/mapping a r3 o validar por segundo evaluador. |
| A-17 | Alto | Sin justificación cuantitativa del tamaño muestral. | §3.4, §3.7. | **Hecho verificado:** se informan tamaños, no potencia/precisión. | Percentiles y cero fallos pueden aparentar más certeza de la disponible. | Justificar por precisión/estabilidad o declarar exploratorio-descriptivo. |
| A-18 | Alto | Reproducibilidad depende de recursos externos no incorporados. | Anexo F. | **Afirmación no verificable.** | Un lector del DOCX aislado no reproduce resultados. | Añadir manifiesto, comandos, hashes, esquemas y enlaces permanentes. |
| A-19 | Alto | Figura 1/9 mezclan topología propuesta y ejecutada. | Figuras 1 y 9; §3.7. | **Error de comunicación:** agente nativo en diseño, contenedor en ensayo. | Confusión sobre qué se evaluó. | Añadir dos vistas: despliegue objetivo y laboratorio real. |
| M-1 | Medio | Bibliografía agrupada temáticamente, no lista APA única. | Cap. 11. | **Juicio evaluativo.** | Observación formal posible. | Ajustar al reglamento; por defecto, lista alfabética única con sangría francesa. |
| M-2 | Medio | Reportes institucionales sin URL. | Refs. IBM, Mandiant, Verizon. | **Hecho verificado.** | Dificulta comprobación. | Incorporar enlaces editoriales oficiales. |
| M-3 | Medio | Referencia no usada. | Menezes et al. (1996). | **Hecho heurístico:** sin cita detectada. | Inconsistencia cita-bibliografía. | Citar sustantivamente o retirar. |
| M-4 | Medio | Prosa excesivamente densa. | Global; 356 oraciones >40 palabras. | **Métrica heurística.** | Reduce claridad en defensa y revisión. | Dividir períodos extensos, una afirmación y una reserva por oración. |
| M-5 | Medio | Índice de tablas desactualizado. | Índice, p. 10; Tabla 12a, p. 89. | **Error:** 20 entradas frente a 21 leyendas numeradas. | Referenciación incompleta. | Actualizar campo de índice y numeración. |
| M-6 | Medio | Texto interno pequeño en figuras. | Figuras 1–8. | **Juicio visual:** ppp suficiente, tipografía reducida. | Ilegibilidad impresa/proyectada. | Aumentar fuente o dividir figuras. |
| M-7 | Medio | Generalización negativa sobre Falco/Tetragon. | §6.7. | **Juicio evaluativo:** basada en documentación, no evaluación sistemática. | Riesgo de refutación por funcionalidades extensibles/versiones. | Limitar a versión/documentación consultada y fecha. |
| M-8 | Medio | Caracterización simplificada de licencia n8n. | §6.6. | **Error potencial:** “prohíbe reventa o incorporación” es demasiado general; licencias comerciales permiten casos ([n8n, licencia oficial](https://docs.n8n.io/n8n-community-license/sustainable-use-license.md)). | Objeción legal/técnica. | Describir SUL y necesidad de licencia comercial según uso, sin conclusión jurídica absoluta. |
| M-9 | Medio | Relación normativa a veces suena a fundamento directo del producto. | §2.4, §10.2. | **Juicio evaluativo:** la Ley 25.326 obliga al responsable, no prescribe FIM. | Riesgo de afirmar cumplimiento jurídico. | Usar “contribuye a” y “posible medida”, no “fundamento legal directo de adoptar FIM”. |
| M-10 | Medio | Privacidad de diffs/fallbacks no operacionalizada. | §4.7, §9.1. | **Hecho verificado:** se reconoce el riesgo, falta matriz. | Fuga de contenido sensible por canales. | Documentar campos, minimización, cifrado, acceso y retención por canal. |
| M-11 | Medio | Sin reparto de responsabilidades entre autores. | Portada/anexos. | **Hecho verificado:** no localizado. | Pregunta previsible del tribunal. | Incorporar contribuciones verificables si el reglamento o director lo requieren. |
| M-12 | Medio | Afirmaciones de “originalidad” o rareza sin revisión sistemática. | §1.3, §6.2, §7.2. | **Juicio evaluativo:** el texto añade reservas, pero conserva lenguaje fuerte. | Riesgo de antecedente omitido. | Reemplazar “original” por “contribución de ingeniería en el alcance consultado”. |
| B-1 | Bajo | Error de espaciado. | §1.3: “inexistencia.El”. | **Error editorial.** | Mala terminación. | Insertar espacio y separar párrafo. |
| B-2 | Bajo | Tildes, guiones y signos inconsistentes. | Tablas 12, 16; versiones. | **Error editorial:** “Si”, “Si-”, guiones como N/A. | Ruido visual. | Normalizar “Sí”, “—” y notación. |
| B-3 | Bajo | Anglicismos abundantes. | Global. | **Juicio editorial.** | Inconsistencia de registro. | Definir una vez, usar español o cursiva consistentemente. |
| B-4 | Bajo | Epígrafes literarios no siempre atribuibles. | Inicios de capítulos. | **Hecho verificado:** varias “formulaciones de los autores”. | Añaden volumen sin rigor. | Retirar los no funcionales o justificar estilo institucional. |
| B-5 | Bajo | Numeración preliminar en arábigos. | pp. 1–14. | **Juicio condicionado:** depende del reglamento UTN-FRM. | Observación formal posible. | Contrastar con plantilla/reglamento; no cambiar sin fuente institucional. |
| B-6 | Bajo | Glosario incluye afirmaciones comparativas sin fuente. | Cap. 10. | **Error menor:** “más difundida”, “sucesor técnico”. | Objeción terminológica. | Definir neutralmente y citar cuando corresponda. |

## Calificación por capítulo

La fórmula usa media aritmética de seis dimensiones aplicables: rigor científico, metodología, redacción, bibliografía, APA 7 y coherencia interna. Las dimensiones no aplicables se excluyen del denominador del capítulo; luego se promedian por igual los 12 capítulos. No se aplicó penalización oculta por hallazgos críticos.

| Capítulo | Rigor | Método | Redacción | Bibliografía | APA | Coherencia | Media |
|---|---:|---:|---:|---:|---:|---:|---:|
| 1 | 7,5 | 7,0 | 7,2 | 7,0 | 6,8 | 6,0 | 6,92 |
| 2 | 8,0 | 7,5 | 7,3 | 8,0 | 7,0 | 7,5 | 7,55 |
| 3 | 7,0 | 6,2 | 6,8 | 7,0 | 6,8 | 6,5 | 6,72 |
| 4 | 7,0 | 6,8 | 6,3 | 6,5 | 6,3 | 5,8 | 6,45 |
| 5 | 6,3 | 5,5 | 6,6 | 6,5 | 6,5 | 5,7 | 6,18 |
| 6 | 7,2 | 6,8 | 7,0 | 7,0 | 6,8 | 7,2 | 7,00 |
| 7 | 6,8 | 6,5 | 7,2 | 6,5 | 6,5 | 5,8 | 6,55 |
| 8 | 7,8 | 7,0 | 7,3 | 6,5 | 6,5 | 7,5 | 7,10 |
| 9 | 7,0 | 6,5 | 7,0 | 6,0 | 6,0 | 7,0 | 6,58 |
| 10 | 6,8 | N/A | 7,2 | 6,5 | 6,2 | 6,7 | 6,68 |
| 11 | N/A | N/A | 6,5 | 7,2 | 5,8 | 6,5 | 6,50 |
| 12 | 6,5 | 6,0 | 6,6 | 5,5 | 5,8 | 5,8 | 6,03 |
| **Global** |  |  |  |  |  |  | **6,69 → 6,7** |

## Fortalezas principales

- Transparencia al conservar resultados adversos e indeterminados.
- Buena separación conceptual entre implementación, ensayo histórico y verificaciones posteriores en varios pasajes narrativos.
- Arquitectura con decisiones de consistencia y resiliencia bien explicadas.
- Delimitación explícita de la semántica de entrega y de efectos laterales.
- Reconocimiento de amenazas a validez y ausencia de aptitud productiva demostrada.
- Marco teórico técnico mayormente respaldado por estándares y documentación oficial.
- Resolución gráfica suficiente y estructura documental completa.

## Debilidades principales

- Falta de evidencia final consolidada sobre una versión congelada.
- Tablas metodológicas y de resultados rotas o semánticamente obsoletas.
- Contradicciones de baseline, autenticación, US-09 y cobertura.
- Inferencia estadística pendiente y referencia de Newcombe incorrecta.
- Ensayos de concurrencia, distribución, TLS Valkey y canales externos no realizados.
- Reproducibilidad dependiente de artefactos externos no incorporados.
- Densidad sintáctica y notas de trabajo aún presentes.

## Preguntas previsibles del tribunal

1. ¿Dónde reside exactamente el contenido restaurable y qué conserva el servidor central?
2. ¿Qué commit único representa la versión defendida y qué suites completas pasaron sobre él?
3. ¿Por qué el documento llama concurrentes a tasas de emisión secuencial?
4. ¿Qué instante inicia la latencia de detección y cuál de los dos P99 responde al criterio?
5. ¿Cómo se explica que US-09 esté implementada en §5.5.1 pero no implementada en Anexo G y Tabla 20?
6. ¿Qué evidencia demuestra US-31 si la Figura 7 muestra una lista vacía?
7. ¿Por qué se denomina exactamente-una-vez a una entrega al menos una vez con deduplicación?
8. ¿Puede reconstruirse la tabla pareada necesaria para McNemar?
9. ¿Por qué se eligieron 500 y 3.000 operaciones y qué incertidumbre tienen los percentiles?
10. ¿Qué parte del sistema se probó con TLS y qué parte siguió en claro?
11. ¿Qué contenido transmiten n8n y los fallbacks, y cómo se protege un diff sensible?
12. ¿Qué prueba sustenta que el drenaje de 29,146 s es estable y no un mejor caso?
13. ¿Cuál fue la contribución específica de cada autor?
14. ¿Qué cambia al desplegar agente y backend en anfitriones distintos?
15. ¿Por qué la conclusión declara evaluados todos los objetivos si la hipótesis conjunta no se corroboró?

## Condiciones mínimas para mejorar el dictamen

1. Reparar todas las tablas rotas y rehacer Figura 8.
2. Unificar baseline, autenticación y estado US-09/backlog en todo el documento.
3. Corregir Tabla 13, intervalos de latencia y Tabla 17.
4. Sustituir la referencia de Newcombe y no informar inferencia sin pares originales.
5. Reescribir Tabla 20 y su conclusión sin cumplimiento integral.
6. Incorporar un manifiesto verificable de evidencia por commit o ejecutar una corrida final consolidada.
7. Actualizar índices, referencias cruzadas y retirar instrucciones internas.

## Plan priorizado por impacto y esfuerzo

| Prioridad | Acción | Impacto | Esfuerzo |
|---|---|---:|---:|
| 1 | Reconstruir Tablas 4, 7, 10, 11, 16 y 17; corregir 13, 18 y 20. | Muy alto | Medio |
| 2 | Unificar baseline, rutas, SameSite y US-09 mediante búsqueda global. | Muy alto | Bajo |
| 3 | Reescribir §7.1 para reflejar resultados parciales por objetivo. | Muy alto | Bajo |
| 4 | Congelar versión y ejecutar validación consolidada con JUnit, coverage y manifiesto. | Muy alto | Alto |
| 5 | Corregir latencias, tasas/concurrencia y factores comparativos. | Alto | Medio |
| 6 | Rehacer Figura 8 y sustituir Figura 7 por evidencia real o limitar su nota. | Alto | Medio |
| 7 | Corregir Newcombe, URLs institucionales y APA. | Alto | Bajo |
| 8 | Repetir Run 4 y caracterizar variabilidad sin modificar configuración. | Alto | Alto |
| 9 | Ejecutar prueba reducida multianfitrión con topología y relojes documentados. | Alto | Alto |
| 10 | Editar oraciones >40 palabras y normalizar terminología. | Medio | Medio |

## Limitaciones de esta auditoría

- No se inspeccionó el repositorio como sustituto del DOCX ni se aceptaron recuerdos conversacionales como evidencia.
- No se ejecutaron los experimentos ni las suites que el documento menciona.
- Las métricas lingüísticas son heurísticas; no sustituyen análisis sintáctico manual.
- La resolución de imágenes se midió sobre archivos embebidos y tamaño de presentación; la legibilidad se juzgó sobre el PDF renderizado.
- No se contó con el reglamento formal de presentación de UTN-FRM; observaciones de paginación y formato quedan condicionadas a ese documento.
- La comprobación web se concentró en fuentes primarias críticas y en la correspondencia sustantiva; no constituye dictamen jurídico ni auditoría de licencias.

## Fuentes primarias y autoritativas consultadas

1. Linux man-pages project, [fanotify(7): Limitations and caveats](https://man7.org/linux/man-pages/man7/fanotify.7.html).
2. NIST, [SP 800-61 Rev. 2 — retirada y sustituida por Rev. 3](https://csrc.nist.gov/pubs/sp/800/61/r2/final) y [SP 800-61 Rev. 3](https://csrc.nist.gov/pubs/sp/800/61/r3/final).
3. Newcombe, R. G., [Improved confidence intervals for the difference between binomial proportions based on paired data](https://onlinelibrary.wiley.com/doi/10.1002/%28SICI%291097-0258%2819981130%2917%3A22%3C2635%3A%3AAID-SIM954%3E3.0.CO%3B2-C).
4. IETF, [RFC 8446 — TLS 1.3](https://www.rfc-editor.org/rfc/rfc8446).
5. IETF, [RFC 5869 — HKDF](https://www.rfc-editor.org/rfc/rfc5869).
6. IETF, [RFC 9106 — Argon2](https://www.rfc-editor.org/rfc/rfc9106).
7. NIST, [FIPS 180-4 — Secure Hash Standard](https://csrc.nist.gov/pubs/fips/180-4/upd1/final).
8. NIST, [SP 800-207 — Zero Trust Architecture](https://csrc.nist.gov/pubs/sp/800/207/final).
9. Valkey, [Streams documentation](https://valkey.io/topics/streams-intro/).
10. Argentina.gob.ar, [Ley 25.326](https://www.argentina.gob.ar/normativa/nacional/ley-25326-64790/texto), [Resolución AAIP 126/2024](https://www.argentina.gob.ar/normativa/nacional/resoluci%C3%B3n-126-2024-399750/texto), [DNU 941/2025](https://www.argentina.gob.ar/normativa/nacional/decreto-941-2025-422011/texto) y [Disposición CNC 1/2026](https://www.argentina.gob.ar/normativa/nacional/disposici%C3%B3n-1-2026-425749/texto).
11. n8n, [Sustainable Use License](https://docs.n8n.io/n8n-community-license/sustainable-use-license.md) y [licencias para casos de uso](https://support.n8n.io/article/can-i-use-your-license-for-my-use-case).
12. IETF, [RFC 6265 — HTTP State Management Mechanism](https://www.rfc-editor.org/rfc/rfc6265).

## Cierre

El documento **no es internamente coherente todavía**. Es defendible como trabajo aplicado y demuestra una madurez poco habitual al exponer límites y resultados adversos, pero la versión auditada conserva defectos documentales que afectan el núcleo metodológico. La calificación de 6,7 no penaliza que la hipótesis no haya sido corroborada; penaliza que la versión no permita reconstruir sin contradicciones qué se midió, sobre qué estado del sistema y con qué evidencia. Corregidas las inconsistencias, reparadas las tablas y consolidada la procedencia experimental, el mismo trabajo técnico podría sostener un dictamen sustancialmente mejor sin alterar ningún resultado.
