# Registro de cambios — Tesis v5 cierre técnico

Documento de origen: `Tesis_v5_cierre_tecnico_aplicado (1).docx`.

La edición conserva la separación entre la batería histórica, las verificaciones posteriores y el estado del cierre. No agrega ensayos ni reclasifica como cumplidos los criterios parciales.

## Correcciones aplicadas

| Sección | Frase original buscable | Corrección aplicada | Evidencia / razón |
|---|---|---|---|
| §1.3 | “la baseline se traslada fuera del anfitrión monitoreado” | Se estableció que el contenido restaurable permanece cifrado localmente en `/var/lib/fim-agent/baseline/`; el servidor conserva metadatos, hashes y resoluciones, no una copia completa acreditada. | `CAMBIOS_PARA_TESIS.md`; `RESULTADOS_VERIFICADOS.md`. Se preservó la limitación de la clave maestra co-residente. |
| §4.6 | “cookies con atributo SameSite configurado como Strict” | Se separó la configuración prevista (`Secure=true`, `SameSite=Strict`, ruta restringida) de la evidencia observada en desarrollo (`Secure=false`, `SameSite=Lax`, `path=/`), sin extrapolarla a producción. | Evidencia de cierre Playwright US-03/US-25; divergencia contractual aún abierta. |
| §4.6 | “con atributos Secure, atributos de cookie…” | Se eliminó la afirmación de `Secure` como atributo observado y se limitó el alcance de los controles. | Corrección editorial y técnica; no se afirma inmunidad frente a XSS o CSRF. |
| §4.6 / §4.12 / Anexo G | “código no alcanzable”, “no fue construida”, “no implementada” | US-09 se describe como implementación posterior de diff textual unificado para UTF-8, hasta 1 MiB, con descartes contractuales de binarios y contenido inválido. | `MATRIZ_TRAZABILIDAD.md`; `RESULTADOS_VERIFICADOS.md`. Las pruebas son dirigidas, no integrales. |
| §5.5.1 / Anexo G / tablas de estado | “dos historias… veintiocho… una —US-09—” | Estado de cierre: 9 historias completas, 22 parciales y 0 sin cobertura funcional; no se declara cumplimiento integral del backlog. | `MATRIZ_TRAZABILIDAD.md`. |
| §4.9 / Tabla 20 | “Cobertura 89 %… 90,3 %, discrepancia pendiente” | Se conservó 89,35 % exclusivamente para Coverage Run 3: 2.484/2.780 statements, 570 aprobadas y 2 omitidas; no se atribuye al commit final. | `evidencia/20260909-coverage-run3/`; `RESULTADOS_VERIFICADOS.md`. |
| Tabla 13 | “Moderada (50 concurrentes)” / “Alta (100 concurrentes)” | Se corrigió a 50 operaciones/s y 100 operaciones/s. El estado queda parcial porque no se ensayó la concurrencia prevista. | Batería histórica B4; `CAMBIOS_PARA_TESIS.md`. |
| §5.2 / Tablas 12 y 18 | “17,274” usado sin distinguir el intervalo | Se separó el P99 histórico de 17,274 ms (`received_at − detected_at`) de la reagregación posterior reportada de 17,745 ms (`received_at − marca post-operación`, n=493). | `RESULTADOS_VERIFICADOS.md`; no se intercambian valores ni fuentes. |
| Tabla 17 | Factores 45.421,7× y 51.949,2× | Se retiraron los factores porque los intervalos no tienen inicio y fin equivalentes; se mantuvieron sólo valores descriptivos. | Regla metodológica indicada por el usuario; ausencia de comparación extremo a extremo equivalente. |
| Tabla 17 | “7 de 500 (1,4 %; caus” / “a indeterminada) 395 de” | Se repararon las celdas: FIM “7 de 500 (1,4 %; causa indeterminada)”; control “395 de 500 (79,0 %)”; factor “—”. | Reparación del contenido desplazado. |
| §5.6 / Tabla 18 / Tabla 20 | Resultado de drenaje presentado sin cortes | Se separaron: histórico 153 s; Run 3 51,773 s; Run 4 29,146 s. Run 4 queda limitado a 3.000 eventos preencolados, ensayo local, tasa modificada y sin repetir la desconexión completa de cinco minutos. | `evidencia/drenaje-20260910-run3/`; `evidencia/drenaje-20260910-run4-unit1/`. |
| §4.7 / §4.8 / Tabla 20 | Seguridad y notificaciones tratadas como un mismo flujo | Se distinguieron mTLS agente-backend, transporte Valkey sin TLS en las corridas documentadas, B4 con receptor HTTP local y evaluaciones posteriores A/B con n8n y webhook controlado. | `RESULTADOS_VERIFICADOS.md`; SMTP real y proveedores comerciales no acreditados. |
| Figura 8 | “DLQ / failed_notifications” | Se corrigió el raster para representar registros de `alerts` con marca de fallo y sin marca de entrega; se eliminó la instrucción de regeneración. | Esquema documentado en `CAMBIOS_PARA_TESIS.md`; Tabla 6 y §4.7. |
| Tabla 4 | Separadores ASCII, fila vacía y filas de 2/5/6/8 celdas | Se reconstruyó como tabla OOXML real de siete columnas y diez filas, sin merges ni separadores incrustados; se conservó el contenido factual disponible. | Hallazgo de verificación independiente y comprobación de 7 celdas por fila. |
| Tabla 7 | “secreto ma” / “estro Baseline ilegible” | Se reconstruyeron las dos celdas completas y se preservó el límite frente a compromiso privilegiado del anfitrión. | Reparación editorial y técnica. |
| Tablas 10, 11 y 16 | Fragmentos trasladados entre columnas | Se repararon `integridad`, `n8n inactivo…` y la fila de comandos antes que eventos; además se impidió dividir filas entre páginas. | Inspección del XML y revisión visual del PDF. |
| Tabla 20 — matriz de objetivos | “copia de restauración no especificada”; “discrepancia pendiente”; “intervalo de latencia sin precisar” | Se sustituyeron por las limitaciones vigentes: restauración local cifrada y ligada al evento, coverage de snapshot no final, intervalos de latencia diferenciados, falta de suite consolidada, concurrencia no ensayada y canales no acreditados. | `INFORME_CIERRE_TECNICO.md`; `RESULTADOS_VERIFICADOS.md`. |
| §8.9 | “la copia que el servidor central mantiene” / “la copia central” | Se reemplazó por “representación central de metadatos y hashes” y se explicitó que no hay contenido restaurable centralizado acreditado. | Coherencia con la arquitectura de baseline local cifrada. |
| Conclusiones §7.1 | “los once objetivos… se atendieron… y su dimensión de evaluación se cumplió” | Se reemplazó por una conclusión graduada: análisis y capacidades documentadas, verificaciones acotadas y evaluación global parcial. | Evita declarar cumplimiento integral con 27 historias parciales y resultados de versiones distintas. |
| Índice de tablas | “Tabla 12. Resultados — Latencia de detección” sin Tabla 12a | Se sincronizó con los títulos reales: Tabla 12, “Resultados históricos del tramo agente-backend”, página 88; Tabla 12a, “Reagregación reportada desde la marca posterior a la operación”, página 89. | Verificación contra el PDF final. |
| Índices | “Índice generado como campo de Word… presione F9” | Se eliminó la instrucción interna y se incorporaron índices estáticos con páginas comprobadas en el PDF final. | Control editorial del PDF final. |

## Criterio de cierre: búsqueda global

| Término | Resultado final | Clasificación |
|---|---:|---|
| `US-09` | Coincidencias en resumen, estado, cierre y Anexo G | Corregidas: implementación posterior con alcance y límites; una mención conserva explícitamente el estado de la evaluación inicial. |
| `no implementada`, `no fue construida`, `código no alcanzable`, `dos historias` | 0 | Eliminadas como afirmaciones obsoletas. |
| `veintiocho` | 2 | Justificadas: ambas refieren al catálogo de ciento veintiocho reglas, no al recuento del backlog. |
| `Strict`, `Lax` | Coincidencias en §4.6 | Justificadas: distinguen criterio previsto y atributos observados. Otros usos de `strict` corresponden a términos técnicos ajenos a cookies. |
| `90,3`, `discrepancia pendiente`, `intervalo de latencia sin precisar` | 0 | Eliminadas y sustituidas por las limitaciones vigentes. |
| `concurrentes` | Coincidencias residuales | Justificadas: el criterio original de notificación y el riesgo de aprobaciones concurrentes se conservan como tales; el ensayo real se informa en operaciones/s y no como concurrencia. |
| `failed_notifications`, `debe regenerarse` | 0 | Eliminadas; Figura 8 corregida. |

## Pendientes de evidencia técnica

- Una ejecución consolidada de agente, backend y frontend sobre una única versión final, con commit, alcance, resultados y cobertura propios.
- Evidencia de una corrección técnica que lleve la cookie al criterio previsto `Secure=true`, `SameSite=Strict` y ruta restringida. Hasta entonces el documento conserva `Secure=false`, `Lax` y `path=/` como estado observado en desarrollo, sin extrapolarlo a producción.
- Ensayo de TLS para el transporte Valkey; mTLS agente-backend no lo sustituye.
- Ensayo de concurrencia real para notificaciones; las tasas de 50 y 100 operaciones/s no lo acreditan.
- Entrega SMTP real y proveedores comerciales; el receptor controlado y el fallback webhook no los acreditan.
- Datos originales y script verificable de la reagregación de 17,745 ms si se pretende elevarla de “reportada” a cálculo reproducido independientemente.
- Repeticiones de drenaje con configuración predeterminada y una desconexión completa de cinco minutos; Run 4 sólo acredita su escenario controlado.
- Evaluación multianfitrión. Las corridas disponibles son locales o de un solo anfitrión.
- Las diecinueve operaciones históricas sin evento carecen de trazas causales contemporáneas; la corrida causal posterior no puede reconstruirlas retrospectivamente.

## Pendientes editoriales o documentales

- Identificar una fuente institucional precisa para el código deontológico o retirar su invocación. No se agregó ninguna referencia sin fuente.
- La correspondencia de las citas utilizadas en las secciones intervenidas con la bibliografía se conservó; no se completaron metadatos bibliográficos por inferencia.

## Contradicciones no resueltas

- **Autenticación:** el criterio previsto exige `Secure=true`, `SameSite=Strict` y ruta restringida, mientras la evidencia disponible en desarrollo registra `Secure=false`, `SameSite=Lax` y `path=/`. Se expone la divergencia; no se la corrige editorialmente como si el sistema ya cumpliera ni se extrapola el estado de desarrollo a producción.
- **Cobertura final:** Coverage Run 3 informa 89,35 % sobre un snapshot manifestado anterior a cambios posteriores. No existe evidencia para atribuir ese porcentaje a la versión final.
- **Hipótesis conjunta:** conviven resultados históricos adversos y verificaciones posteriores acotadas sobre versiones diferentes. Por ese motivo el documento no declara corroboración integral.

## Control de integridad y revisión visual

- `unzip -t`: paquete DOCX válido, sin errores.
- Exportación LibreOffice headless: correcta; PDF A4 de 150 páginas.
- Diferencia observada de paginación: original 149 páginas; final 150 páginas. No se atribuye una causa única sin una comparación de maquetación automatizada página por página.
- Antes/después: 34 entradas OOXML, 10 recursos gráficos, 10 dibujos, 22 tablas y 1 sección en ambos documentos.
- Páginas revisadas visualmente: 48–49 (Tabla 4), 10 (índice), 74 (§4.6), 88–89 (Tablas 12 y 12a), 65–66 (Tabla 7), 75 (Figura 8), 79–80 (Tabla 10), 85–86 (Tabla 11), 90 (Tabla 13), 94–95 (Tabla 16), 97–99 (Tabla 17), 113–115 (Tabla 20) y 123 (§8.9).
- Observaciones visuales: Tabla 4 quedó estructurada y legible; no se observaron separadores ASCII ni celdas desplazadas. Tablas 13, 16 y 20 conservan particiones de línea propias de columnas estrechas, sin alterar el contenido; se documentan como limitación visual menor.
