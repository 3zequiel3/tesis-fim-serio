# Auditoría integral de la tesis V6

**Objeto auditado:** `docs/cierre/Tesis_v6_cierre_tecnico.docx`  
**SHA-256:** `55c19a5835698b6665a4796e97a8fa0e34754097753077bb768126fb549b3593`  
**Fecha de auditoría:** 11 de septiembre de 2026  
**Dictamen:** **Aprobada con observaciones**  
**Calificación global:** **7,2/10** (promedio sin redondear: **7,1858333333**; promedio calculado con mayor precisión antes de exponer las medias capitulares: **7,1861111111**).

## Resumen ejecutivo

La V6 constituye una mejora académica real respecto de la versión original auditada con 6,7/10. Corrige la mayor parte de las contradicciones sustantivas que impedían reconstruir el alcance de la evidencia: ubica el contenido restaurable de la baseline en `/var/lib/fim-agent/baseline/`, separa mTLS agente-backend del transporte Valkey, conserva como distintos los intervalos de latencia de 17,274 ms y 17,745 ms, identifica como tasas —no concurrencia— los escenarios de 50 y 100 operaciones/s, mantiene separados el drenaje histórico, Run 3 y Run 4, declara el alcance local de US-20, conserva US-09 como parcial y reconoce que 10 historias completas y 21 parciales no satisfacen el criterio 31/31. La Figura 8 y las Tablas 7, 13, 17 y 20 fueron sustancialmente reparadas.

El avance principal no consiste en resultados más favorables, sino en una epistemología más disciplinada: el documento distingue implementación, prueba dirigida, evaluación histórica, verificación posterior y estado de cierre; no agrega baterías incompatibles ni declara corroborada la hipótesis conjunta. Esta mejora justifica el cambio de dictamen desde **Aprobada con observaciones mayores** a **Aprobada con observaciones**.

Persisten, sin embargo, defectos de entidad. Tres figuras conservan información incompatible con el texto corregido: la Figura 1 atribuye visualmente mTLS al trayecto hacia Valkey; la Figura 2 mantiene “retención ilimitada” vinculada a la Resolución AAIP 47/2018 y duplica `version`; y la Figura 4 sigue mostrando la ventana `received_at − detected_at` y una semántica exactamente-una-vez que el propio §4.4 delimita. Además, la matriz detallada que origina el recuento 10/21/0 no está incorporada al DOCX, la nota de la Tabla 18 afirma erróneamente que todos sus valores pertenecen a una misma corrida, y no existe una ejecución integral final sobre un único commit. Estas limitaciones impiden una calificación sobresaliente y conservan preguntas previsibles de defensa.

No se identifican hallazgos críticos en esta versión. Se registran **28 riesgos: 10 altos, 12 medios y 6 bajos**. Las limitaciones correctamente declaradas no se califican como contradicciones; se pondera, no obstante, su impacto sobre el alcance defendible.

## Alcance, método y límites de esta auditoría

Se aplicó el mismo marco usado para la V5: lectura completa del contenido materializado en `document.xml`; inventario de párrafos, tablas, leyendas e imágenes; revisión capítulo por capítulo; evaluación metodológica transversal; contraste de citas y referencias; inspección individual de las 22 tablas y 10 figuras; análisis técnico de arquitectura; métricas heurísticas reproducibles de escritura; registro de riesgos y puntuación por seis dimensiones.

Las clasificaciones utilizadas son:

- **Hecho verificado:** observable en el DOCX o en una fuente primaria consultada.
- **Afirmación no verificable:** el DOCX la declara, pero no contiene evidencia suficiente para comprobarla.
- **Error:** contradicción, dato incorrecto o defecto material demostrable.
- **Juicio evaluativo:** valoración académica fundada, no hecho empírico.

La inspección visual se realizó sobre los diez archivos gráficos originales extraídos del DOCX, con resolución efectiva aproximada de 315–351 ppp. La ejecución de LibreOffice destinada a fijar paginación fue interrumpida y no se generó un PDF de auditoría; por ello no se afirma que no existan cortes de tabla, desbordes o viudas en la paginación final. El contenido de las celdas sí fue inspeccionado directamente en XML. La verificación externa se limitó a fuentes oficiales o primarias y reutilizó la comprobación de enlaces realizada con el mismo corpus bibliográfico de la V5; los bloqueos 403 de algunos DOI y la inaccesibilidad puntual de Openwall impiden equiparar “no accesible” con “inexistente”.

## Evaluación de estructura, hipótesis y objetivos

La estructura general cumple el estándar esperado para una tesis aplicada: problema, antecedentes, fundamento, método, desarrollo, resultados, discusión, conclusiones, recomendaciones, ética, referencias y anexos se ordenan de manera lógica. Los índices ya presentan páginas, aunque la entrada conjunta de las Tablas 12 y 12a requiere corrección.

La hipótesis de §1.6 es explícita, falsable y exigente: al ser conjunta, basta un criterio no alcanzado para que no resulte corroborada. La V6 respeta esa regla y no convierte resultados parciales en corroboración. Su debilidad residual es que combina suficiencia funcional, cobertura del backlog y una comparación de proporciones en una única proposición; esta agregación dificulta interpretar qué dimensión del artefacto explica el rechazo. La hipótesis nula también mezcla “uno o más umbrales” con la comparación reactivo-control.

El objetivo general es claro y está delimitado al laboratorio. Los once objetivos específicos son trazables en la Tabla 20. Existe, sin embargo, una asimetría: el criterio 31/31 del frontend no tiene un objetivo específico propio, hecho que la Tabla 4 reconoce. Esa honestidad evita una falsa trazabilidad, pero revela que el sistema de criterios y el árbol de objetivos no fueron diseñados completamente alineados.

## Evaluación capítulo por capítulo

### Capítulo 1 — Introducción

**Cumple con observaciones.** Delimita el laboratorio, separa objetivos de producto, criterios de aceptación y contribución normativa, y formula una hipótesis explícita. La baseline local y su límite frente a compromiso privilegiado quedan correctamente declarados. La premisa sobre accesibilidad económica de soluciones comerciales se reconoce como no evaluada. Persiste el uso de “exactamente-una-vez” en el objetivo 6, aunque luego se acota a persistencia deduplicada.

### Capítulo 2 — Marco teórico y estado del arte

**Cumple.** El marco articula integridad, hashes, FIM, normativa, fanotify, SOAR, mensajería, criptografía, Zero Trust y STRIDE. El estado del arte evita reclamar exclusividades frente a Wazuh y distingue FIM de seguridad de ejecución. Las fuentes técnicas principales son oficiales: [fanotify(7)](https://man7.org/linux/man-pages/man7/fanotify.7.html), [RFC 8446](https://www.rfc-editor.org/rfc/rfc8446), [RFC 9106](https://www.rfc-editor.org/rfc/rfc9106) y [FIPS 180-4](https://doi.org/10.6028/NIST.FIPS.180-4). No es una revisión sistemática y no ofrece estrategia de búsqueda, bases consultadas ni criterios de inclusión; el propio texto lo reconoce.

### Capítulo 3 — Marco metodológico

**Cumple con observaciones.** El encuadre en ciencia del diseño es pertinente y está apoyado en Hevner, Peffers y Wieringa. Define enfoque, unidad de análisis, generación programática de muestra, variables, instrumentos, baterías y amenazas. Corrige la independencia estadística: McNemar es pertinente para observaciones pareadas y Newcombe (1998) se identifica correctamente como fuente insuficiente para la diferencia pareada. No se ejecuta inferencia sin la tabla de pares.

Persisten limitaciones: no se justifica el tamaño de las muestras por precisión o estabilidad de percentiles; la validación del generador y de la checklist fue realizada por los autores; no se informa confiabilidad interobservador; y las verificaciones redundantes previstas con `tcpdump` y `strace` no se reportan. El protocolo planificó concurrencia, pero la corrida ejecutó tasas distintas; el documento lo declara sin alterar retrospectivamente el criterio.

### Capítulo 4 — Desarrollo

**Cumple con observaciones altas.** La arquitectura y los flujos están explicados con profundidad, incluyendo outbox, deduplicación, bloqueo optimista, anti-replay, candidatos cifrados y retención. Se distinguen baseline restaurable local, representación central, HMAC y TLS. La autenticación web registra `SameSite=Strict` y `Path=/auth/refresh` como verificación posterior, con `Secure=false` limitado al laboratorio HTTP; no afirma inmunidad XSS/CSRF.

El principal problema es la divergencia entre texto y figuras. Figura 1, Figura 2 y Figura 4 conservan estados anteriores o simplificaciones materialmente engañosas. Asimismo, la matriz 10/21/0 se resume, pero no se incluye criterio por criterio dentro del DOCX.

### Capítulo 5 — Resultados

**Cumple con observaciones.** Es el capítulo que más mejora: preserva resultados adversos, separa snapshots, no suma suites y delimita cada intervalo. Las Tablas 12/12a mantienen 17,274 ms y 17,745 ms con definiciones distintas; la Tabla 13 usa operaciones/s; la Tabla 17 retira factores no comparables; y la Tabla 18 no declara corroboración conjunta.

La evidencia continúa fragmentada. Los 912 casos son históricos, el 89,35 % pertenece a Coverage Run 3 y Run 4 es una corrida dirigida con tasa modificada. El margen de Run 4 es de 0,854 s y no hay distribución entre repeticiones válidas. US-20 se limita correctamente a un proxy SSE local. La nota posterior a Tabla 18 introduce una contradicción: dice que “todos los valores” corresponden a “la corrida informada”, aunque la tabla incorpora el cierre 10/21/0, Run 4 y la corrida causal posterior.

### Capítulo 6 — Discusión

**Cumple con observaciones.** Discute validez interna y externa, evita causalidad indebida y limita la generalización. Reconoce topología co-residente, ausencia de red real, cifrado deshabilitado y n8n inactivo en la corrida histórica. La formulación sobre la licencia de n8n continúa demasiado amplia: la licencia oficial restringe usos concretos y remite a licencia comercial para otros, por lo que debe citarse directamente la [Sustainable Use License oficial](https://docs.n8n.io/n8n-community-license/sustainable-use-license.md) y evitar una prohibición general de incorporación.

### Capítulo 7 — Conclusiones

**Cumple.** Responde a objetivos e hipótesis sin prometer aptitud productiva. La Tabla 20 separa análisis, implementación, verificación y limitaciones. Declara que la hipótesis conjunta no fue corroborada, conserva las 19 ausencias históricas como indeterminadas y no transforma Run 4 en validación integral. La conclusión es defendible precisamente porque admite el resultado parcial.

### Capítulo 8 — Recomendaciones y trabajo futuro

**Cumple.** Distingue correcciones de cierre de extensiones futuras. Las propuestas de alta disponibilidad, custodia de clave, reconciliación, eBPF, SIEM y atribución estable de procesos derivan de limitaciones observadas. Debe evitarse que la nueva suite consolidada o el transporte Valkey con TLS se presenten como obligaciones del alcance original: son condiciones para ampliar evidencia o desplegar, no para reescribir resultados históricos.

### Capítulo 9 — Consideraciones éticas

**Cumple con observaciones.** Reconoce que diffs y cuarentena pueden contener datos, corrige la retención indefinida y evita atribuir un código deontológico no identificado. Falta convertir esa conciencia en una matriz operacional de datos, finalidad, acceso, transmisión y retención por canal.

### Capítulo 10 — Glosario

**Cumple con observaciones menores.** Es amplio y útil. Algunas entradas contienen afirmaciones comparativas o jurídicas que exceden una definición neutral y deberían citarse o reducirse. Debe uniformarse el uso de anglicismos.

### Capítulo 11 — Referencias

**Cumple con observaciones.** Se identificaron 48 entradas y 40 con URL o DOI. La mayoría existe y las normas, RFC y estándares centrales remiten a fuentes primarias. Persisten problemas APA 7 y de verificabilidad: referencias agrupadas temáticamente en vez de una lista alfabética única; reportes IBM, Mandiant y Verizon sin URL; ISO y PCI sin localizador; AIDE enlazada mediante un espejo no oficial; y la URL `https://valkey.io/documentation/` devolvió 404 en la comprobación anterior del mismo corpus. Menezes et al. (1996) no presenta una cita sustantiva detectada. Los DOI con 403 se consideran existentes por su resolución/editor, no referencias inexistentes.

### Capítulo 12 — Anexos

**Cumple con observaciones.** Los anexos describen flujos, persistencia, Compose, systemd, código, evidencia y backlog. Anexo F mejora la trazabilidad al nombrar paquetes y commits, pero el DOCX aislado no incorpora manifiestos, comandos ni datos; la reproducibilidad depende del repositorio externo. Anexo G enumera 31 historias, pero no contiene la matriz criterio por criterio que permita recomputar 10/21/0.

## Revisión metodológica transversal

| Dimensión | Evaluación |
|---|---|
| Paradigma | Ciencia del diseño, pertinente y explícita. |
| Enfoque | Evaluación cuantitativa con fundamentación argumentativa; no se sobredenomina métodos mixtos. |
| Diseño | Comparativo sobre la misma carga; adecuado para descripción, insuficiente para causalidad o generalización poblacional. |
| Población y muestra | Unidad: operación de archivo. Muestra generada, no probabilística; composición reproducible declarada. Sin justificación de precisión/tamaño. |
| Variables e indicadores | Operacionalizados en Tabla 4. Buena trazabilidad, salvo criterio frontend sin objetivo específico y latencia histórica que no mide el intervalo objetivo. |
| Instrumentos | Generador, logs, SQL, `tcpdump`, `strace`, checklist. Validación autoral; resultados de triangulación no reportados. |
| Estadística | Descriptiva apropiada. McNemar identificado; inferencia no ejecutada sin pares. Sin IC del P99 ni variabilidad de Run 4. |
| Amenazas a validez | Tratadas con franqueza en §§6.4–6.5. Persisten co-residencia, una sola topología y ejecución fragmentada. |
| Reproducibilidad | Rutas y commits mejoran trazabilidad; falta paquete autocontenido y corrida final congelada. |

## Revisión individual de tablas

| Tabla | Evaluación |
|---|---|
| Tabla A | Completa y legible en XML; contiene 39 siglas. “CNC” debe mantenerse vinculado a la fuente normativa vigente. |
| Tabla 1 | Criterios claros y preestablecidos. Conserva concurrencia como criterio original; correctamente no se redefine por las tasas ejecutadas. |
| Tabla 2 | Muy mejorada: distingue obligación, recomendación y documento programático. |
| Tabla 3 | STRIDE pertinente; reconoce que `audit_log` no es inmutable. Las mitigaciones no equivalen automáticamente a pruebas. |
| Tabla 4 | Reparada y coherente con Tablas 1 y 18. Explicita que cobertura del backlog no tiene objetivo específico propio. |
| Tabla 5 | Estructura correcta. “Versiones efectivamente desplegadas y verificadas” no puede comprobarse desde el DOCX aislado. |
| Tabla 6 | Correcta; `alerts` reemplaza una tabla ficticia de fallos. La política real de retención requiere parametrización. |
| Tabla 7 | Celda dañada reparada; baseline ilegible sin secreto correctamente delimitada. |
| Tabla 8 | Máquina de estados coherente con el texto. |
| Tabla 9 | Fallbacks y persistencia final coherentes; las evaluaciones no acreditan SMTP ni proveedores reales. |
| Tabla 10 | Reparada: ruta unificada y separación explícita entre mTLS agente-backend y Valkey. Contradice visualmente la Figura 1. |
| Tabla 11 | Recuento 10/21/0 consistente dentro del texto. La matriz que lo produce no está incluida; “cerraron criterios” no es recomputable. |
| Tabla 12 | Conserva P99 histórico 17,274 ms sobre `received_at − detected_at`; “Sí” aparece sin tilde en dos celdas. Siete ausencias siguen indeterminadas. |
| Tabla 12a | Mantiene 17,745 ms, n=493, como reagregación de un intervalo distinto. No contiene artefacto de cálculo. |
| Tabla 13 | Reparada: 50 y 100 operaciones/s, no concurrentes. Los estados parciales son correctos; faltan causas para 31 operaciones sin webhook. |
| Tabla 14 | Aritmética 9/11=81,8 % correcta. El universo y la codificación son autorales; NIST SP 800-61r2 fue retirado y sustituido por [r3](https://doi.org/10.6028/NIST.SP.800-61r3). |
| Tabla 15 | 912=418+494 y 911 aprobados+1 omitido. Es histórica y no representa el commit final. |
| Tabla 16 | Repara celdas desplazadas y distingue 2.988 encolados de 3.000 operaciones. Conserva correctamente 153 s como incumplimiento. |
| Tabla 17 | Reparada: FIM 7/500, control 395/500, factor “—”. Retira cocientes de latencias no equivalentes. |
| Tabla 18 | Síntesis mayormente coherente. Su nota afirma equivocadamente que todos los valores pertenecen a una corrida, pese a mezclar cortes. |
| Tabla 19 | Diseño A/B/C con n=10 por caso; demuestra ausencia de evasión observada, no inmunidad. La ventana con demora no fue ensayada. |
| Tabla 20 | Excelente mejora de trazabilidad y límites. No declara cumplimiento integral. La evidencia sigue siendo documental y externa para varias filas. |

## Revisión individual de figuras

| Figura | Evaluación |
|---|---|
| Figura 1 | **Defecto alto.** La flecha agente→Valkey porta el rótulo `mTLS · TLS 1.3`, incompatible con Tabla 10 y §§4.8/7.6, que no acreditan TLS Valkey. También conserva `audit_log retención ilimitada`. |
| Figura 2 | **Defecto alto.** Duplica `version (bloqueo optimista)` en `events` y conserva “retención ilimitada (Res. AAIP 47/2018)”, contradiciendo §4.2. El diagrama no usa consistentemente una notación ER formal. |
| Figura 3 | Clara y legible. Sintetiza las tres fases. Debe evitar equiparar “backend indisponible” con toda indisponibilidad de Valkey. |
| Figura 4 | **Defecto alto.** Muestra `|received_at − detected_at| < 5 min` aunque la ventana actual es transmisión→recepción; concluye semántica exactamente-una-vez pese a que §4.4 la limita a entrega al menos una vez y persistencia deduplicada. |
| Figura 5 | Coherente con Tabla 8. Notación de estados simplificada, suficiente si se rotula como tal. |
| Figura 6 | Captura legible del banner degradado; evidencia existencia visual, no el universo de condiciones que lo activa. |
| Figura 7 | El toggle “Mostrar eventos superseded” es visible, pero la lista vacía no prueba filtrado ni cadena con `parent_event_id`. Las pruebas posteriores, no la imagen, sostienen US-31. |
| Figura 8 | Corregida: finaliza en registros `alerts`, no en `failed_notifications`; no contiene instrucciones editoriales. |
| Figura 9 | Despliegue simplificado y legible. Omite protocolos, TLS y fronteras de confianza; no debe usarse como prueba de topología evaluada. |
| Figura 10 | Organización comprensible, pero no es UML/C4 estricto. El canal “Valkey Streams” no explicita estado TLS. |

Las diez imágenes poseen resolución suficiente para impresión (315–351 ppp efectivos). La legibilidad interna es menor que la resolución: Figuras 1–5 contienen texto fino y denso, por lo que conviene proyectarlas ampliadas durante la defensa.

## Auditoría técnica independiente de la arquitectura

La separación funcional entre agente, mensajería, backend, persistencia, frontend y orquestación es viable para un prototipo académico. Son fortalezas el outbox transaccional, la deduplicación por identificador, el bloqueo optimista, la máquina de estados y la separación entre contenido restaurable local y representación central. El diseño anti-replay basado en `sent_at`, firma HMAC y deduplicación es compatible con colas offline; esta compatibilidad está correctamente razonada.

Los límites arquitectónicos relevantes son: instancia única de backend; dependencia de Valkey para autenticación; transporte Valkey no cifrado en los ensayos; clave maestra co-residente; agente privilegiado mediante `CAP_SYS_ADMIN`; `audit_log` mutable; cola `drop-oldest`; y ausencia de evaluación multianfitrión. Son limitaciones reales, correctamente declaradas en su mayoría. La documentación oficial de Linux confirma que fanotify puede emitir `FAN_Q_OVERFLOW` y que sus modos dependen de versión y soporte del sistema de archivos ([fanotify(7)](https://man7.org/linux/man-pages/man7/fanotify.7.html)); detectar el overflow no recupera eventos perdidos.

## Resultados, discusión y conclusiones

La cadena metodológica es ahora coherente en lo esencial:

1. la hipótesis exige satisfacción conjunta;
2. los criterios se mantienen sin redefinición retrospectiva;
3. los resultados históricos adversos se conservan;
4. las verificaciones posteriores se identifican por separado;
5. la discusión limita causalidad y generalización;
6. la conclusión no declara corroboración conjunta.

La inferencia defendible es acotada: el artefacto mostró latencia baja y mejor proporción descriptiva de detección que el sondeo sobre la carga ejecutada; preservó los eventos efectivamente encolados; y ciertas capacidades fueron verificadas en pruebas dirigidas. No queda acreditado el sistema final completo, la concurrencia prevista, SMTP real, TLS Valkey, operación multianfitrión, alta disponibilidad ni aptitud productiva.

## Auditoría cuantitativa de escritura científica

Método: tokenización Unicode sobre texto visible de párrafos y celdas; segmentación de oraciones por puntuación final seguida de mayúscula; patrones léxicos para impersonales, pasivas, adverbios y nominalizaciones. Son aproximaciones, no análisis sintáctico.

| Métrica | V6 | V5 comparable | Cambio |
|---|---:|---:|---:|
| Palabras | 46.342 | 46.744 | −402 |
| Oraciones heurísticas | 1.618 | 1.585 | +33 |
| Media de palabras/oración | 28,63 | 29,48 | −0,85 |
| Mediana | 22 | 23 | −1 |
| Oraciones >40 palabras | 339 | 356 | −17 |
| Oraciones >50 palabras | 199 | 209 | −10 |
| Adverbios en `-mente` | 284 | 291 | −7 |
| Construcciones impersonales con `se` | 65 | 66 | −1 |
| Pasivas perifrásticas | 33 | 31 | +2 |
| Nominalizaciones por sufijo | 3.075 | 3.100 | −25 |

La mejora de concisión es real pero moderada. Continúan oraciones extensas con varias reservas concatenadas, especialmente en §§3.6–3.8, 4.4–4.8, 5.6–5.9 y 7.2–7.6.

| Dimensión de escritura | Nota |
|---|---:|
| Claridad | 7,4 |
| Concisión | 6,5 |
| Voz activa | 7,3 |
| Fluidez | 7,2 |
| Precisión terminológica | 7,4 |
| Coherencia discursiva | 7,7 |
| Estilo científico | 7,6 |
| **Media** | **7,30** |

## Tabla completa de riesgos y hallazgos

| ID | Severidad | Problema | Ubicación exacta buscable | Evidencia / clasificación | Consecuencia para defensa | Corrección mínima |
|---|---|---|---|---|---|---|
| A-1 | Alto | No existe ejecución integral final sobre un commit congelado. | §4.9, frase “Permanece pendiente una ejecución consolidada”; §7.6. | **Hecho verificado y limitación correctamente declarada.** | Impide atribuir simultáneamente cobertura, funcionalidad y seguridad al estado final. | Mantener la limitación o adjuntar una corrida consolidada con manifiesto, JUnit y cobertura propios. |
| A-2 | Alto | Figura 1 confunde mTLS agente-backend con transporte Valkey. | Figura 1, flecha `mTLS · TLS 1.3`; Tabla 10. | **Error visual.** | Sobreafirma cifrado del canal empleado en los ensayos. | Regenerar con canales separados y estado probado/no probado. |
| A-3 | Alto | Figura 4 conserva ventana anti-replay obsoleta y semántica exactamente-una-vez. | Figura 4, textos `received_at - detected_at` y “semántica resultante”. | **Error visual.** | Contradice §§4.4–4.5 y puede invalidar la defensa del protocolo. | Regenerar con `sent_at→received_at` y “al menos una vez + persistencia deduplicada”. |
| A-4 | Alto | Figura 2 conserva retención ilimitada atribuida a AAIP. | Figura 2, entidad `audit_log`; §4.2, frase “ninguna de las normas”. | **Error visual/normativo.** | Reintroduce una conclusión jurídica que el texto corrigió. | Reemplazar por “sin depuración automática en esta versión; política organizacional pendiente”. |
| A-5 | Alto | El recuento 10/21/0 no es recomputable desde el DOCX. | §§4.12, 5.5.1, Anexo G. | **Afirmación no verificable:** no se incluye matriz criterio por criterio. | El tribunal no puede auditar denominador ni método de clasificación. | Incorporar la matriz o un anexo autocontenido con criterios, estado y evidencia. |
| A-6 | Alto | La hipótesis conjunta no fue corroborada. | §1.6; Tabla 18; §7.6. | **Hecho verificado, no contradicción.** | La defensa debe explicar el valor del artefacto pese al resultado global negativo. | Exponer criterios alcanzados/no alcanzados sin reformular la hipótesis. |
| A-7 | Alto | Nota de Tabla 18 atribuye valores heterogéneos a una sola corrida. | Nota posterior a Tabla 18: “Todos los valores… corresponden a la corrida informada”. | **Error.** La tabla incluye cierre, corrida causal y Run 4. | Contradice la separación de cortes que constituye la principal mejora V6. | Reescribir la nota identificando el origen de cada fila. |
| A-8 | Alto | Reproducibilidad depende del repositorio externo. | Anexo F, frases “El repositorio de referencia” y rutas `evidencia/...`. | **Afirmación no verificable desde el DOCX.** | Una copia aislada no permite repetir ni comprobar hashes. | Adjuntar manifiesto mínimo, commits, comandos y checksums en el depósito institucional. |
| A-9 | Alto | La batería de notificación no evaluó concurrencia ni explica 31 faltantes. | §5.3 y Tabla 13, nota “31 operaciones sin webhook”. | **Hecho verificado y límite declarado.** | No acredita el criterio de 100 solicitudes concurrentes. | Mantener “parcial” y ejecutar, si se desea cerrar, la concurrencia original con denominador completo. |
| A-10 | Alto | Seguridad y despliegue solo fueron evaluados localmente y sin TLS Valkey. | §§3.7, 5.6.1, 7.6; Tabla 20. | **Hecho verificado y limitación declarada.** | No acredita arquitectura distribuida segura de extremo a extremo. | No extrapolar; una prueba multianfitrión con TLS sería evidencia adicional, no corrección histórica. |
| M-1 | Medio | Run 4 tiene una sola corrida válida y margen de 0,854 s. | §5.6.1, “29,146 segundos”. | **Hecho verificado.** | Resultado frágil frente a variabilidad. | Repetir sin alterar configuración y reportar todas las corridas válidas. |
| M-2 | Medio | Triangulación temporal prevista pero no reportada. | §3.5 (`tcpdump`, `strace`) y §6.4. | **Afirmación no verificable.** | No hay reloj independiente para validar marcas internas. | Publicar comparación o declarar instrumentos no aplicados. |
| M-3 | Medio | Checklist de triage es autoral y usa NIST r2 retirado. | §§3.6, 5.4; Tabla 14. | **Hecho verificado.** | 81,8 % depende del universo definido por los autores. | Conservar como descriptivo; mapear a r3 o usar segundo evaluador. |
| M-4 | Medio | Caracterización de licencia n8n demasiado general. | §6.6, frase “prohíbe su reventa o incorporación”. | **Error potencial** frente a la licencia oficial. | Objeción legal/técnica. | Citar la SUL y describir casos concretos sin dictamen jurídico absoluto. |
| M-5 | Medio | Fuentes industriales y estándares sin localizador. | Cap. 11: IBM, Mandiant, Verizon, ISO, PCI. | **Hecho verificado.** | Dificulta existencia y consulta. | Añadir URL editorial oficial sin completar datos no comprobados. |
| M-6 | Medio | URL oficial de Valkey obsoleta. | Cap. 11, `https://valkey.io/documentation/`. | **Error de enlace:** la comprobación del corpus V5 devolvió 404. | Reduce verificabilidad técnica. | Sustituir por una página oficial vigente y específica. |
| M-7 | Medio | Referencias no siguen de forma consistente APA 7. | Cap. 11. | **Juicio evaluativo.** Lista temática, guiones de páginas y localizadores inconsistentes. | Observación editorial del tribunal. | Normalizar una lista alfabética única si así lo exige la guía institucional. |
| M-8 | Medio | Figura 7 no demuestra comportamiento de US-31. | Figura 7, lista vacía. | **Error probatorio.** El control existe, pero no se ve su efecto. | Debilita la comprobación manual. | Usar evidencia con eventos superseded antes/después o apoyar solo en la prueba posterior. |
| M-9 | Medio | Figuras 9 y 10 no siguen UML/C4 estricto. | Anexos D/H, Figuras 9–10. | **Juicio evaluativo.** Están rotuladas como simplificadas. | Menor precisión de fronteras, protocolos y cardinalidad. | Mantener el rótulo o adoptar notación formal con leyenda. |
| M-10 | Medio | Tabla 5 declara versiones “verificadas” sin evidencia dentro del DOCX. | Nota de Tabla 5. | **Afirmación no verificable.** | Un lector no puede comprobar lockfiles/imágenes. | Vincular manifiesto de dependencias del snapshot correspondiente. |
| M-11 | Medio | Premisa de accesibilidad económica no fue evaluada. | §§1.1–1.3 y 6.2. | **Limitación correctamente declarada.** | No puede sostener ventaja de costo. | Mantenerla como motivación, no como resultado comparativo. |
| M-12 | Medio | Tratamiento de contenido de diffs no está operacionalizado. | §§4.7, 8.1 y 9.1. | **Hecho verificado y pendiente declarada.** | Riesgo de privacidad y secretos por notificaciones. | Añadir inventario de campos, acceso, retención y minimización por canal. |
| B-1 | Bajo | Índice concatena Tablas 12 y 12a en una entrada. | Índice de tablas, frase “Tabla 12… — 88Tabla 12a…”. | **Error editorial.** | Dificulta navegación. | Separar las entradas y actualizar el campo. |
| B-2 | Bajo | Figura 2 duplica el campo `version`. | Figura 2, entidad `events`. | **Error gráfico.** | Ruido y posible confusión de esquema. | Eliminar duplicado. |
| B-3 | Bajo | “Sí” aparece sin tilde en resultados. | Tabla 12 y Tabla 16, celdas `Si`. | **Error editorial.** | Terminación desigual. | Normalizar “Sí” y “—”. |
| B-4 | Bajo | Anglicismos y términos híbridos abundantes. | Global: `baseline`, `fallback`, `snapshot`, `superseded`, `payload`. | **Juicio editorial.** | Reduce uniformidad del registro. | Definir y aplicar una política terminológica consistente. |
| B-5 | Bajo | Epígrafes autorales/anónimos agregan volumen sin función académica. | Inicios de capítulos. | **Juicio evaluativo.** | Puede percibirse ornamental. | Retirar los que no introducen una decisión metodológica. |
| B-6 | Bajo | Menezes et al. (1996) no presenta cita sustantiva detectada. | Cap. 11. | **Resultado heurístico.** | Correspondencia cita-referencia incompleta. | Citar donde fundamente una primitiva o retirar. |

## Calificación por capítulo

La fórmula es idéntica a la aplicada a V5: media aritmética de seis dimensiones —rigor científico, metodología, redacción, bibliografía, APA 7 y coherencia— con igual peso. Las dimensiones no aplicables se excluyen del denominador del capítulo. La nota global es la media de las doce medias capitulares. No se añade penalización oculta por riesgos; éstos determinan el dictamen cualitativo.

| Capítulo | Rigor | Método | Redacción | Bibliografía | APA | Coherencia | Media |
|---|---:|---:|---:|---:|---:|---:|---:|
| 1 | 8,0 | 7,8 | 7,7 | 7,3 | 7,0 | 8,0 | 7,63 |
| 2 | 8,2 | 7,6 | 7,6 | 8,0 | 7,0 | 7,8 | 7,70 |
| 3 | 8,2 | 7,5 | 7,5 | 7,6 | 7,0 | 7,8 | 7,60 |
| 4 | 7,4 | 7,1 | 7,0 | 6,8 | 6,5 | 6,3 | 6,85 |
| 5 | 7,4 | 6,7 | 7,4 | 6,8 | 6,5 | 7,5 | 7,05 |
| 6 | 7,7 | 7,1 | 7,5 | 7,3 | 6,8 | 7,5 | 7,32 |
| 7 | 7,9 | 7,4 | 7,8 | 6,8 | 6,6 | 8,1 | 7,43 |
| 8 | 7,8 | 7,4 | 7,5 | 6,8 | 6,6 | 8,0 | 7,35 |
| 9 | 7,5 | 7,0 | 7,5 | 6,5 | 6,5 | 7,8 | 7,13 |
| 10 | 7,2 | N/A | 7,4 | 6,5 | 6,3 | 7,1 | 6,90 |
| 11 | N/A | N/A | 6,7 | 7,3 | 5,9 | 6,7 | 6,65 |
| 12 | 7,2 | 6,7 | 7,0 | 6,0 | 6,0 | 6,8 | 6,62 |

**Promedio global calculado:** 7,1858333333 a partir de las medias capitulares expuestas; 7,1861111111 usando las dimensiones antes de redondear cada media.  
**Nota final:** **7,2/10**.

## Comparación válida con la V5

| Aspecto | V5 | V6 | Interpretación |
|---|---:|---:|---|
| Nota global | 6,7 | 7,2 | +0,5 puntos por coherencia, método y cierre editorial. |
| Riesgos críticos | 5 | 0 | Se corrigieron contradicciones centrales de baseline, backlog, tablas y conclusión. |
| Backlog declarado | 4/27/0 en el cierre V5 | 10/21/0 | Mejora declarada; el detalle completo sigue fuera del DOCX. |
| Hipótesis conjunta | No corroborada | No corroborada | No se maquilló el resultado. |
| Suite final única | Ausente | Ausente | Limitación residual sin cambio. |

La comparación es metodológicamente válida porque usa el mismo parser, las mismas métricas, dimensiones y fórmula. La diferencia residual de medición proviene de cambios reales en el texto y de que no se fijó paginación de V6 en PDF; la nota no incluye una dimensión de cantidad de páginas, por lo que esto no altera el cálculo. No se atribuye la mejora a nuevas capacidades que no estén documentadas.

## Fortalezas principales

- Honestidad al conservar incumplimientos, indeterminaciones y cortes históricos.
- Marco metodológico de ciencia del diseño bien formulado.
- Tabla 20 con trazabilidad y limitaciones explícitas.
- Arquitectura técnicamente madura para un prototipo de grado.
- Corrección de baseline, cookies, tasas, latencias, drenaje y Figura 8.
- Tratamiento responsable de US-09, US-20 y de las 19 ausencias históricas.

## Debilidades principales

- Figuras 1, 2 y 4 contradicen el texto actual.
- Evidencia fragmentada; ausencia de suite final congelada.
- Matriz 10/21/0 no incorporada al documento.
- Resultados locales y co-residentes; sin TLS Valkey ni multianfitrión.
- Bibliografía y APA todavía irregulares.
- Persisten una sola corrida válida de drenaje y ausencia de reloj independiente reportado.

## Preguntas previsibles del tribunal

1. ¿Cómo se obtiene exactamente 10/21/0 y qué criterio convierte una historia en completa?
2. ¿Por qué la Figura 1 muestra mTLS hacia Valkey si el transporte Valkey no fue cifrado?
3. ¿Qué garantiza realmente el protocolo denominado exactamente-una-vez?
4. ¿Por qué Run 4 cumple con solo 0,854 s de margen y una única corrida válida?
5. ¿Cómo se defenderá el P99 si la latencia objetivo (a→c) y la histórica (b→c) difieren?
6. ¿Qué valor aporta la tesis si la hipótesis conjunta no fue corroborada?
7. ¿Qué información sensible puede contener US-09 y cómo se gobierna su envío?
8. ¿Qué ocurre ante compromiso privilegiado del anfitrión que contiene baseline y clave?

## Condiciones mínimas para mejorar el dictamen

1. Regenerar Figuras 1, 2 y 4 conforme al texto vigente.
2. Corregir la nota de Tabla 18 para identificar cada corte de evidencia.
3. Incorporar o depositar institucionalmente la matriz completa 10/21/0.
4. Mantener explícita la ausencia de suite final o producirla sobre un commit congelado.
5. Reparar enlaces y normalizar referencias APA.

## Plan priorizado de correcciones

| Prioridad | Acción | Impacto | Esfuerzo |
|---|---|---|---|
| 1 | Regenerar Figuras 1, 2 y 4. | Muy alto | Medio |
| 2 | Corregir nota de Tabla 18 e índice 12/12a. | Alto | Bajo |
| 3 | Adjuntar matriz detallada 10/21/0. | Muy alto | Bajo/medio |
| 4 | Congelar commit y ejecutar suite integral, si el cronograma lo permite. | Muy alto | Alto |
| 5 | Repetir Run 4 y reportar variabilidad. | Alto | Medio |
| 6 | Normalizar bibliografía, enlaces y APA 7. | Medio | Bajo |
| 7 | Incorporar matriz de privacidad para diffs y fallbacks. | Medio | Medio |

## Dictamen final

**Aprobada con observaciones.** La V6 es internamente mucho más coherente y defendible que la versión original. Sus resultados adversos no son causal de rechazo porque se presentan con honestidad y responden a una hipótesis falsable. Las observaciones pendientes se concentran en coherencia gráfica, trazabilidad autocontenida y límites de evidencia, no en manipulación de resultados. La tesis no acredita cumplimiento integral del backlog, seguridad extremo a extremo ni aptitud productiva, y no debe presentarse como si lo hiciera.

## Key Learnings:

1. La mejora principal de V6 es metodológica: separa resultados históricos, verificaciones posteriores y estado final sin agregarlos.
2. Las Figuras 1, 2 y 4 conservan estados anteriores y son ahora la principal fuente de contradicción interna.
3. El recuento 10/21/0 es coherente en el texto, pero no es reproducible sin la matriz detallada externa.
