# Índice de evidencias de cierre

> **Corte:** 2026-09-10. Este índice conduce primero a los resultados que
> sostienen el cierre. El inventario con hashes SHA-256 y las precauciones de
> publicación está en [`evidencia/INDICE.md`](evidencia/INDICE.md).

## Evidencia principal

| Tema | Resultado verificable | Código / evidencia |
|---|---|---|
| US-09 | Diff textual real, acotado y validado desde snapshot limpio | `8039624` + `f08626a`; pruebas citadas en [`MATRIZ_TRAZABILIDAD.md`](MATRIZ_TRAZABILIDAD.md) |
| mTLS agente/backend | Handshake TLS 1.3 válido y rechazos sin certificado, CA no confiable y certificado vencido | `28f87fe`; `backend/tests/test_mtls_transport.py` |
| n8n durable | Cuatro fallos n8n → webhook controlado; fallo total persistido; recuperación con el mismo `notification_id` | `f0a2907`, `e2519eb`, `3bec584`; `n8n/e2e/evidence/` |
| Coverage backend | 570 PASS, 2 omitidas; 2484/2780 statements = 89,35 % | [`evidencia/20260909-coverage-run3/`](evidencia/20260909-coverage-run3/) |
| Corrida causal | 60 operaciones = 50 eventos completos + 10 retornos a baseline descartados legítimamente; 0 ausencias nuevas inexplicadas | `aae55e4`, evidencia `f69e450`; [`RESULTADO.md`](evidencia/absence-20260910T052521Z-r2/RESULTADO.md) |
| D49–D51 | Atribución no resuelta como `null`; `FAN_Q_OVERFLOW` observable; `event_type` y path nulo integrados | `b70934d` + `b8e9513` |
| Baseline aprobada | Candidato local cifrado ligado a `source_event_id`; validación exacta antes de promoción | `8d37075` |
| Backend de ingesta | 8→5 sentencias SQL/evento; 32 pruebas dirigidas PASS | `965dcac`; `backend/tests/test_drain_backend_unit1.py` |
| Drenaje Run 4 | 3.000/3.000 en **29,146335596 s** = **102,928891 eventos/s**; 0 rechazos/duplicados; cadena completa y cola final 0 | evidencia `864b672`; [`RESULTADO.md`](evidencia/drenaje-20260910-run4-unit1/RESULTADO.md) |
| Cuarentena cifrada | AES-256-GCM streaming, HKDF `quarantine-v1`, metadata cifrada, nombres opacos y eliminación durable/idempotente | `b060e5f`; 76/76 dirigidas PASS |
| Retención de cuarentena | Default 30 días configurable 1..365; cleanup inicio/24 h; migración legacy atómica/idempotente | `947edb6`; 50/50 dirigidas PASS |

## Resultados que deben preservarse por separado

- B3/B5 históricos mantienen 19 operaciones sin cadena causal contemporánea.
  La corrida causal nueva no reconstruye esos casos.
- Run 3 conserva 3.000/3.000 en 51,773 s y **NO CUMPLE** `<30 s`.
- Run 4 **CUMPLE** `<30 s` únicamente bajo su laboratorio documentado. No
  establece SLA, validación multianfitrión ni aptitud productiva.
- `32,358 s` fue una proyección previa, no una medición.
- Los dos intentos inválidos de Run 4 permanecen bajo
  [`invalid-runs/`](evidencia/drenaje-20260910-run4-unit1/invalid-runs/) y no
  forman parte del resultado.

## Límites abiertos

| Límite | Estado |
|---|---|
| Cuarentena | Implementada y verificada con límites: no protege root/host vivo/adquisición con secreto; corruptos/desconocidos se preservan; legacy perdió el directorio original y usa `ctime` aproximado cuando no hay timestamp. |
| Dos anfitriones con red real y TLS | No ejecutado. |
| SMTP controlado | No acreditado; el fallback ejecutado fue webhook. |
| Suite final única | Falta agente/backend/frontend sobre un mismo commit congelado. |
| 19 ausencias históricas | Explicación compatible, causalidad runtime retrospectiva no demostrable. |

## Ruta de revisión

1. Leer [`INFORME_CIERRE_TECNICO.md`](INFORME_CIERRE_TECNICO.md).
2. Contrastar indicadores en [`RESULTADOS_VERIFICADOS.md`](RESULTADOS_VERIFICADOS.md).
3. Revisar las 31 historias en [`MATRIZ_TRAZABILIDAD.md`](MATRIZ_TRAZABILIDAD.md).
4. Aplicar las correcciones de redacción de [`CAMBIOS_PARA_TESIS.md`](CAMBIOS_PARA_TESIS.md).
5. Repetir ensayos con [`REPRODUCIR.md`](REPRODUCIR.md).
6. Validar hashes en [`evidencia/INDICE.md`](evidencia/INDICE.md).

## Playwright US-03 / US-25 — 2026-09-10

| Evidencia | Evaluación | Estado | Límite |
|---|---|---|---|
| `docs/cierre/evidencia/us03-us25-playwright-20260910T205424Z/RESULTADO.md` | Refresh/revocación y bulk parcial con usuario/rate-limit aislados | **PASS funcional** | Contratos y tramos live exclusivos continúan BLOCKED. |
| `docs/cierre/evidencia/us03-us25-playwright-20260910T205424Z/combined-final-run1/` | Primera corrida conjunta final | **2/2 PASS** | No acredita multi-key live ni comando/ACK. |
| `docs/cierre/evidencia/us03-us25-playwright-20260910T205424Z/combined-final-run2/` | Segunda corrida consecutiva | **2/2 PASS** | Prueba que el bucket de una corrida no agota la siguiente. |
| `docs/cierre/evidencia/us03-us25-playwright-20260910T203527Z/` y `us03-us25-playwright-20260910T204339Z/` | Descubrimiento/corrección previa | **HISTÓRICO** | No representan el estado final. |

## Laboratorio aislado US-03 / US-16 / US-17 / US-25

| Evidencia | Qué acredita | Resultado | Límite |
|---|---|---|---|
| `docs/cierre/evidencia/us03-us16-us17-us25-isolated-20260910T235332Z/RESULTADO.md` | Rotación JWT live, edición/eliminación con agente real y bulk approve con ACK/efecto | **PASS ejecutado** | Cookie US-03 y wire US-25 siguen BLOCKED contractuales. |
| `.../playwright-us16-us17.log` + `.../playwright-us25.log` | Casos individuales | **1/1 + 1/1 PASS** | Sin mocks de red. |
| `.../playwright-combined.log` | Orden conjunto semánticamente válido | **2/2 PASS** | Un worker, archivos propios por historia. |
| `.../teardown-result.json` | Eliminación de recursos y no alteración del stack principal | **0/0/0; true/true** | Verificable por SHA-256. |

## Playwright US-02 / US-20 / US-31

| Evidencia | Resultado |
|---|---|
| `evidencia/us02-us20-us31-playwright-20260910T212203Z/` | US-02 FAIL; US-20 1 PASS + reconexión INCONCLUSA/BLOCKED por método; US-31 1 PASS/1 FAIL; conjunto aprobado 2/2 PASS; build PASS |
| `evidencia/us02-us20-us31-fixed-20260910T233934Z/` | Corrección posterior: individuales US-02 1/1, US-20 2/2 y US-31 2/2; conjunto 5/5 PASS; evidencia textual sanitizada y medios/traces retirados sin reejecución; build, integridad y teardown PASS |
| `evidencia/us02-us20-us31-fixed-us20isolated20260911T0220Z/` | Evidencia vigente: snapshot congelado; US-20 individual 2/2 dos veces y conjunto US-02/20/31 5/5 dos veces; corte físico sólo de SSE con API/refresh 200; integridad, sanitización y teardown PASS |

El primer paquete se conserva como resultado histórico de descubrimiento. El segundo es la evidencia vigente de estas tres historias; no se suman como una única suite.

## Cierre canónico US-03 / US-16 / US-17 / US-25 — 2026-09-11

| Evidencia | Alcance | Estado |
|---|---|---|
| `docs/cierre/evidencia/us03-us16-us17-us25-isolated-20260911T015529Z/RESULTADO.md` | Cookie/ruta/revocación y multi-key US-03; labels RuleForm; wire y agente/ACK/efecto US-25 | **PASS ejecutado** |
| `docs/cierre/evidencia/us03-us16-us17-us25-isolated-20260911T015529Z/SHA256SUMS` | Integridad del paquete sanitizado | **PASS** |
