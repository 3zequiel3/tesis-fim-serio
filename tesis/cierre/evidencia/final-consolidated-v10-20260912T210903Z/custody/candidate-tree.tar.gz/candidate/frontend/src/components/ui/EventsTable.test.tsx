import { describe, it, expect, vi } from 'vitest'
import { screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { renderWithProviders } from '@/test/renderWithProviders'
import { EventsTable } from './EventsTable'
import type { EventListItem } from '@/api/events'

// D-1/D-7 del design de frontend-severity-triage: aserciones sobre lo que
// el operador VE (texto, presencia/ausencia de clase, contenido de la
// sublínea), nunca sobre clases de Tailwind como fin en sí mismo — un test
// que afirma `border-l-red-500` se rompe con un retoque de paleta y no dice
// nada sobre si el operador puede distinguir un `critical`.

function makeItem(overrides: Partial<EventListItem> = {}): EventListItem {
  return {
    id: 1,
    event_type: 'file_modified',
    path: '/etc/passwd',
    hash_detected: 'deadbeef',
    status: 'pending',
    severity: 'low',
    parent_event_id: null,
    version: 0,
    process_pid: null,
    process_uid: null,
    process_exe: null,
    detected_at: '2026-08-20T12:00:00Z',
    received_at: '2026-08-20T12:00:00Z',
    created_at: '2026-08-20T12:00:00Z',
    resolved_at: null,
    resolved_by: null,
    ack_status: null,
    is_symlink: false,
    symlink_target: null,
    action_failed: false,
    action_error: null,
    ...overrides,
  }
}

const noop = vi.fn()

describe('EventsTable — severidad (8.1, 8.2)', () => {
  it('la fila de un critical muestra el texto "critical" y la de un low muestra "low"', () => {
    const items = [makeItem({ id: 1, severity: 'critical' }), makeItem({ id: 2, severity: 'low' })]
    renderWithProviders(<EventsTable items={items} selected={new Set()} onSelectionChange={noop} />)

    expect(screen.getByText('critical')).toBeInTheDocument()
    expect(screen.getByText('low')).toBeInTheDocument()
  })

  it('la fila de un critical y la de un low no comparten la clase de banda de borde', () => {
    const items = [
      makeItem({ id: 1, path: '/etc/passwd', severity: 'critical' }),
      makeItem({ id: 2, path: '/etc/hosts', severity: 'low' }),
    ]
    renderWithProviders(<EventsTable items={items} selected={new Set()} onSelectionChange={noop} />)

    const criticalRow = screen.getByText('/etc/passwd').closest('tr')!
    const lowRow = screen.getByText('/etc/hosts').closest('tr')!

    expect(criticalRow.className).not.toBe(lowRow.className)
  })
})

describe('EventsTable — contenido de fila (US-06)', () => {
  it('una fila muestra path, estado, severidad y fecha juntos', () => {
    const items = [makeItem({ path: '/var/log/auth.log', status: 'pending', severity: 'high' })]
    renderWithProviders(<EventsTable items={items} selected={new Set()} onSelectionChange={noop} />)

    const row = screen.getByText('/var/log/auth.log').closest('tr')!
    expect(row).toHaveTextContent('pending')
    expect(row).toHaveTextContent('high')
    // formatAbsolute siempre incluye el año — suficiente para confirmar que
    // la celda de fecha está presente sin acoplar el test al formato exacto.
    expect(row).toHaveTextContent('2026')
  })
})

describe('EventsTable — proceso causante (8.3)', () => {
  it('una fila con contexto de proceso muestra el ejecutable, el pid y el uid', () => {
    const items = [
      makeItem({ process_exe: '/usr/bin/vim', process_pid: 4242, process_uid: 0 }),
    ]
    renderWithProviders(<EventsTable items={items} selected={new Set()} onSelectionChange={noop} />)

    expect(screen.getByText(/\/usr\/bin\/vim/)).toBeInTheDocument()
    expect(screen.getByText(/4242/)).toBeInTheDocument()
    expect(screen.getByText(/uid 0/)).toBeInTheDocument()
  })

  it('un evento sin contexto de proceso no renderiza la sublínea ni el texto "null"', () => {
    const items = [
      makeItem({ process_exe: null, process_pid: null, process_uid: null }),
    ]
    const { container } = renderWithProviders(
      <EventsTable items={items} selected={new Set()} onSelectionChange={noop} />
    )

    expect(container.textContent).not.toMatch(/null/i)
    // Sólo debe existir la fila de path, sin una segunda línea de proceso.
    expect(screen.queryByText(/pid/)).not.toBeInTheDocument()
  })
})

// D51/RN-145 (D-10 del design, task 11.6): una fila sin ruta discrimina por
// event_type, no por path === null directamente, y sigue enlazando al detalle.
describe('EventsTable — evento sin ruta (D51/RN-145)', () => {
  it('una fila con path: null y event_type: "detection_gap" muestra la etiqueta y enlaza al detalle', () => {
    const items = [makeItem({ id: 7, path: null, event_type: 'detection_gap' })]
    renderWithProviders(<EventsTable items={items} selected={new Set()} onSelectionChange={noop} />)

    const label = screen.getByText('Brecha de detección')
    expect(label).toBeInTheDocument()
    expect(label.closest('a')).toHaveAttribute('href', '/events/7')
  })

  it('una fila sin ruta no muestra un guion, una cadena vacía ni el literal "null"', () => {
    const items = [makeItem({ id: 8, path: null, event_type: 'detection_gap' })]
    const { container } = renderWithProviders(
      <EventsTable items={items} selected={new Set()} onSelectionChange={noop} />
    )

    expect(container.textContent).not.toMatch(/null/i)
    expect(screen.queryByText('—')).not.toBeInTheDocument()
  })

  it('una fila con ruta renderiza igual que antes (no regresión)', () => {
    const items = [makeItem({ id: 9, path: '/etc/hosts', event_type: 'file_modified' })]
    renderWithProviders(<EventsTable items={items} selected={new Set()} onSelectionChange={noop} />)

    const link = screen.getByText('/etc/hosts')
    expect(link.closest('a')).toHaveAttribute('href', '/events/9')
    expect(screen.queryByText('Brecha de detección')).not.toBeInTheDocument()
  })
})

describe('EventsTable — US-25 selección en lote', () => {
  it('permite seleccionar una fila individual sin seleccionar las demás', async () => {
    const user = userEvent.setup()
    const onSelectionChange = vi.fn()
    const items = [makeItem({ id: 1 }), makeItem({ id: 2, path: '/etc/hosts' })]
    renderWithProviders(
      <EventsTable items={items} selected={new Set()} onSelectionChange={onSelectionChange} />
    )

    await user.click(screen.getByRole('checkbox', { name: 'Seleccionar evento #2' }))

    expect(onSelectionChange).toHaveBeenCalledTimes(1)
    expect([...onSelectionChange.mock.calls[0][0]]).toEqual([2])
  })

  it('seleccionar todo agrega exclusivamente los eventos de la página visible', async () => {
    const user = userEvent.setup()
    const onSelectionChange = vi.fn()
    const items = [makeItem({ id: 10 }), makeItem({ id: 11, path: '/var/log/auth.log' })]
    renderWithProviders(
      <EventsTable items={items} selected={new Set([99])} onSelectionChange={onSelectionChange} />
    )

    await user.click(screen.getByRole('checkbox', { name: 'Seleccionar todos en la página' }))

    expect([...onSelectionChange.mock.calls[0][0]].sort((a, b) => a - b)).toEqual([10, 11, 99])
  })
})

describe('EventsTable — US-31 vínculo de cadena superseded', () => {
  it('un superseded con parent_event_id muestra el indicador y enlaza al evento padre', () => {
    const items = [makeItem({ id: 22, status: 'superseded', parent_event_id: 17 })]
    renderWithProviders(<EventsTable items={items} selected={new Set()} onSelectionChange={noop} />)

    const indicator = screen.getByLabelText('Evento superseded, ver cadena')
    expect(indicator).toHaveAttribute('href', '/events/17')
    expect(indicator).toHaveAttribute('title', 'Ver evento padre #17')
    expect(indicator).toHaveTextContent('#17')
  })
})
