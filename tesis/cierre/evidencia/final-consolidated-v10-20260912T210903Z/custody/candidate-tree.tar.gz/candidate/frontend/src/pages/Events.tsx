import { useState, useEffect, useRef } from 'react'
import { useSearchParams } from 'react-router-dom'
import { useEvents } from '@/hooks/useEvents'
import { EventsTable } from '@/components/ui/EventsTable'
import { BulkActionBar } from '@/components/ui/BulkActionBar'
import { QueryErrorState } from '@/components/ui/QueryErrorState'
import { Pagination } from '@/components/ui/Pagination'
import { parseEventFilters, serializeEventFilters } from '@/utils/eventFilters'
import type { EventFilters } from '@/api/events'

const ALL_STATUSES = [
  'pending',
  'approved',
  'rejected',
  'auto_restored',
  'quarantined',
  'alert_only',
] as const

// Orden de precedencia descendente (critical > high > medium > low): el
// orden en que el operador los busca, no el alfabético (:4.5).
const ALL_SEVERITIES = ['critical', 'high', 'medium', 'low'] as const

export function Events() {
  const [searchParams, setSearchParams] = useSearchParams()
  const filters = parseEventFilters(searchParams)
  const [selected, setSelected] = useState<Set<number>>(new Set())

  // Limpiar selección cuando cambian los filtros o la página
  useEffect(() => {
    setSelected(new Set())
  }, [searchParams.toString()])

  const { data, isLoading, isFetching, isError, refetch } = useEvents(filters)

  // Debounce para path_prefix
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null)
  const [pathInput, setPathInput] = useState(filters.path_prefix ?? '')

  function updateFilter(updates: Partial<EventFilters>) {
    const newFilters: EventFilters = { ...filters, ...updates, page: 1 }
    setSearchParams(serializeEventFilters(newFilters))
  }

  function handlePathChange(value: string) {
    setPathInput(value)
    if (debounceRef.current) clearTimeout(debounceRef.current)
    debounceRef.current = setTimeout(() => {
      updateFilter({ path_prefix: value || undefined })
    }, 300)
  }

  function handleStatusToggle(status: string) {
    const current = filters.status ?? []
    const next = current.includes(status)
      ? current.filter((s) => s !== status)
      : [...current, status]
    updateFilter({ status: next.length > 0 ? next : undefined })
  }

  function handleSeverityToggle(severity: string) {
    const current = filters.severity ?? []
    const next = current.includes(severity)
      ? current.filter((s) => s !== severity)
      : [...current, severity]
    updateFilter({ severity: next.length > 0 ? next : undefined })
  }

  function handlePageChange(newPage: number) {
    const newFilters = { ...filters, page: newPage }
    setSearchParams(serializeEventFilters(newFilters))
  }

  const total = data?.total ?? 0
  const pageSize = filters.page_size ?? 50
  const currentPage = filters.page ?? 1
  const totalPages = Math.max(1, Math.ceil(total / pageSize))
  const showSuperseded = !!filters.include_superseded

  return (
    <div className="space-y-4">
      {/* Encabezado */}
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-semibold text-white">Eventos</h1>
        {isFetching && !isLoading && (
          <span className="text-xs text-gray-500">Actualizando...</span>
        )}
      </div>

      {/* Panel de filtros */}
      <div className="bg-gray-800 border border-gray-700 rounded p-4 space-y-3">
        {/* Filtro por estado */}
        <div>
          <p className="text-xs text-gray-400 mb-1.5">Estado</p>
          <div className="flex flex-wrap gap-2">
            {ALL_STATUSES.map((s) => (
              <label key={s} className="flex items-center gap-1.5 text-sm text-gray-300 cursor-pointer">
                <input
                  type="checkbox"
                  checked={(filters.status ?? []).includes(s)}
                  onChange={() => handleStatusToggle(s)}
                  className="rounded"
                />
                <span className="font-mono text-xs">{s}</span>
              </label>
            ))}
            {showSuperseded && (
              <label className="flex items-center gap-1.5 text-sm text-gray-300 cursor-pointer">
                <input
                  type="checkbox"
                  checked={(filters.status ?? []).includes('superseded')}
                  onChange={() => handleStatusToggle('superseded')}
                  className="rounded"
                />
                <span className="font-mono text-xs">superseded</span>
              </label>
            )}
          </div>
        </div>

        {/* Filtro por severidad (D34/RN-128) */}
        <div>
          <p className="text-xs text-gray-400 mb-1.5">Severidad</p>
          <div className="flex flex-wrap gap-2">
            {ALL_SEVERITIES.map((s) => (
              <label key={s} className="flex items-center gap-1.5 text-sm text-gray-300 cursor-pointer">
                <input
                  type="checkbox"
                  checked={(filters.severity ?? []).includes(s)}
                  onChange={() => handleSeverityToggle(s)}
                  className="rounded"
                />
                <span className="font-mono text-xs">{s}</span>
              </label>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {/* Filtro por path */}
          <div>
            <label className="block text-xs text-gray-400 mb-1">Prefijo de path</label>
            <input
              type="text"
              value={pathInput}
              onChange={(e) => handlePathChange(e.target.value)}
              placeholder="/etc/..."
              className="w-full px-3 py-1.5 bg-gray-900 border border-gray-600 rounded text-sm text-gray-200 placeholder-gray-600 focus:outline-none focus:border-primary"
            />
          </div>

          {/* Fecha desde */}
          <div>
            <label className="block text-xs text-gray-400 mb-1">Desde</label>
            <input
              type="datetime-local"
              value={filters.date_from ?? ''}
              onChange={(e) => updateFilter({ date_from: e.target.value || undefined })}
              className="w-full px-3 py-1.5 bg-gray-900 border border-gray-600 rounded text-sm text-gray-200 focus:outline-none focus:border-primary"
            />
          </div>

          {/* Fecha hasta */}
          <div>
            <label className="block text-xs text-gray-400 mb-1">Hasta</label>
            <input
              type="datetime-local"
              value={filters.date_to ?? ''}
              onChange={(e) => updateFilter({ date_to: e.target.value || undefined })}
              className="w-full px-3 py-1.5 bg-gray-900 border border-gray-600 rounded text-sm text-gray-200 focus:outline-none focus:border-primary"
            />
          </div>
        </div>

        {/* Toggle superseded */}
        <label className="flex items-center gap-2 text-sm text-gray-300 cursor-pointer">
          <input
            type="checkbox"
            checked={showSuperseded}
            onChange={(e) =>
              updateFilter({ include_superseded: e.target.checked || undefined })
            }
            className="rounded"
          />
          Mostrar eventos superseded
        </label>
      </div>

      {/* Permanece montada después de la acción para conservar su resumen. */}
      <BulkActionBar
        selected={selected}
        items={data?.items ?? []}
        filters={filters}
        onSelectionChange={setSelected}
      />

      {/* Tabla de eventos */}
      {isLoading ? (
        <div className="py-12 text-center text-gray-500">Cargando eventos...</div>
      ) : isError ? (
        <QueryErrorState resource="los eventos" onRetry={() => refetch()} />
      ) : (
        <EventsTable
          items={data?.items ?? []}
          selected={selected}
          onSelectionChange={setSelected}
        />
      )}

      {/* Paginación (US-26: navegación numerada + "ir a página") */}
      {!isLoading && total > 0 && (
        <div className="flex flex-wrap items-center justify-between gap-3 text-sm text-gray-400">
          <span>
            Mostrando {(currentPage - 1) * pageSize + 1}–{Math.min(currentPage * pageSize, total)} de {total} eventos
          </span>
          <Pagination
            currentPage={currentPage}
            totalPages={totalPages}
            onPageChange={handlePageChange}
          />
        </div>
      )}
    </div>
  )
}
