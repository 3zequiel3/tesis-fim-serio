import { useState } from 'react'
import { useParams, Link, useNavigate } from 'react-router-dom'
import { useEvent } from '@/hooks/useEvent'
import { useEventActions } from '@/hooks/useEventActions'
import { EventTimeline } from '@/components/ui/EventTimeline'
import { DiffViewer } from '@/components/ui/DiffViewer'
import { RejectModal } from '@/components/ui/RejectModal'
import type { RejectAction } from '@/api/actions'
import { getAckStatusMeta } from '@/utils/ackStatus'
import { getActionFailedMeta } from '@/utils/actionFailed'
import { getActionErrorMeta } from '@/utils/actionError'
import { getEventTypeGapMeta } from '@/utils/eventType'
import { formatAbsolute } from '@/utils/timeDisplay'
import type { CommandAckStatus } from '@/api/events'

export function EventDetail() {
  const { id } = useParams<{ id: string }>()
  const eventId = id ? Number(id) : null
  const navigate = useNavigate()

  const { data: event, isLoading, error } = useEvent(eventId)
  const {
    approveMutation,
    rejectMutation,
    needsAbsentConfirmation,
    clearAbsentConfirmation,
  } = useEventActions({ eventId: eventId ?? undefined })

  const [rejectModalOpen, setRejectModalOpen] = useState(false)

  // Manejo de 404
  const is404 =
    error != null &&
    (error as { response?: { status?: number } })?.response?.status === 404

  if (is404) {
    return (
      <div className="max-w-2xl mx-auto py-16 text-center">
        <p className="text-2xl font-semibold text-gray-400">Evento no encontrado</p>
        <p className="text-sm text-gray-500 mt-2">
          El evento #{eventId} no existe o fue eliminado.
        </p>
        <Link to="/events" className="mt-4 inline-block text-blue-400 hover:text-blue-300 text-sm">
          Volver a eventos
        </Link>
      </div>
    )
  }

  if (isLoading || !event) {
    return (
      <div className="py-16 text-center text-gray-500">
        Cargando evento...
      </div>
    )
  }

  const isPending = approveMutation.isPending || rejectMutation.isPending
  const canApprove = event.status === 'pending' || event.status === 'alert_only'

  function handleApprove() {
    if (!event) return
    approveMutation.mutate({
      event_id: event.id,
      version: event.version,
      confirm_absent: needsAbsentConfirmation || undefined,
    })
  }

  function handleRejectConfirm(action: RejectAction) {
    if (!event) return
    rejectMutation.mutate(
      { event_id: event.id, version: event.version, action },
      { onSuccess: () => setRejectModalOpen(false) }
    )
  }

  return (
    <div className="max-w-4xl mx-auto py-6 px-4 space-y-6">
      {/* Encabezado */}
      <div className="flex items-start justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Link to="/events" className="text-gray-500 hover:text-gray-300 text-sm">
              Eventos
            </Link>
            <span className="text-gray-600">/</span>
            <span className="text-gray-300 text-sm">#{event.id}</span>
          </div>
          {/* D51/RN-145 (D-10 del design): cuando path es nulo se sustituye
              la fila de ruta por el tipo de evento y su causa — sin guiones
              ni celdas vacías. Ramifica sobre path === null, ya resuelto por
              event_type dentro de getEventTypeGapMeta. */}
          {event.path !== null ? (
            <h1 className="text-lg font-semibold text-white break-all">
              {event.path}
            </h1>
          ) : (
            <div>
              <h1 className="text-lg font-semibold text-amber-300">
                {getEventTypeGapMeta(event.event_type).label}
              </h1>
              <p className="text-sm text-gray-400 mt-1">
                {getEventTypeGapMeta(event.event_type).cause}
              </p>
            </div>
          )}
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <SymlinkBadge isSymlink={event.is_symlink} />
          <StatusBadge status={event.status} />
          <ActionFailedBadge actionFailed={event.action_failed} />
          <AckStatusBadge ackStatus={event.ack_status} />
        </div>
      </div>

      {/* Metadato de symlink (D33/RN-127): solo se muestra cuando is_symlink es true */}
      {event.is_symlink && (
        <FieldCard label="Destino del symlink">
          <span className="font-mono text-xs break-all text-cyan-300">
            {event.symlink_target ?? '(desconocido)'}
          </span>
        </FieldCard>
      )}

      {/* Causa del fallo de remediación (D36/RN-130, C41): califica al
          indicador de action_failed que introdujo C40. Permite distinguir un
          problema de despliegue (path no escribible) de un problema de datos
          (baseline ausente/incompleto). No se muestra en la tabla — es
          información de segundo nivel del detalle. */}
      <ActionErrorNote cause={event.action_error} />

      {/* Acciones (solo si está pendiente o alert_only) */}
      {canApprove && (
        <div className="flex gap-2">
          {needsAbsentConfirmation ? (
            <div className="flex items-center gap-3 p-3 bg-yellow-950 border border-yellow-800 rounded text-sm">
              <span className="text-yellow-300">
                El archivo no está en el baseline. ¿Confirmar aprobación de ausencia?
              </span>
              <button
                onClick={handleApprove}
                disabled={isPending}
                className="px-3 py-1.5 bg-green-700 hover:bg-green-600 text-white rounded text-xs font-medium disabled:opacity-50"
              >
                Confirmar
              </button>
              <button
                onClick={clearAbsentConfirmation}
                className="px-3 py-1.5 bg-gray-700 hover:bg-gray-600 text-gray-300 rounded text-xs"
              >
                Cancelar
              </button>
            </div>
          ) : (
            <>
              <button
                onClick={handleApprove}
                disabled={isPending}
                className="px-4 py-2 bg-green-700 hover:bg-green-600 text-white rounded text-sm font-medium disabled:opacity-50"
              >
                {approveMutation.isPending ? 'Aprobando...' : 'Aprobar'}
              </button>
              <button
                onClick={() => setRejectModalOpen(true)}
                disabled={isPending}
                className="px-4 py-2 bg-danger hover:bg-danger-hover text-white rounded text-sm font-medium disabled:opacity-50"
              >
                Rechazar
              </button>
            </>
          )}
        </div>
      )}

      {/* Detalles del evento */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <FieldCard label="Hash detectado">
          {event.hash_detected ? (
            <span className="font-mono text-xs break-all text-red-400">
              {event.hash_detected}
            </span>
          ) : (
            <span className="text-gray-500 text-xs italic">
              Archivo ausente (no en baseline)
            </span>
          )}
        </FieldCard>

        <FieldCard label="Versión de optimistic lock">
          <span className="font-mono">{event.version}</span>
        </FieldCard>

        <FieldCard label="Detectado">
          {formatAbsolute(event.detected_at)}
        </FieldCard>

        <FieldCard label="Recibido por backend">
          {formatAbsolute(event.received_at)}
        </FieldCard>

        {event.resolved_at && (
          <FieldCard label="Resuelto">
            {formatAbsolute(event.resolved_at)}
          </FieldCard>
        )}

        {event.resolved_by != null && (
          <FieldCard label="Resuelto por (user ID)">
            {event.resolved_by}
          </FieldCard>
        )}
      </div>

      {/* Contexto de proceso */}
      {(event.process_pid != null || event.process_uid != null || event.process_exe) && (
        <section className="bg-gray-800 border border-gray-700 rounded p-4 space-y-2">
          <h2 className="text-sm font-semibold text-gray-300">Proceso que generó el evento</h2>
          <dl className="grid grid-cols-1 md:grid-cols-3 gap-2 text-sm">
            {event.process_pid != null && (
              <div>
                <dt className="text-gray-500 text-xs">PID</dt>
                <dd className="font-mono text-gray-200">{event.process_pid}</dd>
              </div>
            )}
            {event.process_uid != null && (
              <div>
                <dt className="text-gray-500 text-xs">UID</dt>
                <dd className="font-mono text-gray-200">{event.process_uid}</dd>
              </div>
            )}
            {event.process_exe && (
              <div>
                <dt className="text-gray-500 text-xs">Ejecutable</dt>
                <dd className="font-mono text-xs text-gray-200 break-all">{event.process_exe}</dd>
              </div>
            )}
          </dl>
        </section>
      )}

      <section className="bg-gray-800 border border-gray-700 rounded p-4 space-y-3">
        <h2 className="text-sm font-semibold text-gray-300">Diff de contenido</h2>
        {event.diff_text ? (
          <DiffViewer diffText={event.diff_text} />
        ) : (
          <p className="text-sm text-gray-500 italic">
            Diff textual no disponible para este evento.
          </p>
        )}
      </section>

      {/* Timeline */}
      <section className="bg-gray-800 border border-gray-700 rounded p-4">
        <EventTimeline event={event} />
      </section>

      {/* Botón volver */}
      <div>
        <button
          onClick={() => navigate(-1)}
          className="text-sm text-gray-400 hover:text-gray-200"
        >
          Volver
        </button>
      </div>

      {/* Modal de rechazo */}
      <RejectModal
        event={event}
        open={rejectModalOpen}
        onClose={() => setRejectModalOpen(false)}
        onConfirm={handleRejectConfirm}
        isPending={rejectMutation.isPending}
      />
    </div>
  )
}

function StatusBadge({ status }: { status: string }) {
  const classes: Record<string, string> = {
    pending: 'bg-yellow-900 text-yellow-300 border-yellow-800',
    approved: 'bg-green-900 text-green-300 border-green-800',
    rejected: 'bg-red-900 text-red-300 border-red-800',
    superseded: 'bg-gray-700 text-gray-400 border-gray-600',
    auto_restored: 'bg-blue-900 text-blue-300 border-blue-800',
    quarantined: 'bg-orange-900 text-orange-300 border-orange-800',
    alert_only: 'bg-purple-900 text-purple-300 border-purple-800',
  }
  const cls = classes[status] ?? 'bg-gray-700 text-gray-300 border-gray-600'
  return (
    <span className={`shrink-0 px-2.5 py-1 rounded border text-sm font-mono ${cls}`}>
      {status}
    </span>
  )
}

// Indicador de symlink-as-object (D33/RN-127, C39). Se omite por completo
// cuando el evento es sobre un archivo regular — no altera el render existente.
function SymlinkBadge({ isSymlink }: { isSymlink: boolean }) {
  if (!isSymlink) return null
  return (
    <span className="shrink-0 px-2.5 py-1 rounded border text-xs font-mono uppercase bg-cyan-900 text-cyan-300 border-cyan-800">
      symlink
    </span>
  )
}

// Indicador de remediación fallida (D35/RN-129, C40). Califica al status:
// un pending con action_failed=true significa que el archivo sigue
// adulterado Y la remediación automática ya falló. Se omite por completo
// cuando action_failed es false.
function ActionFailedBadge({ actionFailed }: { actionFailed: boolean }) {
  const meta = getActionFailedMeta(actionFailed)
  if (!meta) return null
  return (
    <span className={`shrink-0 px-2.5 py-1 rounded border text-xs font-mono ${meta.className}`}>
      {meta.label}
    </span>
  )
}

// Indicador secundario de estado de EJECUCIÓN del comando asociado
// (D30/RN-124, C36). Visualmente distinto de StatusBadge; se omite si no
// hay comando confirmable asociado al evento (RN-72 intacto).
function AckStatusBadge({ ackStatus }: { ackStatus?: CommandAckStatus | null }) {
  const meta = getAckStatusMeta(ackStatus)
  if (!meta) return null
  return (
    <span className={`shrink-0 px-2.5 py-1 rounded border text-xs font-mono ${meta.className}`}>
      {meta.label}
    </span>
  )
}

// Causa del fallo de remediación (D36/RN-130, C41). Prosa, no el literal
// crudo salvo que el valor sea desconocido (getActionErrorMeta hace el
// fallback). Se omite por completo cuando no hay causa.
function ActionErrorNote({ cause }: { cause?: string | null }) {
  const meta = getActionErrorMeta(cause)
  if (!meta) return null
  return (
    <div className={`px-3 py-2 rounded border text-sm ${meta.className}`}>
      {meta.label}
    </div>
  )
}

function FieldCard({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="bg-gray-800 border border-gray-700 rounded p-3">
      <dt className="text-xs text-gray-500 mb-1">{label}</dt>
      <dd className="text-sm text-gray-200">{children}</dd>
    </div>
  )
}
